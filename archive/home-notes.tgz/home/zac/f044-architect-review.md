# F-044 Architect Review: Backend Deduplication Design Evaluation

## Executive Summary

Both designs correctly identify the problem (80%+ duplication across 13,600 lines of backend code) and propose reasonable solutions. However, both underestimate certain structural differences between backends. **My recommendation is to adopt the Simplicity design (macro + dialect trait) with targeted improvements from the Pragmatic design's phasing strategy.** The Pragmatic design's generic approach faces a fundamental obstacle: sqlx's type system makes truly generic implementations painful in practice, requiring verbose trait bounds that negate the readability benefits.

---

## Design Summaries

### Simplicity Design: Macro + Dialect Trait
- **Approach**: `SqlDialect` trait (13 methods) + two `macro_rules!` macros that stamp out `impl MetadataWriter/MetadataProvider` for each backend
- **Claim**: 44% LOC reduction (~6,750 lines removed)
- **Key files**: `dialect.rs` (new), `metadata_writer_impl.rs` (new macro), `metadata_provider_impl.rs` (new macro)

### Pragmatic Design: 3-Phase Generic Implementation
- **Approach**: Phase 1 (helper extraction), Phase 2 (`MetadataDialect` trait + `GenericMetadataWriter<D>`), Phase 3 (cleanup)
- **Claim**: 60% LOC reduction (~9,200 lines removed)
- **Key files**: `metadata_dialect.rs` (new), `metadata_writer_generic.rs` (new), `metadata_provider_generic.rs` (new)

---

## Head-to-Head Comparison

### 1. Correctness

**Simplicity**: The macro approach naturally handles sqlx's concrete types because each macro expansion works with a specific pool/row/transaction type. The dialect trait handles SQL syntax differences cleanly. **However**, the design misclassifies several methods as "pure syntax differences" that actually have structural differences:
- `write_transaction_inner`: PG uses `nextval('ducklake_schema_version_seq')` for DDL schema versions while SQLite uses `MAX(schema_version)+1`; SQLite has a `next_catalog_id`/`next_file_id` UPDATE block (lines 653-669 of sqlite writer) that PG doesn't need; MySQL uses `_df_sequences` table.
- `get_or_create_schema`: PG uses `ON CONFLICT (schema_name) WHERE end_snapshot IS NULL DO NOTHING` (partial unique index), MySQL uses `FOR UPDATE` gap locking, SQLite relies on `block_on_with_retry`. Three fundamentally different concurrency strategies.
- `get_or_create_table`: Same pattern as above.
- `create_snapshot`: SQLite computes `next_catalog_id` via nested subqueries; PG computes `next_file_id` via `GREATEST`; MySQL uses `LAST_INSERT_ID()` after insert.

**Pragmatic**: Identifies 8 categories of differences, which is more thorough than the simplicity design's 3. However, the generic approach has a fundamental correctness risk: **sqlx's type system**. The design claims "all three backends implement `sqlx::Database`" as sufficient justification for generics. In reality, a generic implementation requires:
```rust
impl<D: MetadataDialect> GenericMetadataWriter<D>
where
    for<'q> i64: sqlx::Encode<'q, D::Db> + sqlx::Type<D::Db>,
    for<'q> &'q str: sqlx::Encode<'q, D::Db> + sqlx::Type<D::Db>,
    for<'q> bool: sqlx::Encode<'q, D::Db> + sqlx::Type<D::Db>,
    for<'q> Option<i64>: sqlx::Encode<'q, D::Db> + sqlx::Type<D::Db>,
    for<'q> Option<&'q str>: sqlx::Encode<'q, D::Db> + sqlx::Type<D::Db>,
    for<'r> i64: sqlx::Decode<'r, D::Db>,
    for<'r> String: sqlx::Decode<'r, D::Db>,
    for<'r> bool: sqlx::Decode<'r, D::Db>,
    for<'r> Option<i64>: sqlx::Decode<'r, D::Db>,
    for<'r> Option<String>: sqlx::Decode<'r, D::Db>,
    for<'r> Option<bool>: sqlx::Decode<'r, D::Db>,
    // ... and more for every type combination
```
This bound explosion is not mentioned anywhere in the pragmatic design. It would make the generic code harder to read than the current duplication.

**Verdict**: Simplicity wins on correctness for the mechanism, but both need to expand their "per-backend override" lists.

### 2. Simplicity

**Simplicity design**: Ironic name — a 2,500-line `macro_rules!` definition is NOT simple. However, each macro invocation site IS simple (~5-10 lines of configuration), and the dialect trait is genuinely clean (13 methods, ~150 lines for all 3 implementations). The mental model is straightforward: "one shared logic, stamped out per backend."

**Pragmatic design**: The 3-phase approach sounds incremental, but Phase 1 creates intermediate helpers that Phase 2 mostly supersedes. Phase 1's `metadata_provider_common.rs` and `metadata_writer_common.rs` would be largely thrown away when the generic implementation lands. This is wasted work unless Phase 2 doesn't happen (and without Phase 2, the savings are only ~1,500 lines — not worth the effort).

**Verdict**: Simplicity design is simpler in concept despite the large macro. The pragmatic design has unnecessary intermediate abstractions.

### 3. Risk

**Simplicity design**:
- Macro errors in Rust are notoriously poor. A typo inside a 2,500-line macro will produce an error pointing at the macro invocation site, not the actual error location.
- Migration is all-or-nothing per method — you can't partially migrate a single method.
- Mitigation: Migrate one method at a time per the phase plan, run tests after each.

**Pragmatic design**:
- The generic approach has a HIGH risk of getting stuck on sqlx type bounds. If the bounds don't work out (e.g., sqlx's `Row` trait is not sufficiently generic across backends), the entire Phase 2 fails.
- The "parallel testing" strategy (running old and new implementations side-by-side) is good but adds significant temporary complexity.
- The Phase 1 work is low-risk but also low-reward.

**Verdict**: Simplicity design has LOWER risk overall. Macro risks are well-understood and mitigated by incremental migration. The pragmatic design's core bet (sqlx generics work cleanly) is unvalidated and risky.

### 4. Completeness

**Simplicity design**: Lists 17 writer methods and 14 provider methods as "pure syntax" candidates for the macro. Lists 14 writer methods as "abstractable structural" candidates. Lists `initialize_schema` and inlined data as per-backend overrides. **Missing**: Does not account for the structural differences in `write_transaction_inner`, `get_or_create_schema`, `get_or_create_table`, and `create_snapshot`. These are NOT pure syntax differences.

**Pragmatic design**: Provides a more thorough 8-category analysis. Correctly identifies that `write_transaction_inner` is "structurally identical" BUT the design doesn't actually detail how the generic version would handle:
- PG's `nextval()` for schema_version vs SQLite's `MAX()+1`
- SQLite's `next_catalog_id`/`next_file_id` UPDATE that others don't need
- PG's `ON CONFLICT DO NOTHING` with partial index for concurrent races
- MySQL's `INSERT ... then LAST_INSERT_ID()` vs `RETURNING`

**Both designs miss**:
- The boolean binding inconsistency: SQLite's `recompute_table_column_stats` uses `.bind(if agg.contains_null { 1 } else { 0 })` while PG uses `.bind(agg.contains_null)`. This is fixable (sqlx handles bool for SQLite), but it means the code isn't as identical as claimed.
- PG's `quote_identifier` function (already in `metadata_provider.rs`) for table comments uses standard quoting, while MySQL's `metadata_writer_validation.rs` has a different `quote_identifier`.

**Verdict**: Pragmatic design is more thorough in analysis but less complete in specifying how the generic approach handles each difference. Neither design fully accounts for all structural differences in the most complex methods.

### 5. Rust Idiom

**Simplicity design**: Declarative macros are an established Rust pattern but a 2,500-line `macro_rules!` is at the extreme end of acceptable use. The Rust community generally prefers generics or trait objects over macros for code sharing. `#[track_caller]` helps but doesn't fully fix the debugging experience.

**Pragmatic design**: Generics with trait-based abstraction is the idiomatic Rust approach. IF it works cleanly with sqlx, this would be the clear winner. The problem is that sqlx's design doesn't lend itself to backend-generic code — this is why sqlx itself doesn't have a production-quality `Any` backend.

**Verdict**: Pragmatic design is more idiomatic in theory but fights sqlx's design. The simplicity design is pragmatic (ironically) about what actually works with sqlx.

### 6. LOC Claims

**Simplicity design claims 44% (~6,750 lines removed)**:
- Writer: 10,400 -> 4,950 (52% reduction) — **Realistic** if `write_transaction_inner` and `get_or_create_*` can be partially unified. If these stay per-backend, the writer reduction drops to ~45%.
- Provider: 3,199 -> 1,500 (53% reduction) — **Realistic**. Provider methods are simpler with fewer structural differences.
- Net new code (dialect + macros): ~3,500 lines — **Reasonable** estimate.
- **My adjusted estimate: 40-46% reduction (6,100-7,000 lines removed)**

**Pragmatic design claims 60% (~9,200 lines removed)**:
- This requires the generic approach to absorb ALL methods except `initialize_schema`. Given the structural differences in `write_transaction_inner`, `create_snapshot`, `get_or_create_*`, this is **optimistic**.
- If the generic approach hits sqlx type bound issues and falls back to helper extraction (Phase 1 only), the reduction is only ~10% (~1,500 lines).
- **My adjusted estimate: 35-50% reduction** (depends entirely on whether generics work with sqlx).

**Verdict**: Simplicity design's claims are more realistic. The pragmatic design's 60% claim depends on an unvalidated assumption about sqlx generics.

### 7. Developer Experience

**Simplicity design**: After refactoring:
- Adding a new method: Write it once in the macro, implement any needed dialect methods.
- Fixing a bug: Fix in one place (macro body), recompile stamps it to all backends.
- Debugging: Macro expansion errors are painful; use `cargo expand` to see generated code.
- IDE: Can navigate to macro definition. No go-to-definition into expanded methods.

**Pragmatic design**: After refactoring:
- Adding a new method: Write it once in the generic impl.
- Fixing a bug: Fix in one place.
- Debugging: Normal Rust error messages. IDE go-to-definition works.
- IDE: Full rust-analyzer support with generics.

**Verdict**: Pragmatic design wins on DX, IF the generic approach works. The macro approach has worse DX but is guaranteed to work.

---

## Critical Findings Both Designs Miss

### 1. `write_transaction_inner` Is NOT a Macro/Generic Candidate

This ~150-line method is classified as "structurally identical" by both designs, but has AT LEAST 4 structural differences:

| Aspect | SQLite | PostgreSQL | MySQL |
|--------|--------|------------|-------|
| Schema version for DDL | `MAX(schema_version) + 1` | `nextval('ducklake_schema_version_seq')` | `next_sequence_value(&mut tx, "schema_version")` |
| UUID generation | `uuid::Uuid::new_v4().to_string()` bound to `?` | `gen_random_uuid()` in SQL | `uuid::Uuid::new_v4().to_string()` bound to `?` |
| Table ID allocation | `MAX(table_id) + 1` | `nextval('ducklake_table_id_seq')` | `next_sequence_id(&mut tx, "table_id")` |
| Post-commit update | `UPDATE ducklake_snapshot SET next_catalog_id = ..., next_file_id = ...` | None | MySQL uses `_df_sequences` sync |

A macro CAN handle this via callbacks/closures, but the method would need ~5 dialect callbacks, making the macro invocation ugly. Better to keep this per-backend and extract the 60% that IS identical into helper functions.

### 2. Concurrency Strategies Are Backend-Specific

`get_or_create_schema` and `get_or_create_table` use fundamentally different concurrency strategies:
- **SQLite**: Relies on single-writer serialization + `block_on_with_retry`
- **PG**: Uses partial unique indexes + `ON CONFLICT DO NOTHING` + re-fetch
- **MySQL**: Uses `FOR UPDATE` gap locking

These cannot be unified without losing the backend-specific safety guarantees.

### 3. `create_snapshot` Differs Structurally

- **SQLite**: Single INSERT with subqueries for `schema_version`, `next_catalog_id`, `next_file_id`, uses `RETURNING`
- **PG**: Similar INSERT but uses `GREATEST()` instead of nested `MAX()`, no `next_catalog_id`
- **MySQL**: INSERT without RETURNING + `LAST_INSERT_ID()` on a separate connection

---

## Recommendation: Adopt Simplicity Design with Modifications

### What to take from the Simplicity Design:
1. **The dialect trait** — 13 methods, clean and focused. Add 2-3 more methods (see below).
2. **The macro approach** — Works with sqlx's concrete types naturally.
3. **The per-backend override pattern** — Keeps genuinely different code separate.

### What to take from the Pragmatic Design:
1. **Phase 1 from Pragmatic (partial)** — Extract `recompute_table_column_stats` into a shared helper function that takes a dialect reference. This single extraction saves ~160 lines (identical across all 3 backends except placeholder syntax) and validates the dialect trait approach before the big macro migration.
2. **Provider-first migration order** — Start with providers (simpler, lower risk), then tackle writers.
3. **One backend at a time** — Migrate SQLite first (most tested), then PG, then MySQL.

### What to change from the Simplicity Design:

#### 1. Expand the Per-Backend Override List

Move these methods OUT of the macro into per-backend files:

| Method | Why |
|--------|-----|
| `write_transaction_inner` | 4+ structural differences across backends |
| `get_or_create_schema` | Different concurrency strategies |
| `get_or_create_table` | Different concurrency strategies |
| `create_snapshot` | Different INSERT patterns, RETURNING vs LAST_INSERT_ID |
| `initialize_schema` | Already listed as per-backend (correct) |
| Inlined data methods | Already listed as SQLite-only (correct) |

**Impact**: This reduces the macro's scope from ~25 writer methods to ~20. The 4-5 methods moved out represent ~500 lines per backend that stay duplicated, reducing the net LOC savings from 44% to ~38-40%. This is still a major win (5,800-6,100 lines removed).

#### 2. Add Dialect Methods for Remaining Structural Differences

Add to `SqlDialect`:
```rust
/// Whether this dialect supports RETURNING on INSERT (SQLite, PG: true; MySQL: false)
fn supports_returning(&self) -> bool; // Already in simplicity design

/// SQL for "clamp to zero" (MAX(0, x) vs GREATEST(0, x))
fn clamp_zero(&self, expr: &str) -> String; // Already in simplicity design

/// Boolean literal for SQL (needed for queries that embed booleans in SQL text)
fn bool_lit(&self, val: bool) -> &'static str; // Already in simplicity design

// NEW: Column name quoting for reserved words (MySQL needs backticks on `key`, `sql`, `type`)
fn col(&self, name: &str) -> String; // Already in simplicity design

// NEW: INSERT OR IGNORE syntax
fn insert_or_ignore(&self, sql: &str) -> String;
// SQLite: "INSERT OR IGNORE INTO ..."
// PG: "INSERT INTO ... ON CONFLICT DO NOTHING"
// MySQL: "INSERT IGNORE INTO ..."
```

#### 3. Break the Writer Macro into Smaller Chunks

Instead of one 2,500-line macro, use multiple smaller macros grouped by functionality:

```rust
// metadata_writer_impl.rs

macro_rules! impl_writer_drop_ops {
    // drop_table, drop_schema, drop_table_checked, drop_schema_checked
    // ~200 lines
}

macro_rules! impl_writer_file_ops {
    // end_table_files, register_data_file, register_delete_file,
    // register_dml_files, replace_table_files, register_column_stats
    // ~400 lines
}

macro_rules! impl_writer_ddl_ops {
    // alter_table, rename_table, rename_view, create_view, drop_view,
    // set_table_comment, set_column_comment
    // ~600 lines
}

macro_rules! impl_writer_query_ops {
    // get_data_path, set_data_path, record_snapshot_changes,
    // find_table_id, get_active_columns, get_active_partition_columns,
    // list_active_table_ids, register_file_partition_value
    // ~300 lines
}
```

Benefits:
- Each macro is 200-600 lines, not 2,500 — much more debuggable
- Can migrate one group at a time
- If one group is problematic, the others still work
- Each backend file invokes 4 macros instead of 1

### Revised LOC Estimate

| Component | Before | After | Reduction |
|-----------|--------|-------|-----------|
| Writer implementations (3 files) | 10,400 | ~3,600 (overrides) + ~1,500 (macros) = 5,100 | ~5,300 (51%) |
| Provider implementations (3 files) | 3,199 | ~700 + ~800 (macro) = 1,500 | ~1,700 (53%) |
| Dialect trait (new) | 0 | 200 | +200 |
| **Total backend code** | **13,599** | **~6,800** | **~6,800 (50%)** |

---

## Implementation Plan

### Phase 0: Validate (1 commit, low risk)
1. Create `dialect.rs` with the `SqlDialect` trait and 3 implementations
2. Extract `recompute_table_column_stats` into a shared function parameterized by dialect
3. Fix the boolean binding inconsistency in SQLite's `recompute_table_column_stats` (use `.bind(agg.contains_null)` like PG)
4. Run full test suite
5. **Gate**: If this works cleanly, proceed. If sqlx types fight us, reconsider.

### Phase 1: Provider Macro (medium risk)
1. Create `metadata_provider_impl.rs` with grouped macros
2. Migrate SQLite provider first, run tests
3. Migrate PG provider, run tests
4. Migrate MySQL provider, run tests
5. Override: `get_delete_files_added_between_snapshots` (SQLite: correlated subquery), `get_inlined_data`, `count_inlined_rows`

### Phase 2: Writer Macro — Query & File Ops (medium risk)
1. Create `metadata_writer_impl.rs` with `impl_writer_query_ops!` and `impl_writer_file_ops!`
2. Migrate the simplest methods first: `get_data_path`, `set_data_path`, `record_snapshot_changes`, `end_table_files`, etc.
3. Migrate file operations: `register_data_file`, `register_delete_file`, etc. (these need the `supports_returning` / `last_insert_id` split)
4. Test after each batch

### Phase 3: Writer Macro — DDL & Drop Ops (medium risk)
1. Add `impl_writer_ddl_ops!` and `impl_writer_drop_ops!`
2. Migrate `alter_table`, `rename_table`, comment methods, view methods
3. Migrate `drop_table_inner`, `drop_schema_inner` (these are highly duplicated)
4. Test after each batch

### Phase 4: Cleanup
1. Remove dead code
2. Clean up unused SQL constants
3. Final full test run: `cargo test --features write-sqlite`

**Do NOT macro-ize**: `write_transaction_inner`, `get_or_create_schema`, `get_or_create_table`, `create_snapshot`, `initialize_schema`, inlined data methods, `set_columns`. These stay per-backend.

---

## Key Risks the Implementation Team Must Watch

### 1. sqlx Type Inference Inside Macros
When sqlx can't infer types inside a macro expansion, you'll get cryptic errors like "the trait bound `i64: Type<Sqlite>` is not satisfied." Fix: add explicit type annotations in the macro body (e.g., `row.try_get::<i64, _>(0)?`).

### 2. Lifetime Issues with Transaction References
`&mut *tx` inside macros can cause borrow checker issues if the macro tries to use `tx` across multiple await points in a way the borrow checker can't track. Fix: use explicit temporary variables.

### 3. Feature Gate Interactions
The write path is behind `write-sqlite`, `write-postgres`, `write-mysql` feature flags. The dialect trait must be available to all backends. Make sure `dialect.rs` doesn't accidentally pull in unused dependencies.

### 4. The `next_catalog_id` / `next_file_id` Divergence
SQLite updates these in `write_transaction_inner`; PG doesn't need to (IDENTITY columns). Any attempt to unify `write_transaction_inner` must account for this. The safest approach is to keep this method per-backend.

### 5. PG Partial Unique Indexes
PG's `ON CONFLICT (schema_name) WHERE end_snapshot IS NULL DO NOTHING` requires a partial unique index created in `initialize_schema`. If the macro-ized methods generate ON CONFLICT clauses, make sure they use the dialect trait's `upsert()` method and that PG's version generates the right syntax.

### 6. MySQL's `_df_sequences` Table
MySQL has a custom `_df_sequences` table with `next_sequence_id()` / `next_sequence_ids()` helpers for ID allocation. These are MySQL-only and must stay per-backend. Any macro method that allocates IDs must use the `$next_id` callback from the simplicity design.

---

## Why NOT the Pragmatic Design (Generic Approach)

The pragmatic design's Phase 2 hinges on `GenericMetadataWriter<D: MetadataDialect>` where all sqlx operations are generic over the database type. This is theoretically elegant but practically problematic:

1. **Trait bound explosion**: Every method that uses `sqlx::query(...).bind(val)` requires `val: Encode<'_, D::Db> + Type<D::Db>`. With 5-12 binds per method and ~30 methods, you need ~20 unique type bounds. These propagate to every function signature.

2. **Row decoding asymmetries**: While `i64`, `String`, and `Option<T>` decode consistently across backends, there are edge cases (PG's UUID type returns `Uuid` not `String`, PG's `bool` column returns `bool` while SQLite might return `i32` depending on schema).

3. **Transaction type incompatibilities**: `sqlx::Transaction<'_, Sqlite>` and `sqlx::Transaction<'_, Postgres>` are fundamentally different types with different capabilities. Abstracting over them requires the `D::Db` associated type to carry all the right bounds, which gets very verbose.

4. **sqlx's own "Any" backend is incomplete**: If sqlx's own team couldn't make a clean generic backend abstraction, it's a red flag for us to attempt one.

5. **Macros are the pragmatic choice**: The macro approach is ugly but works. Each expansion compiles against concrete types. There are no bound issues, no type inference problems, no lifetime complications from generic transactions.

---

## Why NOT Reject Both

The duplication is real and causing ongoing problems (18+ parity findings across 6 of 8 review cycles). Doing nothing means every bug fix or new feature must be applied 3 times, and parity gaps will continue to appear. The ~50% LOC reduction from the macro approach is worth the macro complexity cost. The codebase has 770+ tests to catch regressions, and the phased migration plan minimizes risk.

---

## Final Verdict

**Adopt the Simplicity design (macro + dialect trait) with the modifications described above.**

- Use smaller, grouped macros instead of one monolithic macro
- Expand the per-backend override list to include methods with structural differences
- Follow the Pragmatic design's phasing strategy (provider first, one backend at a time)
- Validate the approach with Phase 0 (dialect trait + one shared helper) before committing to the full migration
- Expected outcome: ~50% LOC reduction (~6,800 lines removed), elimination of parity gap root cause
