# Building an Agent Factory: Lessons from DataFusion-DuckLake

**Date**: 2026-03-15
**Source**: 11 review cycles, 3 retrospectives, 264 commits, 84k lines of code

---

## 1. Project Context

DataFusion-DuckLake is a Rust extension that gives Apache DataFusion full read/write access to DuckLake catalogs -- an integrated data lake format storing metadata in SQL databases (DuckDB, SQLite, PostgreSQL, MySQL) and data as Parquet files on disk or object storage. The project required implementing catalog interfaces, query planning, DML execution (INSERT/DELETE/UPDATE/MERGE), DDL operations (CREATE/ALTER/DROP), and cross-engine interoperability with DuckDB.

### Scale

| Metric | Value |
|--------|-------|
| Total commits | 264 |
| Lines added | 84,450 |
| Source files | 37 (15 new, 22 modified) |
| Test files | 86 (47 new) |
| Review cycles completed | 11 |
| Total raw findings | ~900+ |
| Deduplicated findings | ~600+ |
| Findings fixed | ~430+ |
| Fix-introduced regressions | 8 |
| Tests passing | 811 |
| Cross-engine interop tests | 72+ |
| SQLLogicTest pass rate | 158/254 (62.2%) |
| Total agents spawned | ~135 (55 review + 80 fix) |

### The Agent-Driven Approach

Development and implementation were done by a human coordinating teams of AI agents. The majority of quality assurance work -- code review, bug fixing, and regression testing -- was performed by agents operating in parallel, with a human orchestrating the overall process. Over 7 days, 11 review-fix cycles ran, each involving 9-15 agents working in parallel across isolated git worktrees.

---

## 2. The Core Agent Loop

### The Basic Pipeline

Each review cycle followed a five-stage pipeline:

```
Review (5 agents, parallel)
    |
Synthesis (1 agent)
    |
Fix (3-8 agents, parallel, isolated worktrees)
    |
Merge (1 agent, on integration branch)
    |
Verify (build + test suite)
```

### Stage 1: Review

Five specialized review agents examined the codebase in parallel, each with a distinct mandate:

| Agent | Focus | Example Contribution |
|-------|-------|---------------------|
| Correctness | Data integrity, atomicity, error handling | R1: 6 P0 data corruption bugs. R11-S-001: `append_table_files` row_id starting at 0. |
| Idiomatic | Rust patterns, performance, API design | Allocation hotspots, checked arithmetic gaps, dead code |
| Interop | DuckDB compatibility, cross-engine format parity | R8-S-010/011: Extra DDL columns breaking DuckDB writes |
| Test Harness | Test reliability, false positives, coverage gaps | R2 F-004: Tests silently passing on errors |
| Codex | Broad sweep, additional coverage | R10-S-002/003: Missing table_id joins (Codex-unique finds) |

Each agent produced a findings document with severity ratings (P0-P3), affected files, and suggested fixes.

### Stage 2: Synthesis

A single synthesis agent consumed all five review outputs and performed:

1. **Deduplication**: Eliminated findings discovered by multiple agents (typically 15-30% overlap).
2. **Validation**: Verified P0 claims against source code. This was critical -- Codex had an 86-100% P0 false positive rate (R4-R11). The synthesis agent examined transaction boundaries, error handling, and runtime context to downgrade over-classified findings.
3. **Prioritization**: Assigned validated P0/P1/P2/P3 priorities based on real-world impact.
4. **Fix grouping**: Recommended agent assignments -- which findings should be grouped together based on file proximity, logical coupling, and effort.

### Stage 3: Fix

3-8 fix agents worked in parallel, each in an isolated git worktree. Each agent received:
- A specific set of findings to fix (5-7 optimal; >9 risked context exhaustion)
- Cross-backend verification instructions ("For any change to SQLite, verify PG/MySQL")
- Regression test requirements ("Add tests covering your new code")
- The instruction to report worktree branch name and commit hashes, but NOT merge

### Stage 4: Merge

A dedicated merge agent (NOT in a worktree) merged all fix branches into the integration branch one at a time, resolving conflicts and verifying every claimed fix commit was reachable from the final HEAD. This role was introduced in R4 after lost commits in R1-R3.

### Stage 5: Verify

Full build + test suite after all merges. Any failures were investigated and fixed before the next cycle.

### How the Loop Evolved

| Cycle | Key Process Change | Trigger |
|-------|-------------------|---------|
| R1-R3 | No merge agent; fixes committed directly | -- |
| R4 | Merge agent introduced | R1 P0-3 and P1-4 lost to premature worktree cleanup; undetected for 3 cycles |
| R4+ | Codex P0 downgrade protocol in synthesis | 86% Codex P0 false positive rate identified in R1-R5 retrospective |
| R6+ | Cross-backend verification in fix agent prompts | PG/MySQL parity gaps in 6 consecutive cycles (R3-R8) |
| R7+ | Unique agent names per cycle (e.g., `r7-fix-correctness`) | R6 agents launched in stale tmux panes from R5, inheriting exhausted context |
| R9 | Structural fix (F-044) instead of another review cycle | R1-R8 retrospective recommended addressing root cause of parity gaps |
| R10+ | Review scope considerations; targeted audits | Diminishing returns on full-scope reviews identified |

---

## 3. What Worked Well

### 3.1 Worktree Isolation for Parallel Agents

Every fix agent operated in its own git worktree -- a separate working directory with an independent branch. This eliminated merge conflicts between concurrent agents, allowed agents to build and test independently, and produced clean commit histories per agent.

**Evidence**: After worktree isolation was established in R2, zero coordination conflicts occurred between parallel agents across R2-R11. The only post-R2 issue was an operator error in R4 (worktree cleaned before merge), not a worktree isolation failure.

### 3.2 The Merge Agent

Introducing a dedicated merge agent in R4 was the single most impactful process improvement. Before R4, fix agents committed directly to the integration branch or their worktrees were cleaned up before merging. This caused R1 P0-3 (inline data cleared before durable write) and R1 P1-4 (inline flush writes to wrong directory) to be "fixed" but never actually committed -- persisting undetected for 3 cycles until R4 rediscovered them.

**Evidence**: Zero lost commits in R5-R11 (7 consecutive cycles). The merge agent also handled conflict resolution -- R6 required resolving 21 conflicts across 3 branches from 10 fix agents, cleanly handled in a single merge session.

### 3.3 Five-Agent Review Structure with Complementary Specializations

The five review agents had minimal overlap and complementary blind spots. Each agent uniquely discovered findings that no other agent caught:

- **Correctness** uniquely found: R11-S-001 (append_table_files row_id -- highest-impact P1 in R11), R11-S-003 (MERGE multi-match detection -- SQL standard violation).
- **Interop** uniquely found: R8-S-010/011 (extra DDL columns breaking DuckDB writes -- confirmed experimentally), R10-S-005 (missing SNAPPY compression).
- **Codex** uniquely found: R10-S-002/003 (missing table_id join predicates causing wrong column names on SQLite -- would have caused incorrect query results), R11-S-004 (FOR UPDATE with aggregate fails on PostgreSQL).
- **Test Harness** uniquely found: R2 F-004 (tests silently passing on errors -- masked real bugs).

The deduplication rate across all cycles averaged 15-30%, meaning 70-85% of findings were unique to their discovering agent.

### 3.4 Synthesis Step with Codex P0 Downgrade Protocol

The synthesis agent's role in validating severity claims prevented significant wasted effort. Codex claimed P0 (data corruption/security) severity on 11 findings across R4-R11. Of these, only 1 was validated as P0 (R4-S-001, which was itself a rediscovery of R1 P0-3). The other 10 were downgraded -- typically because Codex failed to account for database transaction boundaries that would prevent the claimed data loss.

**Evidence**: Across R4-R11, the synthesis step correctly downgraded ~30 Codex false positives. Without this gate, those 30 findings would have consumed fix agent capacity on non-issues, at an estimated cost of 6-10 additional agent-cycles.

### 3.5 F-044: Structural Fix vs. Repeated Band-Aids

The PG/MySQL backend parity gap was the project's most predictable failure mode. It appeared in 6 of 8 cycles (R3-R8): every time a fix was applied to the SQLite metadata writer, the corresponding PG/MySQL writers were missed. Each occurrence consumed fix agent capacity to discover and patch.

In R9, the #1 recommendation from both prior retrospectives was finally implemented: F-044, a macro + dialect trait approach that extracted ~4,137 lines of shared logic into common implementations. The result was immediate: R10 and R11 found zero parity gap findings, ending a pattern that had persisted for 6 consecutive cycles.

**Evidence**: Parity gap P1 findings per cycle: R3(1), R4(1), R5(1), R6(2), R7(3), R8(3), R9(0), R10(0), R11(0). F-044's effect was binary -- the systemic issue disappeared entirely.

### 3.6 Unique Agent Names Per Cycle

R6 experienced a failure mode where agents launched with stale tmux panes from R5 because they reused names like `fix-correctness`. The new agent inherited a pane where the previous cycle's agent had already consumed most of its context window, leaving the R6 agent with ~10% context remaining.

**Fix**: Per-cycle naming convention: `r7-fix-correctness`, not `fix-correctness`. Zero recurrences in R7-R11.

### 3.7 The Retrospective Process Itself

Three retrospectives were produced (R1-R5, R1-R8, R9-R11), each analyzing trends, validating prior recommendations, and identifying new patterns. The retrospectives were directly actionable:

| Recommendation | Source | Adopted | Outcome |
|----------------|--------|---------|---------|
| Implement F-044 (code dedup) | R1-R5, R1-R8 | Yes (R9) | Eliminated parity gap theme |
| Validate fix commits | R1-R5 | Yes (R4+) | Zero lost commits since |
| Downgrade Codex P0 | R1-R5 | Yes (R4+) | ~30 false positives prevented |
| Cross-backend verification | R1-R5 | Yes (R6+) | Partially effective, superseded by F-044 |
| Stop full-scope reviews | R9-R11 | Pending | -- |

---

## 4. Problems and How We Addressed Them

### 4.1 Lost Commits (R1-R3)

**What happened**: In R1, fix agents worked in worktrees. Two agents' worktrees were cleaned up before their commits were merged into the integration branch. Two P0/P1 fixes (inline data safety) were marked as "fixed" in the synthesis document but had no corresponding commits in git history.

**When noticed**: R4 (3 cycles later). The Codex review agent rediscovered the same bugs (R4-S-001, R4-S-002).

**What we tried**: Introduced a merge agent in R4 with an explicit verification step: check `git log` after merging to confirm every claimed fix has a reachable commit.

**Did it work**: Yes, completely. Zero lost commits in R5-R11. The merge agent workflow is the project's most successful process innovation.

### 4.2 PG/MySQL Parity Gaps (R3-R8)

**What happened**: The SQLite, PostgreSQL, and MySQL metadata writers shared ~80% identical logic but were maintained as separate 3,000-line files. Every fix to SQLite was at risk of not being ported. This produced P1 findings in 6 consecutive cycles.

**When noticed**: R3 (R3F-006), then recurred in R4 (R4-S-006), R5 (R5-S-003), R6 (R6-S-003/004), R7 (R7-S-009/010/011), R8 (R8-S-007/008/009).

**What we tried**: First, cross-backend verification instructions in fix agent prompts (R6+). This reduced but did not eliminate the problem -- agents could verify existing methods but couldn't detect missing trait overrides or features that were never implemented in PG/MySQL.

**Final fix**: F-044 code deduplication in R9, which extracted shared logic into macros with a dialect trait for backend-specific SQL. The structural fix was unambiguously effective: zero parity findings in R10-R11.

**Lesson**: Repeated patches for a systemic problem are worse than a one-time structural fix. The cumulative cost of NOT doing F-044 (~18 parity findings across 6 cycles, each consuming fix agent work) exceeded the one-time refactoring cost. The retrospectives recommended F-044 twice before it was acted on.

### 4.3 Codex False Positives (R4+)

**What happened**: The Codex review agent consistently over-classified severity. Its P0 false positive rate was 86% (R4-R5) and 100% (R6-R11). The pattern was consistent: Codex flagged code patterns as data-loss risks without verifying whether the code executed within a database transaction that would roll back on failure.

**When noticed**: R4 synthesis step.

**What we tried**: The synthesis agent adopted a default-downgrade policy: Codex P0 claims are treated as P1-candidates requiring source code validation before acceptance.

**Did it work**: Yes, as a management strategy. The synthesis step correctly handled every Codex P0 from R4 onward. However, Codex's overall value remained positive -- despite the false positives, it uniquely identified real bugs no other agent caught (R10-S-002/003 table_id joins, R11-S-004 FOR UPDATE aggregate). In R11, Codex achieved a 94% precision rate (3 FPs out of 48 raw findings), the best cycle ever.

### 4.4 Fix-Introduced Regressions (8 total across 11 cycles)

**What happened**: Fix agents sometimes introduced new bugs while fixing old ones. Eight confirmed regressions across 11 cycles (0.73/cycle average).

**Notable examples**:
- R4-S-008: R3 fix agent invented non-standard `snapshot_changes` tokens (`updated_table:{id}` instead of DuckDB's standard `inserted_into_table:{id},deleted_from_table:{id}`), breaking CDC interop.
- R5-S-001: R3 fix agent used SQL `MIN()`/`MAX()` for column stats stored as VARCHAR -- lexicographic ordering is wrong for numeric types (`MIN('9','10') = '10'`).
- R11-S-004: R10 fix agent added `FOR UPDATE` to `SELECT COALESCE(MAX(schema_version), 0) FROM ducklake_snapshot` -- PostgreSQL rejects `FOR UPDATE` with aggregate functions. This fix was itself suggested by the R10 synthesis document, meaning the synthesis step had a blind spot for backend-specific SQL validity.

**Pattern**: Fix-introduced regressions cluster in two categories: (1) parity gaps (3 of 8) -- fix agent changes SQLite but not PG/MySQL, addressed by F-044; (2) incomplete new code (5 of 8) -- fix agents add code with untested edge cases.

**What we tried**: Regression test requirements in fix agent prompts. Partially effective -- R11-S-024 explicitly flagged R10 fixes as lacking regression tests.

**Lesson**: Requiring tests is necessary but insufficient. The R11-S-004 regression (invalid PostgreSQL SQL) would not have been caught by SQLite-based tests. Backend-specific validation is needed for SQL-generation changes.

### 4.5 Test Infrastructure Never Systematically Addressed (11/11 cycles)

**What happened**: Test infrastructure findings appeared in every single review cycle -- the only category to achieve a perfect 11/11 recurrence rate. Issues included: tests silently passing on errors (R2 F-004), SLT runner never failing CI (R2 F-019), test helper duplication across 17+ files (R11-S-023), normalize_value masking type confusion (R11-S-032), and permanently ignored tests (R11-S-040).

**Why it persisted**: Test infrastructure fixes were always classified as P2/P3 and competed with higher-priority P1 findings for fix agent capacity. No cycle dedicated focused effort to systematically improving the test harness. Each cycle fixed 2-3 test issues incrementally, but new ones were always discovered because the underlying infrastructure was never redesigned.

**Lesson**: Some problems require dedicated investment rather than incremental fixes. A single focused sprint on test infrastructure would have reduced per-cycle findings and improved confidence in all other fixes.

### 4.6 Unchecked Arithmetic Recurring Despite Fixes (8+ cycles)

**What happened**: Unchecked `as` casts, unchecked `+=` accumulation, and missing overflow checking appeared in 8+ of 11 cycles. Despite repeated fixes, new code and newly-reviewed code continued to exhibit the pattern.

**Why it persisted**: This is a Rust code smell that appears naturally in new code. Each fix addressed specific instances but didn't establish project-wide conventions (like a lint rule or a helper function). The pattern was endemic, not localized.

**Lesson**: For recurring code patterns, enforcement (lints, pre-commit hooks, shared utility functions) is more effective than repeated review-and-fix cycles.

---

## 5. The Economics of Agent-Driven Development

### 5.1 Finding Counts Per Cycle

| Cycle | Raw | Dedup | P0 | P1 | P2 | P3 | Fix Agents | P1+P2 Fixed |
|-------|-----|-------|----|----|----|----|-----------|-------------|
| R1 | ~36 | 36 | 6 | 11 | 13 | 13 | 4 | 17 |
| R2 | ~99 | 58 | 5 | 15 | 21 | 17 | 10 | 40 |
| R3 | ~67 | 50 | 3 | 9 | 16 | 22 | 8 | 22 |
| R4 | ~74 | 46 | 1 | 12 | 20 | 13 | 8 | 33 |
| R5 | ~95 | 77 | 0 | 11 | 28 | 38 | 8 | 39 |
| R6 | ~107 | 88 | 0 | 14 | 38 | 36 | 10 | 52 |
| R7 | ~58 | 50 | 0 | 8 | 14 | 28 | 6 | 22 |
| R8 | ~125 | 96 | 0 | 12 | 31 | 53 | 8 | 43 |
| R9 | 55 | 25 | 0 | 2 | 12 | 11 | 5 | 25 |
| R10 | 63 | 42 | 0 | 6 | 17 | 14 | 4 | 19 |
| R11 | 97 | 45 | 0 | 11 | 22 | 9 | 4 | 29 |

### 5.2 P0/P1 Severity Trajectory

P0 findings were exhausted by R5. The last validated P0 was R4-S-001, and R6-R11 had zero validated P0s across 6 consecutive cycles (despite Codex claiming P0s in most cycles, all were downgraded).

P1 findings showed no convergence. Full-scope reviews (R10, R11) continued to find 6-11 P1s per cycle. The nature shifted from safety bugs (SQL injection, data corruption in R1-R3) to completeness bugs (metadata edge cases, defensive coding gaps in R8-R11), but the volume remained stable.

### 5.3 Cost Per Finding

| Metric | Value |
|--------|-------|
| Total agents spawned | ~135 |
| Total findings fixed | ~430 |
| Findings fixed per agent (overall) | ~3.2 |
| P1+P2 fixed per fix agent | ~4.3 |

The optimal fix agent load was 5-7 findings. Below 5, agents were underutilized. Above 9, agents risked context exhaustion (particularly when working on large files like `metadata_writer_sqlite.rs` at 3,000+ lines).

### 5.4 Diminishing Returns Curve

The value trajectory was clear:

- **R1-R3 (highest value)**: 14 validated P0s (SQL injection, data corruption, atomicity violations). Cost: ~36 agents. These were existential bugs that would have caused data loss in production.
- **R4-R6 (medium-high value)**: 1 validated P0, ~39 P1s. Cost: ~26 agents. P1s shifted from safety to completeness.
- **R7-R9 (medium value)**: 0 P0s, ~13 P1s. Cost: ~17 agents. P1s increasingly edge-case.
- **R10-R11 (diminishing value)**: 0 P0s, ~17 P1s. Cost: ~8 agents. P1s were metadata edge cases with low real-world probability.

The R9-R11 retrospective concluded: "We are past diminishing returns for review cycles. The project should ship." No P1 from R10-R11 would cause data corruption for a normal user.

### 5.5 The Fix-Introduced Regression Tax

At 0.73 regressions per cycle, each review-fix cycle introduced ~0.73 new bugs while fixing ~30+. The regression rate was low but persistent, and it meant that additional review cycles had a small but non-zero chance of making things worse. This is the fundamental argument for knowing when to stop.

---

## 6. Generalizable Patterns for an Agent Factory

### 6.1 Agent Roles and Specialization

**Why specialized reviewers beat general-purpose ones**: A single general-purpose review agent would need to simultaneously evaluate correctness, idiomatic code, cross-system interop, test reliability, and broad coverage. In practice, this leads to shallow coverage of everything rather than deep coverage of anything. The five-agent structure ensured that each agent could focus deeply on its domain, with deduplication handled in synthesis.

**The optimal number of parallel review agents**: Five worked well for a ~35k-line Rust codebase. The overlap rate of 15-30% indicates that five agents are near the sweet spot -- less overlap would mean coverage gaps, more overlap would indicate redundancy. The interop agent and test-harness agent were the most differentiated from the others (lowest overlap). The correctness and codex agents had the highest overlap but caught different things: correctness was precise but narrow, codex was broad but imprecise.

**Fix agent sizing**: 4-5 fix agents in parallel with 5-7 findings each was the optimal configuration. This was validated across R7 (6 agents, 3.7 findings/agent -- cleanest cycle), R8 (8 agents, 5.4 findings/agent -- most productive), and R6 (10 agents -- most conflicts during merge, though all resolved).

**When to use isolation vs. shared state**: Always use isolation (worktrees) for fix agents. The cost of merge conflict resolution is far lower than the cost of coordination between concurrent agents modifying the same files. The merge agent pattern handles conflict resolution centrally and competently.

### 6.2 The Review-Fix-Merge Pipeline

**How to structure the pipeline**:

1. **Review** agents run in parallel, each producing an independent findings document. They should not coordinate or share findings during review -- independence maximizes coverage breadth.
2. **Synthesis** runs serially after all reviews complete. This is the critical quality gate. It deduplicates, validates severity, and groups findings into fix assignments. Without synthesis, fix agents would waste effort on false positives and duplicates.
3. **Fix** agents run in parallel in isolated environments. Each receives a defined scope from synthesis, plus cross-cutting instructions (regression tests, backend verification).
4. **Merge** runs serially after all fix agents complete. A dedicated merge agent prevents lost commits and handles conflicts.
5. **Verify** confirms the integrated result builds and passes all tests.

**Why synthesis is critical**: Synthesis is not just deduplication. Its most valuable functions are:
- **Severity validation**: Codex P0 false positives would have consumed 6-10 fix agent cycles if not caught by synthesis (evidence: R4-R11 downgrade history).
- **Fix grouping**: Assigning related findings to the same agent reduces context switching and prevents conflicting fixes.
- **Root cause identification**: Synthesis can identify when multiple findings share a root cause (e.g., "these 3 findings all stem from the DML path not sharing code with INSERT") and recommend structural fixes.

**How to handle false positives from AI reviewers**: Don't try to eliminate false positives -- manage them. The Codex agent's value came from its unique discoveries (findings no other agent caught), which justified its high false positive rate. The synthesis step served as an efficient filter. The key insight: false positive rate at P0 level matters more than overall FP rate, because P0 claims trigger urgent fix responses.

### 6.3 Quality Control

**Regression testing requirements for fix agents**: Every fix should include a test that would fail without the fix. This was recommended in the R1-R5 retrospective but only partially adopted. In R11, R11-S-024 explicitly flagged R10 fixes as lacking regression tests. The enforcement gap: prompting agents to write tests is weaker than requiring a test as a gate condition. An agent factory should verify that fix agents' diffs include test additions or modifications before accepting their output.

**Cross-component verification**: When a codebase has parallel implementations (multiple backends, platform-specific code, feature-flagged variants), fix agents must verify their changes across all variants. In DuckLake, the SQLite/PG/MySQL writer parity gap persisted for 6 cycles despite awareness because verification was advisory, not enforced. The structural fix (F-044, shared macros with dialect traits) was more effective than process instructions.

**When structural fixes beat repeated patches**: A structural fix should be prioritized when:
1. The same class of finding appears in 3+ consecutive cycles (the parity gap threshold).
2. The cumulative cost of finding-and-fixing exceeds the one-time refactoring cost.
3. The fix agents' scope instructions cannot prevent the recurrence (because the problem is in the code structure, not the fix process).

F-044's impact was immediate and total: zero parity findings after implementation, vs. 2-3 per cycle before.

### 6.4 Process Evolution

**How the loop should adapt over time**:

Early cycles should be broad and aggressive -- they'll find the most critical bugs. As P0 findings are exhausted and P1s shift from safety to completeness, the process should evolve:

1. **Full-scope reviews** in early cycles (R1-R5): Cast a wide net.
2. **Structural fixes** when recurring patterns are identified (R9): Invest in root causes.
3. **Targeted reviews** in later cycles: Focus on specific subsystems (e.g., "audit all metadata queries for snapshot-awareness" -- done in the post-R11 snapshot audit) rather than whole-codebase sweeps.
4. **PR-based reviews** for maintenance: Review changed files only, triggered by code changes.

**When to stop iterating and ship**: Stop when:
- P0 findings have been zero for 3+ consecutive cycles (achieved at R8).
- P1 findings are stable but shifting from safety to edge cases (achieved at R6).
- The fix-introduced regression rate approaches the finding rate (not yet reached, but the trend was visible).
- A retrospective recommends shipping (R9-R11 retrospective).

In DuckLake, the optimal stopping point was probably R8-R9 (after F-044). R10-R11 found real bugs but at diminishing marginal value.

**The role of retrospectives**: Retrospectives were the primary mechanism for process improvement. Every significant process change (merge agent, Codex downgrade protocol, unique agent names, F-044 recommendation) originated in a retrospective. The key discipline: retrospectives must analyze trends across multiple cycles, not just the latest cycle. Single-cycle analysis misses systemic patterns.

### 6.5 Memory and Context

**The handoff document pattern**: The `handoff-prompt.md` file served as the authoritative project state document, updated after each cycle. It contained: full review cycle history with commit hashes, current feature status, deferred items, and instructions for spawning new agents. Any new agent (or human) could read this single document and understand the project's complete history and current state.

**Memory files for cross-conversation persistence**: A `MEMORY.md` file tracked current state across agent sessions: which branch, which commit, what's been done, what's pending. This prevented agents from repeating work or operating on stale assumptions.

**Agent naming as context management**: Unique names per cycle (`r7-fix-correctness`, not `fix-correctness`) prevented infrastructure-level context contamination. In an agent factory, agent identity should encode its lifecycle scope to prevent session reuse.

---

## 7. Open Questions and Research Ideas

### 7.1 Could a "Pre-Flight" Agent Validate Fix Plans?

R10-S-004's fix (adding `FOR UPDATE` to an aggregate query) was suggested by the synthesis document itself and then implemented by a fix agent -- producing invalid PostgreSQL SQL that was only caught in R11. A pre-flight agent could review proposed fixes before agents start coding, checking for backend-specific SQL validity, API compatibility, and potential side effects.

### 7.2 Could Backend-Specific Tests Be Required for SQL-Generation Changes?

The R11-S-004 regression would have been caught by running `cargo test --features write-postgres` against a real PostgreSQL instance. An agent factory could enforce: any change to shared SQL generation code triggers backend-specific test execution before the fix is accepted.

### 7.3 What if Fix Agents Had to Write Tests First (TDD)?

Requiring agents to write a failing test before implementing a fix would: (1) verify the agent understands the bug, (2) create automatic regression coverage, (3) provide a clear "done" signal. The risk: some findings (especially P2/P3 code quality issues) don't have natural test expressions.

### 7.4 Could a "Regression Detector" Agent Compare Before/After Diffs?

A specialized agent could examine each fix agent's diff and look for: (1) changes to SQL strings without corresponding test changes, (2) modifications to shared code (macros, traits) without verification across all consumers, (3) new code paths without test coverage.

### 7.5 How Would This Scale?

DuckLake was ~35k lines of source code. At 10x (350k), the five-agent review structure would likely need subsystem-scoped reviews rather than whole-codebase sweeps. At 100x (3.5M lines), the agent factory would need a hierarchical structure: subsystem-level review teams feeding into a project-level synthesis.

### 7.6 Could Review Agents Learn from Prior Cycle Findings?

Unchecked arithmetic appeared in 8+ cycles. If review agents had access to prior findings and patterns, they could: (1) proactively check known problem areas, (2) avoid re-discovering fixed issues, (3) focus on areas not covered in prior cycles. The risk: accumulated context might bias agents toward expected patterns, reducing their ability to find novel issues.

### 7.7 What Is the Optimal Cycle Length?

DuckLake used rapid-fire cycles (sometimes 2-3 per day). Slower cycles with more deliberate review and fix phases might produce higher-quality fixes with fewer regressions. However, fast cycles enable faster convergence on critical issues (the P0 findings were all found and fixed within the first 4 cycles spanning 3 days).

### 7.8 The P3 Backlog Problem

P3 findings accumulated every cycle (~150+ unaddressed by R11). They were never assigned because P1/P2 findings consumed all fix agent capacity. An agent factory needs a strategy for the long tail: periodic "cleanup sprints" dedicated to P3 items, or automatic P3 assignment when fix agents have spare capacity.

### 7.9 Could Agents Self-Organize?

The current model uses centralized coordination (human orchestrator assigns agents). Could agents negotiate their own scope? For example: review agents could vote on which findings are most critical, fix agents could claim findings based on their expertise, and the merge agent could request re-fixes when it detects conflicts. The risk: coordination overhead might exceed the benefit.

### 7.10 Agent Factory Dashboard Metrics

An agent factory dashboard should track:
- P0/P1/P2/P3 finding counts per cycle (severity trajectory)
- Fix-introduced regression count per cycle (quality signal)
- Codex false positive rate (calibration signal)
- Findings per agent (efficiency signal)
- Time from finding to fix (latency signal)
- Test count and pass rate (quality floor)
- Recurring theme list with cycle counts (structural debt signal)

---

## 8. Anti-Patterns to Avoid

### 8.1 Don't Reuse Agent Names Across Cycles

Reusing names like `fix-correctness` across cycles caused R6 agents to launch in stale tmux panes from R5, inheriting exhausted context windows. Use `r7-fix-correctness` to guarantee fresh sessions.

### 8.2 Don't Skip the Merge Agent Step

Direct commits to shared branches from parallel agents caused lost commits in R1-R3. Two P0 fixes were "fixed" but never actually committed, persisting undetected for 3 cycles. A dedicated merge agent with commit verification prevents this class of failure entirely.

### 8.3 Don't Trust Codex P0 Claims Without Validation

Codex had an 86-100% P0 false positive rate across R4-R11. Every P0 claim from any AI reviewer should be validated against source code by the synthesis step, with particular attention to transaction boundaries, error handling context, and runtime environment.

### 8.4 Don't Apply Fixes Without Regression Tests

Fix-introduced regressions averaged 0.73 per cycle. The R11-S-004 regression (invalid PostgreSQL SQL from R10's fix) was only caught because another review cycle happened to run. Without regression tests, fix-introduced bugs can persist indefinitely. Require test additions as a condition for accepting fix agent output.

### 8.5 Don't Do Endless Review Cycles

Full-scope reviews continued finding ~8-12 P1s per cycle with no evidence of convergence. This means the review process could run indefinitely without reaching zero findings. The decision to stop must be based on severity trajectory (P0 exhaustion), marginal value (P1s shifting from safety to edge cases), and opportunity cost (what else could the agent capacity accomplish). In DuckLake, the optimal stopping point was R8-R9; R10-R11 provided diminishing value.

### 8.6 Don't Patch Symptoms When Structural Fixes Are Available

The PG/MySQL parity gap was patched 11+ times across 6 cycles before the structural fix (F-044) was implemented. Each patch consumed fix agent capacity and didn't prevent the next occurrence. When a retrospective identifies a root cause, prioritize the structural fix over another band-aid cycle. The cumulative cost of deferred structural fixes exceeds the one-time investment.

### 8.7 Don't Neglect Infrastructure Problems

Test infrastructure findings appeared in all 11 cycles but were never systematically addressed because they were always P2/P3. Similarly, unchecked arithmetic appeared in 8+ cycles. Problems that recur every cycle despite being "fixed" indicate that the fix scope is too narrow. Either invest in a comprehensive cleanup sprint or establish enforcement mechanisms (lints, hooks, shared utilities) that prevent recurrence.

### 8.8 Don't Let Synthesis Suggest Backend-Specific Solutions Without Validation

R10's synthesis document suggested `FOR UPDATE` as the fix approach for a PostgreSQL concurrency issue. The fix agent faithfully implemented it, producing invalid SQL because PostgreSQL disallows `FOR UPDATE` with aggregates. Synthesis documents should flag backend-specific solutions as requiring validation, or the pre-flight agent concept (Section 7.1) should be implemented.

---

## Appendix: Key Documents

For those wanting to examine the primary sources:

| Document | Purpose |
|----------|---------|
| `docs/2026-03-03-retrospective-r1-r5.md` | First retrospective: P0 trajectory, Codex FP rates, parity gap pattern |
| `docs/2026-03-05-retrospective.md` | Second retrospective: R1-R8 trend analysis, ROI, process maturation |
| `docs/2026-03-07-retrospective-r9-r11.md` | Third retrospective: F-044 impact, diminishing returns, ship recommendation |
| `docs/handoff-prompt.md` | Authoritative project state: full cycle history, agent instructions, merge workflow |
| `docs/2026-03-06-r10-review-synthesis.md` | Example synthesis: deduplication, validation, fix grouping |
| `docs/2026-03-06-r11-review-synthesis.md` | Example synthesis: Codex P0 validation, fix-introduced regression discovery |
| `CLAUDE.md` | Project architecture reference and build/test instructions |
