# DuckLake Security Review - Team Lead Notes

**Date started**: 2026-02-24
**Repo**: /home/zac/datafusion-ducklake
**PR Strategy**: /home/zac/ducklake-pr-strategy.md

## CRITICAL: Branch Strategy Change

**All existing work is on `ducklake-features/integration` which has ~40 feature commits beyond main.**
Cherry-picks to main FAIL with conflicts. All fixes must be **re-implemented fresh against `origin/main`**.
Existing commits serve as **reference implementations only**.

See `/home/zac/ducklake-pr-strategy.md` for full PR plan (9 PRs).

## Issue Inventory (13 issues, all labeled "security-review")

### Priority 1 - Security Critical
| # | Title | Reference Phase | PR Phase | PR Branch |
|---|-------|-----------------|----------|-----------|
| 54 | SECURITY: Path traversal via ../ | DONE (ref: 6d21593, 9c9aaf6) | NEEDS RE-IMPL | fix/path-traversal-null-bytes |
| 55 | SECURITY: Null bytes in paths | DONE (ref: 90d3b6b) | NEEDS RE-IMPL (combined w/ #54) | fix/path-traversal-null-bytes |
| 52 | Silent data corruption: missing delete files | DONE (ref: 3633fe4, 8c3b38b) | NEEDS RE-IMPL | fix/missing-delete-file-error |

### Priority 2 - Unsafe Casts / Validation
| # | Title | Reference Phase | PR Phase | PR Branch |
|---|-------|-----------------|----------|-----------|
| 58 | Negative file_size_bytes wraps to u64::MAX | IN PROGRESS (impl-58) | NEEDS RE-IMPL (combined w/ #59) | fix/validate-numeric-metadata |
| 59 | Negative footer_size wraps to usize::MAX | IN PROGRESS (impl-59) | NEEDS RE-IMPL (combined w/ #58) | fix/validate-numeric-metadata |
| 63 | column_id as i32 cast wraps | DONE (ref: e18832f) | NEEDS RE-IMPL | fix/column-id-overflow |
| 53 | Invalid decimal precision | NOT STARTED | NEEDS FRESH IMPL | fix/decimal-precision-validation |
| 56 | ColumnDef accepts invalid type strings | NOT STARTED | NEEDS FRESH IMPL | fix/validate-type-strings |

### Priority 3 - Path/URL Handling
| # | Title | Reference Phase | PR Phase | PR Branch |
|---|-------|-----------------|----------|-----------|
| 64 | Leading whitespace breaks scheme detection | NOT STARTED | NEEDS FRESH IMPL | fix/path-resolver-hardening |
| 61 | Case-sensitive scheme check | NOT STARTED | NEEDS FRESH IMPL (combined w/ #64, #60) | fix/path-resolver-hardening |
| 60 | Non-ASCII paths broken by URL encoding | NOT STARTED | NEEDS FRESH IMPL (combined w/ #64, #61) | fix/path-resolver-hardening |
| 57 | Empty catalog fails to open | NOT STARTED | NEEDS VERIFICATION (may be no-op on main) | fix/empty-catalog |

### Priority 4 - Type System
| # | Title | Reference Phase | PR Phase | PR Branch |
|---|-------|-----------------|----------|-----------|
| 62 | Type roundtrip loses precision | NOT STARTED | NEEDS VERIFICATION (may be no-op on main) | fix/type-roundtrip |

## PR Grouping (9 PRs)

| PR | Issues | Priority | Dependencies | Status |
|----|--------|----------|-------------|--------|
| PR 1 | #54 + #55 | HIGH (security) | None | DONE — PR #68 |
| PR 2 | #52 | HIGH (data integrity) | None | DONE — PR #65 |
| PR 3 | #58 + #59 | MEDIUM | None | DONE — PR #66 |
| PR 4 | #63 | MEDIUM | None | DONE — PR #67 |
| PR 5 | #53 | LOW | None | DONE — PR #71 |
| PR 6 | #56 | LOW | None | IN PROGRESS (pr6-7-impl) |
| PR 7 | #62 | LOW | None | IN PROGRESS (pr6-7-impl) |
| PR 8 | #61 + #64 + #60 | LOW | PR 1 | DONE — PR #69 |
| PR 9 | #57 | LOW | None | DONE — PR #70 |

## Current Agents Running

- **reviewer-55**: Reviewing null bytes fix (reference phase)
- **impl-58**: Implementing file_size_bytes fix (reference phase)
- **impl-59**: Implementing footer_size fix (reference phase)

## Two-Phase Approach

### Phase 1 (current): Reference Implementation
- Implement and review fixes on integration branch worktrees
- This validates the approach, catches edge cases via review
- All commits are REFERENCE only

### Phase 2 (next): PR Creation
- Re-implement each fix fresh against origin/main
- Use reference commits as guides
- Create proper PR branches
- Each PR gets its own review cycle

## Activity Log

- 2026-02-24: Created team, dispatched Wave 1 (issues #54, #55, #52)
- 2026-02-24: impl-52 completed fix (commit 3633fe4), 134 tests pass. Dispatched reviewer-52.
- 2026-02-24: reviewer-52 completed review. 2 SHOULD FIX: NotFound distinction, S3 perf TODO. Dispatched fixup-52.
- 2026-02-24: impl-54 completed (commit 6d21593, 450+ tests pass, 12 new tests). Dispatched reviewer-54.
- 2026-02-24: fixup-52 completed (commit 8c3b38b): NotFound vs other errors distinguished. Review confirmed clean.
- 2026-02-24: reviewer-54 completed review. APPROVE with 1 SHOULD FIX: %2e%2e encoded traversal not caught.
- 2026-02-24: fixup-54 completed: %2e%2e rejection added (9c9aaf6). Issues #52 and #54 reference phase DONE.
- 2026-02-24: impl-55 completed (commit 90d3b6b, 15 new tests). Dispatched reviewer-55.
- 2026-02-24: Wave 2 started: impl-58 (#58), impl-59 (#59), impl-63 (#63) dispatched.
- 2026-02-24: impl-63 completed (commit e18832f, 3 new tests).
- 2026-02-24: pr-planner completed: Cherry-picks won't work. Must re-implement all fixes against origin/main. Strategy doc at /home/zac/ducklake-pr-strategy.md.
- 2026-02-24: Waiting on reviewer-55, impl-58, impl-59 to finish reference phase. Then pivot to Phase 2 (PR creation).
- 2026-02-24: reviewer-55 completed: APPROVE with 1 SHOULD FIX (%00 encoded null bytes).
- 2026-02-24: impl-59 completed both #58 and #59 (commit a2c1243). impl-58 redundant, shut down.
- 2026-02-24: impl-63 completed (commit e18832f).
- 2026-02-24: batch-reviewer completed: %00 fix (cce616b), review #63 clean, review #58/#59 found MUST FIX (missing guard in table_changes.rs).
- 2026-02-24: batch-reviewer fixed MUST FIX (commit c0e5c11). ALL reference phase work complete.
- 2026-02-24: PHASE 2 STARTING — Re-implementing all fixes against origin/main for PRs.
- 2026-02-24: PR #65 created (issue #52 — missing delete file error)
- 2026-02-24: PR #66 created (issues #58+#59 — validate numeric metadata) + patched for table_changes.rs
- 2026-02-24: PR #67 created (issue #63 — column_id overflow)
- 2026-02-24: PR #68 created (issues #54+#55 — path traversal + null bytes)
- 2026-02-24: ALL HIGH/MEDIUM PRIORITY PRs DONE. Remaining: PRs 5-9 (issues #53, #56, #57, #60, #61, #62, #64)
