# DuckLake Security Fixes — Work Tracker

**Started**: 2026-02-24
**Repo**: /home/zac/datafusion-ducklake
**Team**: ducklake-security-fixes

## Overview

13 security-review issues (#52-#64). All original PRs merged. 1 new PR for remaining issue.

## PR Status (Final)

| PR | Issues | Branch | CI | Status |
|----|--------|--------|----|--------|
| #65 | #52 (delete files) | fix/missing-delete-file-error | ✅ | **MERGED** |
| #66 | #58+#59 (numeric metadata) | fix/validate-numeric-metadata | ✅ | **MERGED** |
| #67 | #63 (column_id) | fix/column-id-overflow | ✅ | **MERGED** |
| #68 | #54+#55 (path traversal) | fix/path-traversal-null-bytes | ✅ | **MERGED** |
| #69 | #61+#64+#60 (path hardening) | fix/path-resolver-hardening | ✅ | **MERGED** |
| #70 | #57 (empty catalog) | fix/empty-catalog | ✅ | **MERGED** |
| #71 | #53 (decimal precision) | fix/decimal-precision-validation | ✅ | **MERGED** |
| #72 | #56 (type strings) | fix/validate-type-strings | — | **CLOSED** (superseded by #78) |
| #73 | #62 (type roundtrip) | fix/type-roundtrip-precision | — | **CLOSED** (interop — known limitation) |
| #75 | Follow-up to #71 | fix/decimal-parse-edge-cases | ✅ | **MERGED** |
| #78 | #56 (type strings) | fix/validate-column-def-types | Pending | NEW — CI running, reviewed by 3 experts (all APPROVE) |

## Recommended Merge Order

1. **PR #67** (column_id) — independent, ✅ green
2. **PR #65** (delete files) — independent, ✅ green
3. **PR #70** (empty catalog) — independent (has standalone .. check)
4. **PR #68** (path traversal) — largest PR, touches many files
5. **PR #66** (numeric metadata) — may conflict with #65 in table.rs
6. **PR #75** (decimal follow-up) — independent

## Review Rounds Summary

### Wave 2 (initial review) — 4 reviewers
Found: branch contamination, HEAD request perf issue, unchecked casts in table_deletions.rs, PR #72/#73 issues

### Wave 3 (fix round 1)
- PR #65: Rewritten from scratch (no HEAD request, wraps Parquet NotFound)
- PR #66: table_deletions.rs casts fixed
- PR #68: %2f bypass, alloc removal, doc comments fixed
- PR #70: Rebased cleanly onto main
- PR #72/#73: Closed

### Wave 4 (thorough re-review) — 4 reviewers
Found: error message whitespace, UTF-8 decoding regression, footer_size cast inconsistency, merge dependency

### Wave 4 fixes
- PR #65: Error message whitespace fixed
- PR #66: footer_size casts now use usize::try_from everywhere
- PR #68: UTF-8 percent-decoding restored, fast-path added, double-boxing removed
- PR #70: Standalone .. traversal check added (safe to merge independently)
- PR #75: NEW — malformed decimal error + negative scale test

### Wave 5 (verification review) — 3 reviewers
All 6 open PRs APPROVED with no findings:
- reviewer-a: PR #65 APPROVE, PR #67 APPROVE (both CI green)
- reviewer-b: PR #66 APPROVE, PR #75 APPROVE (CI pending)
- reviewer-c: PR #68 APPROVE, PR #70 APPROVE (PR #68 CI needs re-trigger)

## Activity Log

- 2026-02-24: Picked up from previous agent. Cleaned stale worktrees (reclaimed ~118G).
- 2026-02-24: Wave 1: Fixed CI on 6 PRs + implemented PR #73 for issue #62.
- 2026-02-24: Wave 1.5: Fixed remaining build failures (clippy, DuckDB install race).
- 2026-02-24: PRs #69 and #71 merged by user.
- 2026-02-24: Wave 2: 4 reviewers (rust, security, perf, design). Found branch contamination + multiple issues.
- 2026-02-24: Wave 3: Fixed all review findings. Closed PRs #72, #73.
- 2026-02-24: Wave 4: Thorough re-review. Found error message whitespace, UTF-8 regression, cast inconsistency.
- 2026-02-24: Wave 4 fixes: All issues addressed. PR #75 created for merged-PR follow-up.
- 2026-02-24: CI pending on #66, #68, #70, #75. PRs #65, #67 green and ready to merge.
- 2026-02-24: Wave 5: Dispatched 3 verification reviewers (reviewer-a: #65+#67, reviewer-b: #66+#75, reviewer-c: #68+#70). PR #68 CI not triggered for latest commit — needs re-trigger.
- 2026-02-24: Wave 5 results: ALL 6 PRs APPROVED with zero findings. Dispatched ci-trigger to re-trigger PR #68 CI. Shutting down reviewers.
- 2026-02-24: PR #68 CI trigger: pushed trailing newline commit to trigger CI. All GitHub Actions runners backlogged (macOS pending 30+ min across all PRs). CI will resolve when runners are available.
- 2026-02-24: All agents shut down. Wave 5 complete. All 6 PRs ready to merge once CI passes.
- 2026-02-24: PR #68 merge conflict resolved (with PR #69 changes in path_resolver.rs). Junk commits cleaned up. Build + tests pass. Force-pushed.
- 2026-02-24: PR #66 rebased onto main. Resolved 5 conflict zones with PR #68's Result types. Build + tests pass. Force-pushed, CI running.
- 2026-02-24: PR #66 CI failure on main was flaky DuckDB extension autoloading race (not code bug). Re-run triggered.
- 2026-02-24: 2 open issues remain: #56 (type string validation) and #62 (type roundtrip precision). Need new PRs.
- 2026-02-25: All original PRs (#65, #66, #67, #68, #70, #75) confirmed merged to main.
- 2026-02-25: Issue #62 — closing as known limitation. DuckLake catalog normalizes to canonical type names for DuckDB interop. No data loss (Parquet preserves physical types).
- 2026-02-25: Issue #56 — implemented fix: ColumnDef::new() validates type strings, fields made pub(crate), getters added. Reviewed by 3 experts (DataFusion, Rust, perf) — all APPROVE.
- 2026-02-25: PR #78 created for issue #56. CI running.

## New-Code Bug Fix Branches (2026-02-26)

Fixes for 11 bugs found during adversarial security review of the `ducklake-features/integration` branch.
See `docs/new-code-bugs.md` for full details.

| Branch | Bugs Fixed | Status |
|--------|-----------|--------|
| fix/zero-column-tables | V2 (zero-column tables) | Committed, pushed, PR #79 (created prematurely) |
| fix/validate-record-count | M6 (record count validation) | Committed locally |
| fix/name-validation | V1+V3+L3 (empty names, control chars, length limit) | Committed locally |
| fix/type-normalization-promotion | V4+L6 (type normalization, promotion rules) | Committed locally |

Note: `gh` was logged out before branches could be pushed (except zero-column-tables). Need to re-auth and push remaining branches.

## Remaining Action Items
1. ~~**Issue #56**: ColumnDef accepts invalid type strings~~ — PR #78 created, CI pending
2. ~~**Issue #62**: Type roundtrip loses precision~~ — Closing as known limitation (DuckDB interop)
3. **PR #78**: Await CI, then merge
4. Push fix/validate-record-count, fix/name-validation, fix/type-normalization-promotion branches
5. Create PRs for the 3 unpushed branches
6. Comprehensive review of DuckDB-DuckLake feature parity workstream
