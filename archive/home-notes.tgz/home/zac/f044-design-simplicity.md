# F-044: Provider/Writer Deduplication Design

## Executive Summary

The three metadata backends (SQLite, PostgreSQL, MySQL) contain ~15,200 lines of near-identical code across 6 implementation files. Analysis shows **~70% is identical modulo SQL placeholder/quoting substitution**, **~20% differs in ID generation and concurrency patterns** that can be abstracted into a small dialect trait, and **~10% is genuinely backend-specific** (schema initialization, SQLite-only inlined data). The design uses a **macro-generated implementation + dialect trait** approach: one `SqlDialect` trait (~15 methods) handles SQL syntax differences, a macro stamps out the `impl MetadataWriter/MetadataProvider` blocks for each backend using shared logic, and the few genuinely different methods stay as per-backend overrides. This eliminates ~8,500 lines of duplication (~56% reduction) while keeping the design simple and IDE-navigable.

---

## Current State Analysis

### File sizes

| File | Lines | Role |
|------|-------|------|
| `metadata_writer_sqlite.rs` | 4,478 | Writer impl (includes ~1,140 lines of tests + inlined data) |
| `metadata_writer_postgres.rs` | 2,904 | Writer impl |
| `metadata_writer_mysql.rs` | 3,018 | Writer impl |
| `metadata_provider_sqlite.rs` | 1,054 | Provider (read) impl |
| `metadata_provider_postgres.rs` | 1,085 | Provider (read) impl |
| `metadata_provider_mysql.rs` | 1,060 | Provider (read) impl |
| `metadata_writer.rs` | 833 | Writer trait definition |
| `metadata_provider.rs` | 801 | Provider trait definition + shared SQL constants |
| **Total** | **15,233** | |

### Catalog of Differences

#### Category 1: Pure SQL Syntax (~70% of code)

These methods differ ONLY in SQL string construction. The Rust logic (row mapping, error handling, control flow) is identical.

| Difference | SQLite | PostgreSQL | MySQL |
|-----------|--------|------------|-------|
| **Placeholders** | `?` | `$1, $2, ...` | `?` |
| **Identifier quoting** | `"col"` (double quotes) | `"col"` (double quotes) | `` `col` `` (backticks) |
| **Reserved words** | No quoting needed | No quoting needed | Must quote `key`, `sql`, `type` |
| **Timestamp NOW** | `strftime('%Y-%m-%d %H:%M:%f+00:00','now')` | `CURRENT_TIMESTAMP` | `NOW(6)` |
| **CAST to text** | `CAST(x AS TEXT)` | `CAST(x AS VARCHAR)` | `CAST(x AS CHAR)` |
| **CAST to int** | (none needed) | `CAST(x AS BIGINT)` | `CAST(x AS SIGNED)` |
| **Boolean literals** | `1` / `0` | `TRUE` / `FALSE` | `TRUE` / `FALSE` |
| **Upsert syntax** | `ON CONFLICT(c) DO UPDATE SET x = excluded.x` | `ON CONFLICT(c) DO UPDATE SET x = EXCLUDED.x` | `ON DUPLICATE KEY UPDATE x = VALUES(x)` |
| **Clamp to zero** | `MAX(0, expr)` | `GREATEST(0, expr)` | `GREATEST(0, expr)` |
| **UUID generation** | Rust-side `Uuid::new_v4().to_string()` | SQL `gen_random_uuid()` | Rust-side `Uuid::new_v4().to_string()` |
| **UUID type in SQL** | `VARCHAR` | `UUID` (native, needs `::UUID` casts) | `VARCHAR(255)` |

**Writer methods that are pure syntax differences**: `end_table_files`, `drop_table`, `drop_schema`, `drop_table_checked`, `drop_schema_checked`, `list_active_table_ids`, `register_column_stats`, `register_file_partition_value`, `get_active_partition_columns`, `get_active_columns`, `find_table_id`, `set_table_comment`, `set_column_comment`, `get_data_path`, `set_data_path`, `record_snapshot_changes`, `drop_view`

**Provider methods that are pure syntax differences**: `get_current_snapshot`, `get_data_path`, `list_schemas`, `list_tables`, `list_all_columns`, `list_all_files`, `get_table_structure`, `get_table_files_for_select`, `get_schema_by_name`, `get_table_by_name`, `get_data_files_added_between_snapshots`, `get_file_column_stats`, `get_partition_columns`, `get_file_partition_values`

#### Category 2: Abstractable Structural Differences (~20%)

These methods have the same high-level algorithm but differ in how they generate IDs, handle concurrency, or retrieve insert IDs.

| Pattern | SQLite | PostgreSQL | MySQL |
|---------|--------|------------|-------|
| **ID generation** | `MAX(col)+1` in transaction | `nextval('seq_name')` | `next_sequence_id(&mut tx, "name")` |
| **Insert ID retrieval** | `RETURNING col` | `RETURNING col` | separate `LAST_INSERT_ID()` call |
| **Row locking** | None (SQLite serializes) | `FOR UPDATE` | `FOR UPDATE` |
| **Blocking wrapper** | `block_on_with_retry` (busy-retry) | `block_on` | `block_on` |
| **Existence check** | `SELECT COUNT(*)` | `SELECT EXISTS(...)` | `SELECT COUNT(*)` |

**Writer methods**: `create_snapshot`, `get_or_create_schema`, `get_or_create_table`, `set_columns`, `register_data_file`, `register_delete_file`, `register_dml_files`, `replace_table_files`, `write_transaction_inner`, `begin_checked_write_transaction`, `create_view`, `rename_view`, `rename_table`, `alter_table`

**Provider methods**: `table_exists`, `view_exists`, `list_snapshots`, `list_all_tables`, `get_table_row_count`

#### Category 3: Genuinely Backend-Specific (~10%)

| Feature | Details |
|---------|---------|
| **`initialize_schema`** | Completely different DDL format, sequence creation, bootstrapping per backend |
| **Inlined data** (writer) | SQLite-only: `store_inlined_data`, `read_inlined_data`, `clear_inlined_data`, `get_data_inlining_row_limit`, `get_inlined_row_count` (~300 lines) |
| **`get_inlined_data`** (provider) | Different table introspection: `sqlite_master`/`PRAGMA` vs `information_schema` |
| **`count_inlined_rows`** (provider) | Same introspection differences |
| **`get_delete_files_added_between_snapshots`** (provider) | SQLite uses correlated subqueries (no LATERAL JOIN support); PG/MySQL use LATERAL |
| **SQLite retry logic** | `block_on_with_retry` with exponential backoff for SQLITE_BUSY |
| **MySQL sequence helpers** | `next_sequence_id()`, `next_sequence_ids()`, `last_insert_id()` |

---

## Design: Macro + Dialect Trait

### Why not other approaches?

| Approach | Rejected because |
|----------|-----------------|
| **sqlx `Any` pool** | Feature incomplete; doesn't support all query patterns we use; would require rewriting all queries |
| **Fully generic `impl<D: Dialect>`** | Fights sqlx's type system — `SqlitePool`, `PgPool`, `MySqlPool` are concrete types with different `Row`, `Transaction`, etc. Requires extensive generic bounds that make the code harder to read than the duplication |
| **String template engine** | Over-engineered; adds a dependency and indirection for what's essentially parameterized SQL |

### Why macro + dialect trait?

- **Macro** handles sqlx type differences naturally (each expansion uses the concrete pool/row types)
- **Dialect trait** keeps SQL generation clean and testable (no string interpolation in macro body)
- **Per-backend overrides** for the ~10% that's genuinely different — no forced unification
- Result: one source of truth for logic, small dialect adapters, IDE navigation still works

### Architecture

```
src/
  dialect.rs              (NEW - ~200 lines - SqlDialect trait + 3 implementations)
  metadata_writer.rs      (UNCHANGED - trait definition)
  metadata_writer_impl.rs (NEW - ~2,500 lines - macro definition with shared logic)
  metadata_writer_sqlite.rs   (SHRUNK to ~400 lines - struct + macro invocation + overrides)
  metadata_writer_postgres.rs (SHRUNK to ~250 lines - struct + macro invocation + overrides)
  metadata_writer_mysql.rs    (SHRUNK to ~300 lines - struct + macro invocation + overrides)
  metadata_provider.rs        (UNCHANGED - trait definition)
  metadata_provider_impl.rs   (NEW - ~800 lines - macro definition with shared logic)
  metadata_provider_sqlite.rs   (SHRUNK to ~200 lines)
  metadata_provider_postgres.rs (SHRUNK to ~150 lines)
  metadata_provider_mysql.rs    (SHRUNK to ~150 lines)
```

### The Dialect Trait

```rust
// src/dialect.rs

/// SQL dialect differences between SQLite, PostgreSQL, and MySQL.
/// Each method returns a SQL fragment or performs a dialect-specific operation.
pub trait SqlDialect: Send + Sync + 'static {
    /// Parameter placeholder: "?" for SQLite/MySQL, "$N" for Postgres.
    fn ph(&self, n: usize) -> String;

    /// Quote an identifier: "col" for SQLite/Postgres, `col` for MySQL.
    fn quote_id(&self, name: &str) -> String;

    /// Quote a column name only if it's a reserved word in this dialect.
    /// Returns the column name as-is or quoted.
    fn col(&self, name: &str) -> String;

    /// SQL expression for current timestamp.
    fn now(&self) -> &'static str;

    /// Generate a UUID value. Returns (sql_expr, Option<bind_value>).
    /// SQLite/MySQL: (placeholder, Some(uuid_string))
    /// Postgres: ("gen_random_uuid()", None)
    fn uuid_value(&self) -> (String, Option<String>);

    /// Boolean literal: "1"/"0" for SQLite, "TRUE"/"FALSE" for PG/MySQL.
    fn bool_lit(&self, val: bool) -> &'static str;

    /// CAST expression for text: TEXT, VARCHAR, or CHAR.
    fn cast_text(&self, expr: &str) -> String;

    /// CAST expression for integer (empty for SQLite, BIGINT for PG, SIGNED for MySQL).
    /// Returns expr unchanged if no cast needed.
    fn cast_int(&self, expr: &str) -> String;

    /// Clamp-to-zero: MAX(0, expr) for SQLite, GREATEST(0, expr) for PG/MySQL.
    fn clamp_zero(&self, expr: &str) -> String;

    /// Upsert clause after INSERT.
    /// SQLite: ON CONFLICT(col) DO UPDATE SET x = excluded.x, ...
    /// Postgres: ON CONFLICT(col) DO UPDATE SET x = EXCLUDED.x, ...
    /// MySQL: ON DUPLICATE KEY UPDATE x = VALUES(x), ...
    fn upsert(&self, conflict_col: &str, set_cols: &[&str]) -> String;

    /// Whether this dialect supports RETURNING clauses.
    fn supports_returning(&self) -> bool;

    /// FOR UPDATE clause (empty for SQLite).
    fn for_update(&self) -> &'static str;
}

// --- Implementations ---

pub struct Sqlite;
pub struct Postgres;
pub struct MySql;

impl SqlDialect for Sqlite {
    fn ph(&self, _n: usize) -> String { "?".into() }
    fn quote_id(&self, name: &str) -> String { format!("\"{}\"", name) }
    fn col(&self, name: &str) -> String { name.to_string() }
    fn now(&self) -> &'static str { "strftime('%Y-%m-%d %H:%M:%f+00:00','now')" }
    fn uuid_value(&self) -> (String, Option<String>) {
        ("?".into(), Some(uuid::Uuid::new_v4().to_string()))
    }
    fn bool_lit(&self, val: bool) -> &'static str { if val { "1" } else { "0" } }
    fn cast_text(&self, expr: &str) -> String { format!("CAST({expr} AS TEXT)") }
    fn cast_int(&self, expr: &str) -> String { expr.to_string() } // no cast needed
    fn clamp_zero(&self, expr: &str) -> String { format!("MAX(0, {expr})") }
    fn upsert(&self, conflict_col: &str, set_cols: &[&str]) -> String {
        let sets: Vec<String> = set_cols.iter()
            .map(|c| format!("{c} = excluded.{c}"))
            .collect();
        format!("ON CONFLICT({conflict_col}) DO UPDATE SET {}", sets.join(", "))
    }
    fn supports_returning(&self) -> bool { true }
    fn for_update(&self) -> &'static str { "" }
}

impl SqlDialect for Postgres {
    fn ph(&self, n: usize) -> String { format!("${n}") }
    fn quote_id(&self, name: &str) -> String { format!("\"{}\"", name) }
    fn col(&self, name: &str) -> String { name.to_string() }
    fn now(&self) -> &'static str { "CURRENT_TIMESTAMP" }
    fn uuid_value(&self) -> (String, Option<String>) {
        ("gen_random_uuid()".into(), None)
    }
    fn bool_lit(&self, val: bool) -> &'static str { if val { "TRUE" } else { "FALSE" } }
    fn cast_text(&self, expr: &str) -> String { format!("CAST({expr} AS VARCHAR)") }
    fn cast_int(&self, expr: &str) -> String { format!("CAST({expr} AS BIGINT)") }
    fn clamp_zero(&self, expr: &str) -> String { format!("GREATEST(0, {expr})") }
    fn upsert(&self, conflict_col: &str, set_cols: &[&str]) -> String {
        let sets: Vec<String> = set_cols.iter()
            .map(|c| format!("{c} = EXCLUDED.{c}"))
            .collect();
        format!("ON CONFLICT({conflict_col}) DO UPDATE SET {}", sets.join(", "))
    }
    fn supports_returning(&self) -> bool { true }
    fn for_update(&self) -> &'static str { " FOR UPDATE" }
}

impl SqlDialect for MySql {
    fn ph(&self, _n: usize) -> String { "?".into() }
    fn quote_id(&self, name: &str) -> String { format!("`{}`", name) }
    fn col(&self, name: &str) -> String {
        match name {
            "key" | "sql" | "type" => format!("`{name}`"),
            _ => name.to_string(),
        }
    }
    fn now(&self) -> &'static str { "NOW(6)" }
    fn uuid_value(&self) -> (String, Option<String>) {
        ("?".into(), Some(uuid::Uuid::new_v4().to_string()))
    }
    fn bool_lit(&self, val: bool) -> &'static str { if val { "TRUE" } else { "FALSE" } }
    fn cast_text(&self, expr: &str) -> String { format!("CAST({expr} AS CHAR)") }
    fn cast_int(&self, expr: &str) -> String { format!("CAST({expr} AS SIGNED)") }
    fn clamp_zero(&self, expr: &str) -> String { format!("GREATEST(0, {expr})") }
    fn upsert(&self, _conflict_col: &str, set_cols: &[&str]) -> String {
        let sets: Vec<String> = set_cols.iter()
            .map(|c| format!("{c} = VALUES({c})"))
            .collect();
        format!("ON DUPLICATE KEY UPDATE {}", sets.join(", "))
    }
    fn supports_returning(&self) -> bool { false }
    fn for_update(&self) -> &'static str { " FOR UPDATE" }
}
```

**That's it. One trait, 13 methods, ~150 lines total for all three implementations.**

### The Writer Macro

The macro stamps out the `impl MetadataWriter` block. Here's a representative example showing how it handles the different patterns:

```rust
// src/metadata_writer_impl.rs

/// Helper to build a comma-separated placeholder list: "?, ?, ?" or "$1, $2, $3"
fn placeholders(d: &dyn SqlDialect, start: usize, count: usize) -> String {
    (start..start + count).map(|i| d.ph(i)).collect::<Vec<_>>().join(", ")
}

macro_rules! impl_metadata_writer {
    (
        $struct_name:ty,
        pool_type = $pool_type:ty,
        db_type = $db_type:ty,
        dialect = $dialect:expr,
        block_on = $block_on:path,
        // ID generation: either a closure/function or a macro arm
        next_id = $next_id:expr,
        last_insert_id = $last_insert_id:expr
    ) => {
        #[async_trait::async_trait]
        impl MetadataWriter for $struct_name {

            async fn record_snapshot_changes(
                &self,
                snapshot_id: i64,
                changes: &str,
            ) -> Result<()> {
                let d = $dialect;
                let sql = format!(
                    "INSERT INTO ducklake_snapshot_changes (snapshot_id, changes_made) \
                     VALUES ({}, {}) {}",
                    d.ph(1), d.ph(2),
                    d.upsert("snapshot_id", &["changes_made"])
                );
                $block_on(async {
                    sqlx::query(&sql)
                        .bind(snapshot_id)
                        .bind(changes)
                        .execute(&self.pool)
                        .await?;
                    Ok(())
                })
            }

            async fn get_data_path(&self) -> Result<Option<String>> {
                let d = $dialect;
                let sql = format!(
                    "SELECT value FROM ducklake_metadata WHERE {} = {}",
                    d.col("key"), d.ph(1)
                );
                $block_on(async {
                    let row = sqlx::query(&sql)
                        .bind("data_path")
                        .fetch_optional(&self.pool)
                        .await?;
                    Ok(row.map(|r| r.get::<String, _>(0)))
                })
            }

            // ... ~30 more methods following the same pattern ...
            // Each method: build SQL string using dialect, execute with sqlx,
            // map rows identically across all backends.

            // For methods needing ID generation:
            async fn register_data_file(&self, /* ... */) -> Result<i64> {
                let d = $dialect;
                $block_on(async {
                    let mut tx = self.pool.begin().await?;

                    // ... common SQL logic using d.ph(), d.col(), etc. ...

                    let file_id = if d.supports_returning() {
                        let sql = format!(
                            "INSERT INTO ducklake_data_file (...) VALUES (...) \
                             RETURNING data_file_id"
                        );
                        let row = sqlx::query(&sql)
                            .bind(/* ... */)
                            .fetch_one(&mut *tx)
                            .await?;
                        row.get::<i64, _>(0)
                    } else {
                        let sql = format!(
                            "INSERT INTO ducklake_data_file (...) VALUES (...)"
                        );
                        sqlx::query(&sql)
                            .bind(/* ... */)
                            .execute(&mut *tx)
                            .await?;
                        // MySQL: get last insert ID
                        ($last_insert_id)(&mut tx).await?
                    };

                    tx.commit().await?;
                    Ok(file_id)
                })
            }
        }
    };
}
```

Then each backend file becomes:

```rust
// src/metadata_writer_sqlite.rs (~400 lines total)

use crate::dialect::Sqlite;
use crate::metadata_writer_impl::impl_metadata_writer;

pub struct SqliteMetadataWriter {
    pool: SqlitePool,
}

impl SqliteMetadataWriter {
    // Constructor, block_on_with_retry helper, is_sqlite_busy helper
}

impl_metadata_writer!(
    SqliteMetadataWriter,
    pool_type = SqlitePool,
    db_type = sqlx::Sqlite,
    dialect = Sqlite,
    block_on = Self::block_on_with_retry,
    next_id = |tx, _seq| { /* MAX(col)+1 query */ },
    last_insert_id = |_tx| { unreachable!("SQLite uses RETURNING") }
);

// Override: initialize_schema (stays here, ~150 lines)
// Override: inlined data methods (stays here, ~300 lines, SQLite-only)
```

```rust
// src/metadata_writer_postgres.rs (~250 lines total)

impl_metadata_writer!(
    PostgresMetadataWriter,
    pool_type = PgPool,
    db_type = sqlx::Postgres,
    dialect = Postgres,
    block_on = tokio::runtime::Handle::current().block_on,
    next_id = |tx, seq| { /* nextval(seq) query */ },
    last_insert_id = |_tx| { unreachable!("Postgres uses RETURNING") }
);

// Override: initialize_schema (~100 lines, sequences + partial indexes)
```

```rust
// src/metadata_writer_mysql.rs (~300 lines total)

impl_metadata_writer!(
    MySqlMetadataWriter,
    pool_type = MySqlPool,
    db_type = sqlx::MySql,
    dialect = MySql,
    block_on = tokio::runtime::Handle::current().block_on,
    next_id = |tx, seq| { /* _df_sequences table query */ },
    last_insert_id = |tx| { /* LAST_INSERT_ID() query */ }
);

// Override: initialize_schema (~120 lines, _df_sequences table + NO_AUTO_VALUE_ON_ZERO)
// Helper: next_sequence_id, next_sequence_ids (stays here, ~40 lines)
```

### The Provider Macro

Same pattern, simpler (providers are read-only, fewer structural differences):

```rust
// src/metadata_provider_impl.rs (~800 lines)

macro_rules! impl_metadata_provider {
    (
        $struct_name:ty,
        pool_type = $pool_type:ty,
        db_type = $db_type:ty,
        dialect = $dialect:expr
    ) => {
        #[async_trait::async_trait]
        impl DuckLakeMetadataProvider for $struct_name {
            async fn get_current_snapshot(&self) -> Result<i64> {
                let row = sqlx::query(
                    "SELECT COALESCE(MAX(snapshot_id), 0) FROM ducklake_snapshot"
                )
                    .fetch_one(&self.pool)
                    .await?;
                Ok(row.get::<i64, _>(0))
            }

            async fn list_schemas(&self, snapshot_id: i64) -> Result<Vec<SchemaInfo>> {
                let d = $dialect;
                let sql = format!(
                    "SELECT schema_id, schema_name FROM ducklake_schema \
                     WHERE active = {} AND created_snapshot_id <= {} \
                     ORDER BY schema_name",
                    d.bool_lit(true), d.ph(1)
                );
                let rows = sqlx::query(&sql)
                    .bind(snapshot_id)
                    .fetch_all(&self.pool)
                    .await?;
                Ok(rows.iter().map(|r| SchemaInfo {
                    schema_id: r.get(0),
                    schema_name: r.get(1),
                }).collect())
            }

            // ... all other provider methods ...
        }
    };
}
```

Per-backend provider files shrink to:

```rust
// src/metadata_provider_sqlite.rs (~200 lines)

impl_metadata_provider!(
    SqliteMetadataProvider,
    pool_type = SqlitePool,
    db_type = sqlx::Sqlite,
    dialect = Sqlite
);

// Override: get_delete_files_added_between_snapshots (correlated subquery, no LATERAL)
// Override: get_inlined_data (sqlite_master + PRAGMA table_info)
// Override: count_inlined_rows
```

### Handling the RETURNING / LAST_INSERT_ID Split

This is the most common structural difference. The macro uses a simple conditional:

```rust
// Inside the macro, a helper pattern used by multiple methods:
macro_rules! insert_returning_id {
    ($pool_or_tx:expr, $d:expr, $sql_base:expr, $id_col:expr, $binds:expr) => {{
        if $d.supports_returning() {
            let sql = format!("{} RETURNING {}", $sql_base, $id_col);
            let mut q = sqlx::query(&sql);
            for b in $binds { q = q.bind(b); }
            let row = q.fetch_one($pool_or_tx).await?;
            row.get::<i64, _>(0)
        } else {
            let mut q = sqlx::query($sql_base);
            for b in $binds { q = q.bind(b); }
            q.execute($pool_or_tx).await?;
            ($last_insert_id)($pool_or_tx).await?
        }
    }};
}
```

### Handling ID Generation

The `next_id` callback abstracts the three strategies. Inside the macro:

```rust
// Used in methods like get_or_create_table, set_columns, create_view, alter_table
let new_table_id: i64 = ($next_id)(&mut tx, "table_id").await?;
```

Each backend provides:
- **SQLite**: `SELECT COALESCE(MAX(table_id), 0) + 1 FROM ducklake_table`
- **Postgres**: `SELECT nextval('ducklake_table_id_seq')`
- **MySQL**: `UPDATE _df_sequences SET value = value + 1 WHERE name = 'table_id'; SELECT value FROM _df_sequences WHERE name = 'table_id'`

This is passed as a closure to the macro, keeping the per-backend code in the per-backend file (~10-15 lines each).

---

## Methods That Stay Per-Backend (Not in Macro)

These methods are too different to unify and remain as manual `impl` blocks in their respective files:

### Writer
| Method | Why | Lines (per backend) |
|--------|-----|---------------------|
| `initialize_schema` | Completely different DDL, sequence creation, bootstrapping | 80-150 |
| `store_inlined_data` | SQLite-only | ~100 (SQLite only) |
| `read_inlined_data` | SQLite-only | ~60 (SQLite only) |
| `clear_inlined_data` | SQLite-only | ~30 (SQLite only) |
| `get_data_inlining_row_limit` | SQLite-only | ~20 (SQLite only) |
| `get_inlined_row_count` | SQLite-only | ~30 (SQLite only) |

### Provider
| Method | Why | Lines (per backend) |
|--------|-----|---------------------|
| `get_delete_files_added_between_snapshots` | SQLite: correlated subquery vs PG/MySQL: LATERAL JOIN | ~80 each |
| `get_inlined_data` | Different table introspection APIs | ~60 each |
| `count_inlined_rows` | Different table introspection APIs | ~30 each |

---

## Migration Plan

### Phase 1: Introduce dialect.rs (non-breaking, additive)
1. Create `src/dialect.rs` with the `SqlDialect` trait and three implementations
2. Add `mod dialect;` to `lib.rs`
3. **Test**: `cargo build` passes, no behavior change

### Phase 2: Extract provider macro (low risk)
1. Create `src/metadata_provider_impl.rs` with macro covering ~18 of 22 provider methods
2. Refactor `metadata_provider_sqlite.rs` to use macro + 3 override methods
3. **Test**: Full test suite passes
4. Refactor `metadata_provider_postgres.rs` and `metadata_provider_mysql.rs`
5. **Test**: Full test suite passes
6. Remove unused shared SQL constants from `metadata_provider.rs`

### Phase 3: Extract writer macro (medium risk — larger surface area)
1. Create `src/metadata_writer_impl.rs` with macro covering ~25 of 33 writer methods
2. Start with the simplest methods (pure syntax differences): `record_snapshot_changes`, `get_data_path`, `set_data_path`, `end_table_files`, etc.
3. **Test** after each batch of methods migrated
4. Migrate the ID-generation methods: `get_or_create_table`, `set_columns`, `create_view`, etc.
5. **Test** after each batch
6. Leave `initialize_schema` and inlined data methods in per-backend files
7. **Test**: Full test suite passes including cross-engine tests

### Phase 4: Cleanup
1. Remove dead code from per-backend files
2. Remove any now-unused shared SQL constants
3. Final full test run: `cargo test --features write-sqlite`

**Each phase is independently shippable.** If Phase 3 proves too complex, Phases 1-2 alone eliminate ~2,200 lines of provider duplication.

---

## Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Macro makes debugging harder (error messages point to macro expansion) | Medium | Medium | Keep methods small; use `#[track_caller]`; good error messages in dialect methods |
| Macro makes IDE navigation worse | Medium | Low | Macro is in a single file; each backend file is small and easy to find |
| Subtle SQL differences missed during unification | Medium | High | Migrate one backend at a time; run full test suite after each; cross-engine tests catch parity issues |
| sqlx type inference breaks inside macro | Low | Medium | Test incrementally; worst case, add explicit type annotations in macro |
| Performance regression from format! string building | Very Low | Very Low | SQL strings are small; format! is negligible vs network I/O |

---

## Estimated LOC Impact

| Component | Before | After | Reduction |
|-----------|--------|-------|-----------|
| Writer implementations (3 files) | 10,400 | 2,450 + 2,500 (macro) = 4,950 | ~5,450 (52%) |
| Provider implementations (3 files) | 3,199 | 700 + 800 (macro) = 1,500 | ~1,700 (53%) |
| Dialect trait (new file) | 0 | 200 | +200 |
| Trait definitions (unchanged) | 1,634 | 1,634 | 0 |
| **Total** | **15,233** | **~8,284** | **~6,950 (46%)** |

Accounting for the new macro files and dialect.rs, **net reduction is ~6,750 lines (44%)**.

The remaining per-backend code is genuinely different logic that *should* be separate.

---

## File Structure After Refactoring

```
src/
  dialect.rs                    NEW    ~200 lines  SqlDialect trait + Sqlite/Postgres/MySql impls
  metadata_provider.rs          SAME   ~801 lines  Trait definition (constants cleaned up)
  metadata_provider_impl.rs     NEW    ~800 lines  Macro for shared provider logic
  metadata_provider_sqlite.rs   SHRUNK ~200 lines  Struct + macro call + 3 overrides
  metadata_provider_postgres.rs SHRUNK ~150 lines  Struct + macro call + 3 overrides
  metadata_provider_mysql.rs    SHRUNK ~150 lines  Struct + macro call + 3 overrides
  metadata_writer.rs            SAME   ~833 lines  Trait definition
  metadata_writer_impl.rs       NEW   ~2500 lines  Macro for shared writer logic
  metadata_writer_sqlite.rs     SHRUNK ~400 lines  Struct + macro call + init + inlined data + tests
  metadata_writer_postgres.rs   SHRUNK ~250 lines  Struct + macro call + init
  metadata_writer_mysql.rs      SHRUNK ~300 lines  Struct + macro call + init + sequence helpers
```

---

## Alternative Considered: Procedural Macro

A proc macro (`#[derive(MetadataWriter)]`) could generate implementations from annotated structs. This was rejected because:
- Proc macros live in separate crates, adding build complexity
- They're even harder to debug than declarative macros
- The dialect differences are too varied for a simple derive pattern
- Overkill for this use case

## Alternative Considered: Code Generation Script

A build.rs or external script could generate the three implementation files from a template. Rejected because:
- Adds build-time complexity
- Generated files are harder to review in PRs
- Rust's macro system is sufficient here

---

## Summary

The design is intentionally simple: **one trait** (`SqlDialect`, 13 methods), **two macros** (one for writer, one for provider), **three thin adapter files** per side. The genuinely different code stays per-backend where it belongs. No generics fighting sqlx's type system, no proc macros, no code generation, no new dependencies. Net reduction of ~6,750 lines with the recurring parity-gap problem eliminated at the root — there's only one place to fix a bug, and the macro stamps it out to all three backends.
