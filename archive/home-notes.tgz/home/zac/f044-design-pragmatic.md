# F-044: Pragmatic Deduplication of Metadata Provider/Writer Backends

## Executive Summary

The three metadata backend implementations (SQLite, PostgreSQL, MySQL) contain ~15,200 lines of code that are 80-90% structurally identical, differing only in SQL dialect specifics (placeholder syntax, ID generation, timestamp functions, DDL types, upsert syntax, table-existence checks). This duplication has caused 18+ parity findings across 6 of 8 review cycles. This design proposes a **3-phase incremental migration** that progressively deduplicates the code while keeping all tests passing at each phase boundary. Phase 1 (helpers) reduces risk immediately with ~1,500 LOC savings. Phase 2 (dialect trait) delivers the primary deduplication win with ~5,000+ LOC savings. Phase 3 (optional cleanup) polishes the result.

---

## Current State Analysis

### File Inventory

| File | Lines | Role |
|------|-------|------|
| `metadata_writer_sqlite.rs` | 4,478 | Writer impl (SQLite) — largest due to tests |
| `metadata_writer_postgres.rs` | 2,904 | Writer impl (PostgreSQL) |
| `metadata_writer_mysql.rs` | 3,018 | Writer impl (MySQL) |
| `metadata_provider_sqlite.rs` | 1,054 | Provider impl (SQLite) |
| `metadata_provider_postgres.rs` | 1,085 | Provider impl (PostgreSQL) |
| `metadata_provider_mysql.rs` | 1,060 | Provider impl (MySQL) |
| `metadata_writer.rs` | 833 | Writer trait definition |
| `metadata_provider.rs` | 801 | Provider trait + shared SQL constants |
| **Total** | **15,233** | |

### Catalog of Actual Differences

After thorough analysis of all 8 files, the differences fall into **7 categories**:

#### 1. Placeholder Syntax (Mechanical, Pervasive)
- **SQLite**: `?` positional placeholders
- **PostgreSQL**: `$1, $2, $3` numbered placeholders
- **MySQL**: `?` positional placeholders (same as SQLite)
- **Impact**: Every SQL query string differs between PG and SQLite/MySQL. This is the single largest source of textual difference, but it's purely syntactic.

#### 2. ID Generation Strategy (Structural)
- **SQLite**: `RETURNING data_file_id` for auto-increment PKs; `MAX(id)+1` pattern for non-PK IDs (table_id, column_id, view_id, partition_id) within transactions (safe due to single-writer serialization)
- **PostgreSQL**: `RETURNING data_file_id` for `GENERATED ALWAYS AS IDENTITY` PKs; `nextval('ducklake_xxx_seq')` for sequence-based IDs (table_id, column_id, schema_version)
- **MySQL**: `LAST_INSERT_ID()` after INSERT for auto-increment PKs; custom `_df_sequences` table with `next_sequence_id()` helper for non-PK IDs
- **Impact**: ~15 call sites per backend. The logic *around* ID generation is identical; only the ID retrieval mechanism differs.

#### 3. DDL / Schema Creation (Isolated to `initialize_schema`)
- **SQLite**: Single multi-statement `CREATE TABLE IF NOT EXISTS` string
- **PostgreSQL**: Array of individual `CREATE TABLE` statements + 3 `CREATE SEQUENCE` statements
- **MySQL**: Individual `CREATE TABLE` constants + `_df_sequences` table; uses backtick quoting for reserved words (`key`, `sql`, `type`)
- **Type differences**: `INTEGER` (SQLite) vs `BIGINT` (PG/MySQL); `TEXT` vs `VARCHAR(255)`; `INTEGER PRIMARY KEY` vs `BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY` vs `BIGINT AUTO_INCREMENT PRIMARY KEY`
- **Impact**: ~300 lines per backend, but only called once during initialization. This is the least important to deduplicate.

#### 4. Timestamp Functions (Mechanical)
- **SQLite**: `strftime('%Y-%m-%d %H:%M:%f+00:00', 'now')`
- **PostgreSQL**: `CURRENT_TIMESTAMP` or `NOW()`
- **MySQL**: `NOW(6)`
- **Impact**: ~10 call sites per backend (snapshot creation in every DDL method).

#### 5. UUID Generation (Minor)
- **SQLite**: `uuid::Uuid::new_v4().to_string()` (Rust-side)
- **PostgreSQL**: `gen_random_uuid()` (server-side)
- **MySQL**: `uuid::Uuid::new_v4().to_string()` (Rust-side, same as SQLite)
- **Impact**: ~5 call sites per backend.

#### 6. Upsert / Conflict Handling (Minor)
- **SQLite**: `ON CONFLICT(snapshot_id) DO UPDATE SET changes_made = excluded.changes_made`
- **PostgreSQL**: `ON CONFLICT (snapshot_id) DO UPDATE SET changes_made = EXCLUDED.changes_made`
- **MySQL**: `ON DUPLICATE KEY UPDATE changes_made = VALUES(changes_made)` (requires UNIQUE index on snapshot_id)
- Also `INSERT OR IGNORE` (SQLite) vs `INSERT ... ON CONFLICT DO NOTHING` (PG) vs `INSERT IGNORE` (MySQL)
- **Impact**: ~8 call sites per backend.

#### 7. SQLite-Specific Concurrency Handling (Unique to SQLite)
- `block_on_with_retry()` with SQLITE_BUSY detection and exponential backoff + jitter
- PostgreSQL and MySQL use plain `block_on()` (database handles concurrency natively)
- **Impact**: SQLite wraps ~25 methods in `block_on_with_retry`; PG/MySQL use `block_on`. The retry wrapper is an orthogonal concern.

#### 8. Inlined Data (Backend-Specific Table Existence Checks)
- **SQLite**: `SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name = ?`
- **PostgreSQL**: `SELECT EXISTS(SELECT 1 FROM information_schema.tables WHERE table_name = $1)`
- **MySQL**: `SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?`
- Also `PRAGMA table_info(...)` (SQLite) vs `information_schema.columns` (PG/MySQL) for column discovery
- **Impact**: ~5 call sites, isolated to inlined data methods.

### What's Identical (Copy-Paste)

The following are **structurally identical** across all three backends (differing only in placeholder syntax and ID generation):

- `write_transaction_inner` (~150 lines each): Check schema exists → check table exists → determine DDL → create snapshot → create schema → create table → get/compare columns → set columns → record changes
- `drop_table_inner` (~60 lines each): Validate → create snapshot → end table/columns/files → record changes
- `drop_schema_inner` (~80 lines each): Validate → create snapshot → cascade end columns/files/tables → record changes
- `recompute_table_column_stats` (~80 lines each): Read per-file stats → aggregate with type-aware min/max → write back
- `register_data_file` (~50 lines each): Get row_id_start → insert file → update table_stats
- `register_dml_files` (~120 lines each): Track net deletions → end old deletes → insert new deletes → insert new data files → update stats
- `replace_table_files` (~100 lines each): End existing files → register new files with stats and partitions → update table_stats
- `alter_table` (~200 lines each): Get columns → validate → create snapshot → apply action → record changes
- `rename_table` (~80 lines each): Fetch current row → check duplicates → create snapshot → end old → insert new
- `set_table_comment` / `set_column_comment` (~60 lines each): Create snapshot → end old tag → insert new tag
- `create_view` / `drop_view` / `rename_view` (~80 lines each): Nearly identical patterns
- `begin_checked_write_transaction` (~100 lines each): Conflict detection → delegate to write_transaction_inner
- `drop_table_checked` / `drop_schema_checked` (~40 lines each): Conflict detection → delegate
- All provider methods: Structurally identical, differing only in placeholder syntax

### What's Truly Different

Only these are backend-specific:
1. **Connection pool setup** (~30 lines each): Different pool types and options
2. **DDL statements** (~300 lines each): Different type systems
3. **SQLite BUSY retry logic** (~90 lines, SQLite only)
4. **ID generation** (~5 lines at each call site, but pervasive)
5. **Inlined data table existence checks** (~20 lines each)

---

## Phased Approach

### Phase 1: Extract Shared SQL Builders and Row Mappers

**Goal**: Eliminate the easiest duplication without changing architecture. Create helper functions that all three backends can call. Focus on the **provider** side first (simpler, read-only).

**Duration**: Low risk, fast to implement.

#### Phase 1a: Unified Provider Implementation

The three provider files are nearly identical. The only differences are:
1. Placeholder syntax (`?` vs `$1`)
2. Pool type (`SqlitePool` vs `PgPool` vs `MySqlPool`)
3. A few query variations (SQLite uses `COUNT(*)` for `table_exists`, PG uses `SELECT EXISTS`)
4. Delete file change queries (SQLite lacks `LEFT JOIN LATERAL`)

**Approach**: Introduce a `SqlDialect` enum and generic query builder:

```rust
// src/metadata_provider_common.rs (new file)

/// SQL dialect differences between backends
pub(crate) enum SqlDialect {
    Sqlite,
    Postgres,
    Mysql,
}

impl SqlDialect {
    /// Return a placeholder for the nth parameter (1-indexed)
    pub fn param(&self, n: usize) -> String {
        match self {
            SqlDialect::Postgres => format!("${}", n),
            SqlDialect::Sqlite | SqlDialect::Mysql => "?".to_string(),
        }
    }

    /// Return the current timestamp expression
    pub fn now(&self) -> &'static str {
        match self {
            SqlDialect::Sqlite => "strftime('%Y-%m-%d %H:%M:%f+00:00', 'now')",
            SqlDialect::Postgres => "CURRENT_TIMESTAMP",
            SqlDialect::Mysql => "NOW(6)",
        }
    }

    /// Quote an identifier
    pub fn quote_id(&self, name: &str) -> String {
        match self {
            SqlDialect::Mysql => format!("`{}`", name.replace('`', "``")),
            _ => format!("\"{}\"", name.replace('"', "\"\"")),
        }
    }

    /// Upsert pattern for snapshot_changes
    pub fn upsert_snapshot_changes(&self) -> &'static str {
        match self {
            SqlDialect::Sqlite =>
                "INSERT INTO ducklake_snapshot_changes (snapshot_id, changes_made) VALUES (?, ?) ON CONFLICT(snapshot_id) DO UPDATE SET changes_made = excluded.changes_made",
            SqlDialect::Postgres =>
                "INSERT INTO ducklake_snapshot_changes (snapshot_id, changes_made) VALUES ($1, $2) ON CONFLICT (snapshot_id) DO UPDATE SET changes_made = EXCLUDED.changes_made",
            SqlDialect::Mysql =>
                "INSERT INTO ducklake_snapshot_changes (snapshot_id, changes_made) VALUES (?, ?) ON DUPLICATE KEY UPDATE changes_made = VALUES(changes_made)",
        }
    }
}
```

**Row mapper helpers**: Extract the row-to-struct mapping code that's identical across all backends:

```rust
// In metadata_provider_common.rs
pub(crate) fn map_schema_row(row: &impl Row) -> Result<SchemaMetadata> {
    Ok(SchemaMetadata {
        schema_id: row.try_get(0)?,
        schema_name: row.try_get(1)?,
        path: row.try_get(2)?,
        path_is_relative: row.try_get(3)?,
    })
}

pub(crate) fn map_table_row(row: &impl Row) -> Result<TableMetadata> {
    // ...identical across all three backends
}

pub(crate) fn map_table_file_row(row: &impl Row) -> Result<DuckLakeTableFile> {
    // ...identical across all three backends
}
```

**Estimated changes**:
- New file: `metadata_provider_common.rs` (~200 lines)
- Each provider file reduced from ~1,050 → ~600 lines (row mappers extracted, shared SQL used)
- Net savings: ~1,050 lines

#### Phase 1b: Extract Writer Helper Functions

Extract the **business logic** that's identical across all three writer backends into shared functions. These functions take a generic transaction reference and work with any sqlx backend.

**Key candidates for extraction**:

1. **`recompute_table_column_stats`** — Currently copy-pasted in all three writers (~80 lines each). The only difference is placeholder syntax.

2. **Alter table action dispatch** — The `match action { ... }` block in `alter_table` is ~150 lines of identical logic per backend.

3. **Column schema comparison** — The `schema_matches` check in `write_transaction_inner` is identical.

4. **Table stats update pattern** — The "UPDATE ... WHERE; if rows_affected == 0 then INSERT" pattern appears ~6 times per backend.

**Approach**: Create `metadata_writer_common.rs` with shared SQL template functions:

```rust
// src/metadata_writer_common.rs (new file)

/// Generate the SQL for recording snapshot changes, parameterized by dialect
pub(crate) fn sql_record_snapshot_changes(dialect: &SqlDialect) -> &'static str {
    dialect.upsert_snapshot_changes()
}

/// Generate the SQL for creating a snapshot with schema_version
pub(crate) fn sql_create_snapshot(dialect: &SqlDialect) -> String {
    format!(
        "INSERT INTO ducklake_snapshot (snapshot_time, schema_version) VALUES ({}, {}) RETURNING snapshot_id",
        dialect.now(),
        dialect.param(1)
    )
}
```

**Estimated changes**:
- New file: `metadata_writer_common.rs` (~400 lines)
- Each writer file reduced by ~200-300 lines
- Net savings: ~500 lines

**Phase 1 total LOC savings**: ~1,500 lines
**Phase 1 risk**: Very low — additive only, existing code calls new helpers

#### Phase 1 Rollback Story

Every change in Phase 1 is additive. The old code is replaced by calls to new helper functions. If any helper is wrong, the fix is local to the helper. If the entire approach needs to be reverted, `git revert` the commits.

#### Phase 1 Test Strategy

- All existing tests must pass after each commit
- No new tests needed (same behavior, just refactored)
- Run `cargo test --features write-sqlite` and `cargo test --all-features` (if Docker available)

---

### Phase 2: Dialect Abstraction + Consolidated Implementation

**Goal**: Introduce a `SqlxDialect` trait that abstracts the backend differences, then write a **single generic implementation** of `MetadataWriter` and `MetadataProvider`.

This is the phase that delivers the major deduplication win.

#### Phase 2a: Define the Dialect Trait

```rust
// src/metadata_dialect.rs (new file, ~300 lines)

use sqlx::Database;

/// Trait abstracting SQL dialect differences between metadata backends.
///
/// Implementations provided for SQLite, PostgreSQL, and MySQL.
/// Each method returns a dialect-specific SQL fragment or performs
/// a dialect-specific operation.
pub(crate) trait MetadataDialect: Send + Sync + 'static {
    /// The sqlx Database type
    type Db: Database;

    /// Bind parameter placeholder for the nth parameter (1-indexed)
    fn param(n: usize) -> String;

    /// SQL expression for current timestamp
    fn now_expr() -> &'static str;

    /// Quote an identifier for this dialect
    fn quote_identifier(name: &str) -> String;

    /// Execute a block_on, with retry logic if needed (SQLite)
    fn block_on_with_retry<F, Fut, T>(f: F) -> crate::Result<T>
    where
        F: FnMut() -> Fut,
        Fut: std::future::Future<Output = crate::Result<T>>;

    /// Plain block_on without retry
    fn block_on<F, T>(f: F) -> T
    where
        F: std::future::Future<Output = T>;

    /// Generate next ID for a named sequence within a transaction.
    /// Returns the allocated ID.
    async fn next_id(
        tx: &mut sqlx::Transaction<'_, Self::Db>,
        sequence_name: &str,
        table_name: &str,
        id_column: &str,
    ) -> crate::Result<i64>;

    /// Get the last inserted auto-increment ID (MySQL needs this).
    /// For SQLite/PG, this is unused because they use RETURNING.
    async fn last_insert_id(
        tx: &mut sqlx::Transaction<'_, Self::Db>,
    ) -> crate::Result<i64>;

    /// Create snapshot SQL (different timestamp handling)
    fn sql_create_snapshot() -> &'static str;

    /// Insert-or-ignore SQL for initial data
    fn sql_insert_or_ignore(table: &str, columns: &str, values: &str) -> String;

    /// Upsert snapshot_changes SQL
    fn sql_upsert_snapshot_changes() -> &'static str;

    /// Generate UUID expression (server-side for PG, Rust-side for SQLite/MySQL)
    fn generate_uuid() -> String;

    /// Check if a table exists in the database (for inlined data)
    async fn table_exists_in_db(
        pool: &sqlx::Pool<Self::Db>,
        table_name: &str,
    ) -> crate::Result<bool>;

    /// Get column names from an existing table (for inlined data)
    async fn get_table_columns(
        pool: &sqlx::Pool<Self::Db>,
        table_name: &str,
    ) -> crate::Result<Vec<String>>;

    /// DDL type for a DuckLake column type (maps to backend-specific SQL types)
    fn ddl_column_type(ducklake_type: &str) -> &'static str;

    /// Initialize the catalog schema (DDL statements)
    async fn create_catalog_tables(pool: &sqlx::Pool<Self::Db>) -> crate::Result<()>;

    /// Seed initial catalog metadata
    async fn seed_catalog_metadata(
        tx: &mut sqlx::Transaction<'_, Self::Db>,
    ) -> crate::Result<()>;
}
```

#### Phase 2b: Implement Dialect for Each Backend

```rust
// src/metadata_dialect_sqlite.rs (~200 lines)
pub(crate) struct SqliteDialect;

impl MetadataDialect for SqliteDialect {
    type Db = sqlx::Sqlite;

    fn param(_n: usize) -> String { "?".to_string() }
    fn now_expr() -> &'static str { "strftime('%Y-%m-%d %H:%M:%f+00:00', 'now')" }
    fn quote_identifier(name: &str) -> String {
        format!("\"{}\"", name.replace('"', "\"\""))
    }

    fn block_on_with_retry<F, Fut, T>(f: F) -> crate::Result<T>
    where F: FnMut() -> Fut, Fut: std::future::Future<Output = crate::Result<T>>
    {
        block_on_with_sqlite_retry(f) // existing function
    }

    async fn next_id(
        tx: &mut sqlx::Transaction<'_, sqlx::Sqlite>,
        _sequence_name: &str,
        table_name: &str,
        id_column: &str,
    ) -> crate::Result<i64> {
        // MAX(id)+1 pattern
        let sql = format!("SELECT COALESCE(MAX({}), 0) + 1 FROM {}", id_column, table_name);
        let row = sqlx::query(&sql).fetch_one(&mut **tx).await?;
        Ok(row.try_get(0)?)
    }

    // ... etc
}

// src/metadata_dialect_postgres.rs (~200 lines)
// src/metadata_dialect_mysql.rs (~250 lines, slightly more due to sequence table)
```

#### Phase 2c: Generic Writer Implementation

The key insight: **sqlx is already generic over Database**. We can write a single implementation parameterized by `D: MetadataDialect`:

```rust
// src/metadata_writer_generic.rs (~1,500 lines — one copy instead of three)

pub(crate) struct GenericMetadataWriter<D: MetadataDialect> {
    pool: sqlx::Pool<D::Db>,
    _dialect: std::marker::PhantomData<D>,
}

impl<D: MetadataDialect> GenericMetadataWriter<D> {
    async fn write_transaction_inner(
        mut tx: sqlx::Transaction<'_, D::Db>,
        schema_name: &str,
        table_name: &str,
        columns: &[ColumnDef],
        mode: WriteMode,
    ) -> Result<WriteSetupResult> {
        // One implementation, using D::param(), D::now_expr(), D::next_id(), etc.
        let existing_schema = sqlx::query(&format!(
            "SELECT schema_id FROM ducklake_schema WHERE schema_name = {} AND end_snapshot IS NULL",
            D::param(1)
        ))
        .bind(schema_name)
        .fetch_optional(&mut *tx)
        .await?;

        // ... rest of logic, identical to current code but using D:: methods
    }
}

impl<D: MetadataDialect> MetadataWriter for GenericMetadataWriter<D> {
    fn create_snapshot(&self) -> Result<i64> {
        D::block_on_with_retry(|| async {
            let row = sqlx::query(D::sql_create_snapshot())
                .fetch_one(&self.pool)
                .await?;
            Ok(row.try_get(0)?)
        })
    }

    // ... all other methods
}
```

Then the backend-specific files become thin wrappers:

```rust
// src/metadata_writer_sqlite.rs — reduced to ~100 lines (from 4,478!)
pub type SqliteMetadataWriter = GenericMetadataWriter<SqliteDialect>;

impl SqliteMetadataWriter {
    pub async fn new(connection_string: &str) -> Result<Self> { /* ... */ }
    pub async fn new_with_init(connection_string: &str) -> Result<Self> { /* ... */ }
}

// Tests remain here
#[cfg(test)]
mod tests { /* ... */ }
```

#### Phase 2d: Generic Provider Implementation

Same approach for the provider:

```rust
// src/metadata_provider_generic.rs (~500 lines — one copy instead of three)

pub(crate) struct GenericMetadataProvider<D: MetadataDialect> {
    pool: sqlx::Pool<D::Db>,
    _dialect: std::marker::PhantomData<D>,
}

impl<D: MetadataDialect> MetadataProvider for GenericMetadataProvider<D> {
    fn get_current_snapshot(&self) -> Result<i64> {
        D::block_on(async {
            let row = sqlx::query("SELECT COALESCE(MAX(snapshot_id), 0) FROM ducklake_snapshot")
                .fetch_one(&self.pool)
                .await?;
            Ok(row.try_get(0)?)
        })
    }
    // ... etc
}
```

**Note**: The provider's `get_delete_files_added_between_snapshots` needs special handling because SQLite doesn't support `LEFT JOIN LATERAL`. This method would have a `D`-specific override or a dialect method that returns the appropriate query.

#### Phase 2 Technical Challenges

1. **sqlx generic bounds**: `sqlx::query()` returns `Query<'_, DB, ...>` which is bound to a specific `DB` type. Making this generic requires that `D::Db` implements the right sqlx traits. This works because all three backends implement `sqlx::Database`.

2. **`Row::try_get` type inference**: When reading values, sqlx needs to know the concrete column type. For most cases (`i64`, `String`, `bool`, `Option<T>`), the same types work across all three backends.

3. **MySQL LAST_INSERT_ID**: MySQL can't use `RETURNING`, so the generic code needs a pattern like:
   ```rust
   let data_file_id = if D::SUPPORTS_RETURNING {
       // Use RETURNING clause
   } else {
       // Insert, then D::last_insert_id()
   };
   ```
   This can be handled with an associated const on the dialect trait.

4. **PostgreSQL sequence creation**: PG needs `CREATE SEQUENCE` statements in `initialize_schema`. This is handled by each dialect's `create_catalog_tables` method.

**Estimated changes**:
- New files: `metadata_dialect.rs` (~100 lines trait def), `metadata_dialect_sqlite.rs` (~200), `metadata_dialect_postgres.rs` (~200), `metadata_dialect_mysql.rs` (~250), `metadata_writer_generic.rs` (~1,500), `metadata_provider_generic.rs` (~500)
- Modified: `metadata_writer_sqlite.rs` (4,478 → ~200 lines + tests), `metadata_writer_postgres.rs` (2,904 → ~100 lines), `metadata_writer_mysql.rs` (3,018 → ~100 lines)
- Modified: `metadata_provider_sqlite.rs` (1,054 → ~60 lines), `metadata_provider_postgres.rs` (1,085 → ~60 lines), `metadata_provider_mysql.rs` (1,060 → ~60 lines)

**Phase 2 LOC analysis**:
- New code: ~2,750 lines
- Removed code: ~(4,478-200) + (2,904-100) + (3,018-100) + (1,054-60) + (1,085-60) + (1,060-60) = ~11,959 lines removed
- Previous Phase 1 helper files may be absorbed into generic impl: ~-600 lines
- **Net savings: ~5,000-6,000 lines**

#### Phase 2 Migration Strategy (CRITICAL)

Do NOT attempt this as a big-bang rewrite. Instead:

**Step 1**: Write `GenericMetadataWriter<SqliteDialect>` alongside the existing `SqliteMetadataWriter`. Run both in parallel in tests to verify behavioral equivalence.

**Step 2**: Once the generic SQLite implementation passes all tests, switch the public type alias:
```rust
pub type SqliteMetadataWriter = GenericMetadataWriter<SqliteDialect>;
```
Delete the old implementation code (keep tests).

**Step 3**: Implement `PostgresDialect` and switch PostgresMetadataWriter. Run PG tests.

**Step 4**: Implement `MySqlDialect` and switch MySqlMetadataWriter. Run MySQL tests.

Each step is independently deployable and revertible.

#### Phase 2 Rollback Story

- Each step targets one backend. If PG breaks, revert only the PG switch while keeping SQLite on the generic path.
- The generic implementation coexists with the old implementations during migration.
- The old code is deleted only after the generic version passes all tests for that backend.

#### Phase 2 Test Strategy

- All existing tests must pass at every step
- Add a "parallel execution" test that runs the same operations through both old and new implementations and compares results (temporary, removed after migration)
- Cross-engine tests are the ultimate validation

---

### Phase 3: Polish and Cleanup (Optional)

**Goal**: Clean up any remaining duplication and improve maintainability.

#### Phase 3a: Consolidate SQL Constants

Move shared SQL query templates from `metadata_provider.rs` to `metadata_dialect.rs` or a shared queries module. The existing `SQL_GET_DATA_FILES`, `SQL_LIST_SCHEMAS`, etc. constants already use `?` placeholders. Either:
- Keep them as-is (SQLite/MySQL can use directly)
- Generate them via dialect methods (for PG's `$N` syntax)

#### Phase 3b: Merge Provider Trait SQL with Shared Constants

Currently `metadata_provider.rs` has shared SQL constants that the provider implementations partially use and partially inline. Consolidate so all queries come from one place.

#### Phase 3c: Simplify Error Handling

The `block_on_with_retry` wrapper is currently SQLite-specific. After genericization, it becomes a `MetadataDialect` method, which is cleaner. Consider whether PG/MySQL would benefit from similar retry logic for transient errors.

**Phase 3 LOC savings**: ~200-400 lines
**Phase 3 risk**: Very low — cosmetic improvements

---

## File Structure Evolution

### Before (Current)
```
src/
  metadata_provider.rs              (801 lines - trait + SQL constants)
  metadata_provider_sqlite.rs       (1,054 lines)
  metadata_provider_postgres.rs     (1,085 lines)
  metadata_provider_mysql.rs        (1,060 lines)
  metadata_writer.rs                (833 lines - trait + types)
  metadata_writer_sqlite.rs         (4,478 lines)
  metadata_writer_postgres.rs       (2,904 lines)
  metadata_writer_mysql.rs          (3,018 lines)
  metadata_writer_validation.rs     (1,203 lines)
  Total: ~16,436 lines
```

### After Phase 1
```
src/
  metadata_provider.rs              (801 lines - unchanged)
  metadata_provider_common.rs       (200 lines - NEW: row mappers, SQL helpers)
  metadata_provider_sqlite.rs       (~600 lines - reduced)
  metadata_provider_postgres.rs     (~600 lines - reduced)
  metadata_provider_mysql.rs        (~600 lines - reduced)
  metadata_writer.rs                (833 lines - unchanged)
  metadata_writer_common.rs         (400 lines - NEW: shared SQL builders)
  metadata_writer_sqlite.rs         (~4,200 lines - slightly reduced)
  metadata_writer_postgres.rs       (~2,600 lines - slightly reduced)
  metadata_writer_mysql.rs          (~2,800 lines - slightly reduced)
  metadata_writer_validation.rs     (1,203 lines - unchanged)
  Total: ~14,837 lines (-1,599)
```

### After Phase 2
```
src/
  metadata_provider.rs              (801 lines - trait + SQL constants)
  metadata_provider_generic.rs      (~500 lines - NEW: single generic impl)
  metadata_provider_sqlite.rs       (~60 lines - type alias + constructor)
  metadata_provider_postgres.rs     (~60 lines - type alias + constructor)
  metadata_provider_mysql.rs        (~60 lines - type alias + constructor)
  metadata_writer.rs                (833 lines - trait + types)
  metadata_writer_generic.rs        (~1,500 lines - NEW: single generic impl)
  metadata_writer_sqlite.rs         (~200 lines - alias + constructor + tests)
  metadata_writer_postgres.rs       (~100 lines - alias + constructor)
  metadata_writer_mysql.rs          (~100 lines - alias + constructor)
  metadata_writer_validation.rs     (1,203 lines - unchanged)
  metadata_dialect.rs               (~100 lines - NEW: trait definition)
  metadata_dialect_sqlite.rs        (~200 lines - NEW: SQLite dialect)
  metadata_dialect_postgres.rs      (~200 lines - NEW: PG dialect)
  metadata_dialect_mysql.rs         (~250 lines - NEW: MySQL dialect)
  Total: ~6,167 lines (-10,269 from original!)
```

### After Phase 3
```
  (Same structure, ~200-400 lines less total)
  Total: ~5,800 lines (-10,636 from original, ~65% reduction)
```

---

## Risk Assessment

| Phase | Risk Level | What Could Go Wrong | Mitigation |
|-------|-----------|---------------------|------------|
| 1a | Very Low | Helper function returns wrong value | All existing tests catch this |
| 1b | Low | SQL builder generates wrong query | Tests + review |
| 2a | Low | Trait doesn't capture all differences | Extend trait; old code still available |
| 2b | Medium | sqlx generic bounds don't work as expected | Prototype first with SQLite only |
| 2c | Medium | Behavioral difference in edge case | Parallel testing old vs new |
| 2d | Low | Provider is simpler than writer | Same approach, lower risk |
| 3 | Very Low | Cosmetic changes | Standard refactoring risk |

**Highest risk area**: Phase 2c (generic writer) for MySQL, because MySQL's `LAST_INSERT_ID()` pattern differs most from the `RETURNING`-based pattern used by SQLite and PG. The dialect trait must cleanly abstract this difference.

**Mitigation**: Implement SQLite first (most tested backend), then PG (similar to SQLite), then MySQL (most different). Each backend switch is a separate, revertible step.

---

## Estimated Total LOC Impact

| Phase | New Code | Removed Code | Net Change |
|-------|----------|-------------|------------|
| Phase 1 | +600 | -2,100 | **-1,500** |
| Phase 2 | +2,750 | -8,700 | **-5,950** |
| Phase 3 | +0 | -400 | **-400** |
| **Total** | **+3,350** | **-11,200** | **-7,850** |

Final codebase for these files: **~6,000 lines** (down from ~15,200), a **~60% reduction**.

---

## Key Design Decisions

### Why not macros?

Rust macros could generate the three implementations from a template. However:
- Macro-generated code is hard to debug (error messages point to macro expansion, not source)
- IDE support is poor (no go-to-definition into macro bodies)
- Generics with a trait provide the same deduplication with better tooling support

### Why not a single "any backend" runtime dispatch?

Using `enum BackendPool { Sqlite(SqlitePool), Postgres(PgPool), MySQL(MySqlPool) }` with runtime dispatch would avoid generics but:
- Every method would need match arms
- Performance: virtual dispatch on every query
- Still need backend-specific code for dialect differences
- Generics give compile-time monomorphization with zero runtime cost

### Why generic + dialect trait over sqlx `Any` backend?

sqlx has an `Any` backend that provides runtime polymorphism. However:
- `Any` doesn't support all features we use (RETURNING, specific type coercions)
- `Any` has performance overhead from runtime type checking
- Our dialect trait gives us fine-grained control over each difference

### Why keep backend files even after genericization?

The backend files (`metadata_writer_sqlite.rs`, etc.) remain as thin wrappers because:
- They contain the public type (`SqliteMetadataWriter`)
- They hold backend-specific constructors
- SQLite file keeps the test suite
- Feature-gate boundaries are cleaner per-file
- Users import from a named backend, not a generic

---

## Dependencies and Prerequisites

1. **No prerequisite work needed** — Phase 1 can start immediately
2. **Tests must be green** before starting — `cargo test --features write-sqlite` must pass
3. **Docker optional** — PG/MySQL tests need Docker, but the implementation can proceed without them
4. **No breaking API changes** — All public types remain the same; only internals change

## Recommended Execution Order

1. Phase 1a first — provider dedup is simpler and validates the approach
2. Phase 1b — writer helpers, builds on 1a
3. Phase 2a — define the trait (design checkpoint before heavy implementation)
4. Phase 2b+2c — implement for SQLite first, validate thoroughly
5. Phase 2c continued — PG, then MySQL
6. Phase 2d — provider genericization
7. Phase 3 — optional polish

Each step ends with all tests passing. Each step is a separate PR or commit series.
