# Adding Catalogs to DuckLake: Research & Design Document

**Date:** 2026-02-25
**Status:** Proposal
**Authors:** Research team (synthesis of 5 independent research agents)

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Background & Current State](#background--current-state)
3. [The Case for Catalogs](#the-case-for-catalogs)
4. [Engine-Specific Analysis](#engine-specific-analysis)
5. [Proposed Design](#proposed-design)
6. [Impact Analysis](#impact-analysis)
7. [Risks & Open Questions](#risks--open-questions)
8. [Recommendation](#recommendation)

---

## 1. Executive Summary

**Research question:** Can we add catalogs to DuckLake as a first-class object (catalog → schema → table) without imposing overhead on users who don't need them?

**Answer: Yes — and the design is remarkably simple.**

The proposed change touches only **2 metadata tables** (1 new, 1 modified) out of 25+ existing tables. Because DuckLake's metadata already scopes tables under schemas via `schema_id`, adding a `catalog_id` to the schema table transitively scopes the entire object tree without modifying tables, columns, views, macros, files, or any other metadata entity.

For single-catalog users — the vast majority today — the overhead is:

- **Storage:** One extra row in `ducklake_catalog`, one extra column (`catalog_id DEFAULT 0`) on `ducklake_schema`
- **Query cost:** One additional `AND catalog_id = 0` predicate on schema lookups (indexed, negligible)
- **Migration:** One `CREATE TABLE`, one `ALTER TABLE ADD COLUMN`, one `INSERT` — the simplest migration in DuckLake's history
- **Behavioral change:** None. The default catalog is implicit. Existing queries, paths, and workflows are unchanged.

The value proposition differs by engine:

| Engine | Value | Reason |
|--------|-------|--------|
| **DataFusion** | **High** | Native 3-level hierarchy; enables multi-tenant, cross-catalog queries from a single connection |
| **DuckDB** | **Moderate** | `METADATA_SCHEMA` already provides a workaround, but spec-level catalogs would be cleaner and portable |
| **Spec/Ecosystem** | **High** | Aligns with industry standard (Hive, Unity Catalog, Iceberg REST, AWS Glue all have catalogs) |

**Recommendation:** Add catalogs to the DuckLake spec in **v0.5**. The change is minimal, the migration is trivial, and the design degrades gracefully to a no-op for single-catalog deployments. This is a case where doing it right is also doing it simply.

---

## 2. Background & Current State

### 2.1 What Is DuckLake?

DuckLake is an open table format that stores metadata in a relational database (DuckDB, PostgreSQL, MySQL, or SQLite) and data files on object storage or local filesystems. It has two production implementations:

- **DuckDB extension** — the reference implementation
- **DataFusion extension** — a Rust-based alternative reading the same metadata

### 2.2 Current Metadata Architecture

The metadata layer consists of **25+ tables**, all prefixed `ducklake_`, stored in an attached database. The current object hierarchy is:

```
DuckLake Instance (1 attached database)
└── Schema (ducklake_schema)
    ├── Table (ducklake_table)
    │   ├── Columns (ducklake_column, ducklake_column_tag)
    │   ├── Files (ducklake_file, ducklake_delete_file)
    │   ├── Partitions (ducklake_partition_key)
    │   └── Statistics (ducklake_column_stats, ducklake_column_segment_stats)
    ├── View (ducklake_view)
    └── Macro (ducklake_macro, ducklake_macro_parameter)
```

Key architectural properties:

- **Flat schema namespace:** Schemas are the top-level organizational unit. There is no catalog concept in the metadata.
- **Global ID space:** A single counter (`next_catalog_id` in `ducklake_snapshot` — a misleading name, since it allocates IDs for all object types) provides IDs for schemas, tables, views, etc.
- **Temporal versioning:** All mutable entities carry `begin_snapshot` / `end_snapshot` columns for snapshot isolation.
- **Hierarchical data paths:** Files are stored under `data_path/schema_name/table_name/`.
- **Scoped configuration:** The `ducklake_metadata` table supports `scope` values of NULL (global), `'schema'`, or `'table'` — but not `'catalog'`.
- **In-memory representation:** `DuckLakeCatalogInfo` holds `vector<DuckLakeSchemaInfo>`, `vector<DuckLakeTableInfo>`, etc. — the entire catalog state at a given snapshot.

### 2.3 Current Spec Version

The metadata format is at **version 0.4**, with a well-established migration chain (0.1 → 0.2 → 0.3 → 0.4). Migration is opt-in via the `AUTOMATIC_MIGRATION` attach option. The v1.0 roadmap includes PostgreSQL catalog support with data inlining, inline deletes/updates, and — notably — an **internal review of DATA_PATH/option scopes**, which is directly relevant to catalog-level configuration.

---

## 3. The Case for Catalogs

### 3.1 Industry Context

Every major lakehouse catalog system uses a 3-level hierarchy:

| System | Level 1 | Level 2 | Level 3 |
|--------|---------|---------|---------|
| Hive Metastore 3.0 | Catalog | Database | Table |
| Unity Catalog | Catalog | Schema | Table |
| Iceberg REST Catalog | Namespace (multi-level) | — | Table |
| AWS Glue | Catalog (account-level) | Database | Table |
| Polaris | Catalog | Namespace | Table |
| **DuckLake (current)** | **(none)** | **Schema** | **Table** |

DuckLake is the outlier. Adding a catalog level aligns with established conventions and interoperability expectations.

### 3.2 Use Cases

**Multi-tenancy:** A single DuckLake metadata database can serve multiple logical catalogs (e.g., `production`, `staging`, `dev`) without requiring separate metadata databases or connection strings.

**Organizational namespacing:** Large organizations can partition data by domain (e.g., `finance.public.transactions`, `marketing.analytics.campaigns`) within a single metadata store.

**Cross-catalog queries:** Both DuckDB and DataFusion support multi-catalog queries natively. With catalogs in the spec, a single connection can query across organizational boundaries:

```sql
SELECT *
FROM production.sales.orders o
JOIN staging.sales.orders s ON o.id = s.id
WHERE o.amount != s.amount;
```

**Portable catalog semantics:** Without spec-level catalogs, each engine invents its own workaround (DuckDB uses `METADATA_SCHEMA`, DataFusion would need custom registration logic). A spec-level concept ensures consistent behavior across implementations.

### 3.3 Who Benefits Most?

- **DataFusion users:** The most direct beneficiaries. DataFusion's native `CatalogProvider → SchemaProvider → TableProvider` hierarchy maps cleanly to a 3-level DuckLake model. Today, one DuckLake database = one `register_catalog()` call. With catalogs, a single DuckLake connection can expose multiple catalogs.
- **Multi-engine deployments:** Organizations using both DuckDB and DataFusion against the same metadata get a consistent catalog model.
- **Platform builders:** Anyone building a data platform on DuckLake gains standard namespace isolation without custom workarounds.

---

## 4. Engine-Specific Analysis

### 4.1 DuckDB Perspective

#### The ATTACH Constraint

DuckDB's architecture enforces a **strict 1:1 mapping between ATTACH and catalog**. The `DuckLakeAttach()` function returns exactly one `unique_ptr<Catalog>`, and this is architecturally fixed — there is no mechanism to produce multiple DuckDB catalogs from a single ATTACH call.

This means that even if DuckLake adds a catalog concept to the metadata, DuckDB cannot expose multiple DuckLake catalogs from one ATTACH. Each DuckDB catalog must correspond to a separate ATTACH.

#### The METADATA_SCHEMA Workaround

DuckDB already has a practical solution: the `METADATA_SCHEMA` attach option. By attaching the same metadata database multiple times with different `METADATA_SCHEMA` values, users get separate DuckDB catalogs backed by separate DuckLake schema namespaces:

```sql
ATTACH 'ducklake:metadata.db' AS prod (METADATA_SCHEMA='prod_meta');
ATTACH 'ducklake:metadata.db' AS staging (METADATA_SCHEMA='staging_meta');

-- Cross-catalog query works natively
SELECT * FROM prod.public.users JOIN staging.public.users USING (id);
```

Each attachment gets its own `DuckLakeTransactionManager`, so there are no shared transactions — a feature, not a limitation.

#### Value Proposition for DuckDB

While `METADATA_SCHEMA` works, spec-level catalogs would provide:

1. **Cleaner semantics:** `METADATA_SCHEMA` is a DuckDB-specific workaround. Catalog-level isolation is a more natural concept.
2. **Interoperability:** A DataFusion process and a DuckDB process see the same catalog boundaries.
3. **Path resolution:** Catalog-level data paths allow physical data separation by catalog.

**Bottom line:** For DuckDB users alone, the existing workaround is adequate. The value comes from cross-engine consistency and spec cleanliness.

### 4.2 DataFusion Perspective

#### Natural Architectural Fit

DataFusion's catalog hierarchy is a direct match:

```
DataFusion                    DuckLake (proposed)
─────────────────────────────────────────────────
CatalogProviderList     →     (new) ducklake_catalog
  └── CatalogProvider   →     DuckLakeCatalog (with catalog_id)
        └── SchemaProvider →  DuckLakeSchema
              └── TableProvider → DuckLakeTable
```

Currently, DuckLake maps to all three levels, but the top level is always a single implicit catalog. Adding catalog support makes this mapping explicit and allows a single DuckLake connection to expose multiple catalogs through DataFusion's native `CatalogProviderList`.

#### Required Changes

| Component | Change |
|-----------|--------|
| `MetadataProvider` trait | Add `list_catalogs()`, `get_catalog_by_name()` |
| `list_schemas()` / `get_schema_by_name()` | Add `catalog_id` parameter |
| `DuckLakeCatalog` | Add `catalog_id` field to constructor |
| Write path (`begin_write_transaction`) | Accept catalog name in addition to schema name |
| Table functions | Support catalog-qualified names instead of hardcoded "main" |
| Path resolution | Insert catalog path segment between data_path and schema path |

#### Benefits

- **Multi-tenant serving:** A single DataFusion process can serve multiple DuckLake catalogs without multiple connections.
- **Cross-catalog queries:** DataFusion already supports this natively; DuckLake catalogs slot in directly.
- **Organizational namespacing:** Standard 3-level naming eliminates custom workarounds.

### 4.3 Spec Perspective

#### Version Roadmap Context

The spec is currently at v0.4. The v1.0 roadmap already includes a review of `DATA_PATH` and option scopes, which is directly relevant — adding a catalog scope to `ducklake_metadata` is a natural part of that review.

The post-v1.0 roadmap mentions **branching and merge**, which implies multi-version catalog support. Having an explicit catalog concept in place before branching arrives will simplify that design significantly.

#### What v0.5 Would Look Like

Adding catalogs would be a clean v0.5 milestone:

- **New table:** `ducklake_catalog`
- **Modified table:** `ducklake_schema` (add `catalog_id` column)
- **Modified table:** `ducklake_metadata` (add `'catalog'` scope)
- **Migration:** Trivially reversible — the simplest migration in the chain

Cross-backend compatibility is preserved: `ducklake_catalog` uses only SQL-92 types (`BIGINT`, `UUID`, `VARCHAR`, `BOOLEAN`), consistent with the existing backend-agnostic approach.

DataFusion's migration support is limited (it reads but doesn't migrate), so the initial implementation would need to handle the new table presence gracefully.

---

## 5. Proposed Design

### 5.1 Schema Changes

#### New Table: `ducklake_catalog`

```sql
CREATE TABLE ducklake_catalog (
    catalog_id    BIGINT PRIMARY KEY,
    catalog_uuid  UUID,
    begin_snapshot BIGINT,
    end_snapshot  BIGINT,
    catalog_name  VARCHAR NOT NULL,
    path          VARCHAR,
    path_is_relative BOOLEAN
);

-- Seed the default catalog
INSERT INTO ducklake_catalog (catalog_id, catalog_uuid, begin_snapshot, end_snapshot, catalog_name, path, path_is_relative)
VALUES (0, gen_random_uuid(), 0, NULL, 'default', NULL, NULL);
```

Design notes:

- **`catalog_id = 0`** is the default catalog. All existing schemas implicitly belong to it.
- **`begin_snapshot` / `end_snapshot`** follows the existing temporal versioning pattern — catalogs are snapshot-versioned like everything else.
- **`path` / `path_is_relative`** enables catalog-level data isolation. When `path` is NULL (as for the default catalog), the data path falls through to the instance-level `data_path` — a complete no-op for single-catalog users.
- **`catalog_uuid`** enables external references and cross-system identification.
- **No foreign key constraints.** Learned from Hive's HIVE-21739 pain — FK constraints on metadata caused migration nightmares. Application-level enforcement only.

#### Modified Table: `ducklake_schema`

```sql
ALTER TABLE ducklake_schema ADD COLUMN catalog_id BIGINT DEFAULT 0;
```

That's it. One column. The `DEFAULT 0` ensures all existing schemas are automatically associated with the default catalog — **zero data migration required**.

#### Extended Metadata Scope

```sql
-- Enable catalog-level configuration
-- The ducklake_metadata.scope column already supports NULL, 'schema', 'table'
-- Add 'catalog' as a valid scope value
```

### 5.2 Migration Strategy (v0.4 → v0.5)

```sql
-- Full migration script
BEGIN TRANSACTION;

-- 1. Create the catalog table
CREATE TABLE ducklake_catalog (
    catalog_id    BIGINT PRIMARY KEY,
    catalog_uuid  UUID,
    begin_snapshot BIGINT,
    end_snapshot  BIGINT,
    catalog_name  VARCHAR NOT NULL,
    path          VARCHAR,
    path_is_relative BOOLEAN
);

-- 2. Seed default catalog
INSERT INTO ducklake_catalog (catalog_id, catalog_uuid, begin_snapshot, end_snapshot, catalog_name, path, path_is_relative)
VALUES (0, gen_random_uuid(), 0, NULL, 'default', NULL, NULL);

-- 3. Add catalog_id to schema table
ALTER TABLE ducklake_schema ADD COLUMN catalog_id BIGINT DEFAULT 0;

-- 4. Update version
UPDATE ducklake_metadata SET value = '0.5' WHERE key = 'version';

COMMIT;
```

**Migration complexity: minimal.** Compare to previous migrations (0.2 → 0.3 added column tags; 0.3 → 0.4 added macros with multiple new tables). This is the simplest migration in the chain.

### 5.3 Query Changes

#### Schema Lookup (Before)

```sql
SELECT * FROM ducklake_schema
WHERE end_snapshot IS NULL;
```

#### Schema Lookup (After)

```sql
SELECT * FROM ducklake_schema
WHERE catalog_id = @catalog_id
  AND end_snapshot IS NULL;
```

For single-catalog users, `@catalog_id` is always `0`. With an index on `(catalog_id, end_snapshot)`, this adds negligible overhead.

#### All Other Queries: Unchanged

Because tables reference schemas via `schema_id`, and `schema_id` is already globally unique, **no other metadata queries need modification**. The catalog scoping is entirely transitive through the schema layer:

```
catalog_id → ducklake_schema.schema_id → ducklake_table.schema_id → (everything else)
```

This is the critical simplicity win: 25+ tables remain untouched.

### 5.4 Path Resolution

| Level | Current | Proposed |
|-------|---------|----------|
| Instance | `data_path/` | `data_path/` |
| Catalog | *(none)* | `[catalog.path]/` (empty for default) |
| Schema | `schema_name/` | `schema_name/` |
| Table | `table_name/files` | `table_name/files` |

**Example (default catalog):**
```
s3://bucket/warehouse/public/orders/data-00001.parquet
                      ^^^^^^ ^^^^^^
                      schema table
```

**Example (named catalog):**
```
s3://bucket/warehouse/production/public/orders/data-00001.parquet
                      ^^^^^^^^^^ ^^^^^^ ^^^^^^
                      catalog    schema table
```

When `catalog.path` is NULL, the catalog level is skipped entirely — backward-compatible with all existing data layouts.

### 5.5 Catalog DDL

```sql
-- Create a new catalog
CREATE CATALOG production;

-- Create with explicit data path
CREATE CATALOG staging WITH (PATH = 's3://bucket/staging/');

-- Drop catalog (must be empty)
DROP CATALOG staging;

-- Drop catalog and all contents (sets end_snapshot transitively)
DROP CATALOG staging CASCADE;

-- Rename
ALTER CATALOG staging RENAME TO pre_production;
```

### 5.6 Suggested Cleanup: Rename `next_catalog_id`

The `ducklake_snapshot.next_catalog_id` column is a universal ID allocator, not catalog-specific. With an actual `ducklake_catalog` table, this naming becomes actively confusing. Recommend renaming to `next_object_id` as part of the v0.5 migration:

```sql
ALTER TABLE ducklake_snapshot RENAME COLUMN next_catalog_id TO next_object_id;
```

---

## 6. Impact Analysis

### 6.1 Performance Overhead for Single-Catalog Users

| Aspect | Overhead | Notes |
|--------|----------|-------|
| Storage | ~100 bytes | 1 row in `ducklake_catalog` + 8 bytes per schema row |
| Schema queries | +1 predicate | `AND catalog_id = 0` — indexed, sub-microsecond |
| Table/view/macro queries | None | No changes to these queries |
| Path resolution | None | `catalog.path` is NULL → skipped |
| In-memory footprint | +8 bytes per schema | One `int64` field |

**Verdict: Negligible.** A single-catalog DuckLake instance is functionally identical before and after this change.

### 6.2 Migration Complexity

| Metric | Value |
|--------|-------|
| New tables | 1 |
| Modified tables | 1 (+ optional rename in `ducklake_snapshot`) |
| Data migration | 0 rows (DEFAULT handles it) |
| SQL statements | 4 (CREATE, INSERT, ALTER, UPDATE version) |
| Risk of data loss | None (purely additive) |
| Reversibility | Full (DROP TABLE + ALTER TABLE DROP COLUMN) |

**Compared to previous migrations:**

| Migration | New Tables | Modified Tables | Complexity |
|-----------|-----------|-----------------|------------|
| 0.1 → 0.2 | 0 | Several | Moderate |
| 0.2 → 0.3 | 1 (column_tag) | 0 | Low |
| 0.3 → 0.4 | 3 (macro tables) | 1 | Moderate |
| **0.4 → 0.5** | **1** | **1** | **Low** |

### 6.3 Implementation Effort per Engine

#### DuckDB

| Task | Effort | Details |
|------|--------|---------|
| Migration code | Low | Add v0.4→0.5 to existing migration chain |
| Metadata queries | Low | Add `catalog_id` parameter to schema queries |
| DDL support | Medium | `CREATE/DROP/ALTER CATALOG` parsing and execution |
| Attach behavior | None | No change — still 1 ATTACH = 1 DuckDB catalog |
| Cross-catalog | None | Already works via multiple ATTACHes |

**Estimated effort: ~1-2 weeks** for a developer familiar with the codebase. Most work is in DDL parsing and catalog management API.

#### DataFusion

| Task | Effort | Details |
|------|--------|---------|
| MetadataProvider trait | Low | Add 2 new methods (`list_catalogs`, `get_catalog_by_name`) |
| Schema queries | Low | Add `catalog_id` to existing methods |
| DuckLakeCatalog | Low | Add `catalog_id` field |
| CatalogProviderList | Medium | New integration point for multi-catalog exposure |
| Write path | Low | Add catalog awareness to `begin_write_transaction` |
| Table functions | Low | Support catalog-qualified names |

**Estimated effort: ~1-2 weeks.** DataFusion's architecture is already designed for 3-level hierarchy, so this is largely plumbing.

### 6.4 Backward Compatibility

| Scenario | Impact |
|----------|--------|
| v0.4 reader, v0.5 metadata | Fails gracefully (unknown version) |
| v0.5 reader, v0.4 metadata | Migrates if `AUTOMATIC_MIGRATION` is on; otherwise fails with version mismatch |
| Existing data files | Completely unaffected — data paths unchanged for default catalog |
| Existing queries | Unchanged — default catalog is implicit |
| Existing METADATA_SCHEMA usage | Unchanged — orthogonal mechanism |
| Cross-backend compatibility | Preserved — only SQL-92 types used |

---

## 7. Risks & Open Questions

### 7.1 Risks

| Risk | Likelihood | Severity | Mitigation |
|------|-----------|----------|------------|
| Naming confusion: `next_catalog_id` vs `catalog_id` | High | Low | Rename to `next_object_id` in same migration |
| DuckDB users confused by "catalog" concept that doesn't map to ATTACH | Medium | Low | Documentation; default catalog is invisible |
| DataFusion migration gap (doesn't support auto-migration) | Medium | Medium | DataFusion needs explicit v0.5 awareness |
| `DEFAULT 0` behavior varies across SQL backends | Low | Medium | Test across DuckDB, PostgreSQL, MySQL, SQLite |
| Catalog-level snapshot isolation complexity | Low | Medium | Catalogs share the instance snapshot — no new isolation boundary |

### 7.2 Open Questions

1. **Default catalog naming:** Should it be `'default'`, `'main'`, or something else? DuckDB uses `'main'` for its default catalog; Hive uses `'hive'`; Unity Catalog uses configurable names. Recommendation: `'default'` — neutral, self-describing, and avoids collision with DuckDB's `'main'`.

2. **Should DuckDB ATTACH expose catalog selection?** An optional `CATALOG` attach option could filter which DuckLake catalog a DuckDB attachment represents:
   ```sql
   ATTACH 'ducklake:metadata.db' AS prod (CATALOG='production');
   ```
   This would be a convenience feature, not a requirement.

3. **Catalog-level ACLs:** The current design has no access control. Should `ducklake_catalog` include ownership/permission columns? Recommendation: defer to post-v1.0 — keep v0.5 minimal.

4. **Interaction with branching:** The post-v1.0 branching feature implies multi-version catalog state. Does adding catalogs now constrain or simplify the branching design? Likely simplifies — branching a catalog is more natural than branching a schema namespace.

5. **Cross-catalog transactions:** Should a single snapshot span multiple catalogs? Current design: yes, the snapshot is instance-level. This is simpler but means you can't have per-catalog snapshot isolation. For now, this is fine — revisit if branching introduces per-catalog versioning.

6. **Catalog-level statistics / compaction:** Should compaction and statistics be scoped to catalogs? The current design inherits table-level scoping, which works. Catalog-level policies could be future `ducklake_metadata` entries with `scope='catalog'`.

---

## 8. Recommendation

### Do It — In v0.5

Add catalogs to the DuckLake spec as a v0.5 feature. The design is:

- **Minimal:** 1 new table, 1 modified table, 0 data migration
- **Backward-compatible:** Default catalog is implicit; existing users see no change
- **Forward-looking:** Aligns with industry standards, enables multi-tenancy, prepares for branching
- **Low-risk:** Purely additive; fully reversible

### Suggested Implementation Order

```
Phase 1: Spec & Core (v0.5)
├── Define ducklake_catalog table schema
├── Add catalog_id to ducklake_schema
├── Write migration (v0.4 → v0.5)
├── Rename next_catalog_id → next_object_id
└── Update ducklake_metadata scope to support 'catalog'

Phase 2: DuckDB Implementation
├── Migration code
├── Schema query changes (add catalog_id filtering)
├── DDL: CREATE/DROP/ALTER CATALOG
├── Optional: CATALOG attach option
└── Tests

Phase 3: DataFusion Implementation
├── MetadataProvider trait extensions
├── DuckLakeCatalog with catalog_id
├── CatalogProviderList integration
├── Write path updates
└── Tests

Phase 4: Documentation & Ecosystem
├── Spec documentation update
├── Migration guide
├── Cross-engine compatibility tests
└── Example: multi-catalog setup
```

### The Key Insight

The reason this works so cleanly is that DuckLake's existing design already scopes everything through `schema_id`. Adding `catalog_id` to schemas is sufficient to transitively scope the entire object tree. This is not a hack — it's a consequence of good relational design. The 25+ unchanged tables are not being ignored; they're already correctly scoped by their existing foreign key relationships.

**Can it be done well, without overhead for use cases not requiring different catalogs?**

Yes. The overhead for single-catalog users is one extra row, one extra column with a default value, and one extra predicate on schema lookups. That's as close to zero-cost as a feature can get.
