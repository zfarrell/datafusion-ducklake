# Claude Code Team Prompt: DataFusion DuckLake Extension

You are implementing the remaining features for the DataFusion DuckLake extension — a production-quality DataFusion table provider backed by the DuckLake open table format.

## Repository Layout

Both repositories are checked out locally:

- `datafusion-ducklake/` — the DataFusion extension (this is the codebase you're modifying)
- `ducklake/` — the DuckLake reference implementation and spec (read-only reference)

You also have access to DuckDB. Install it if needed (`brew install duckdb`, `apt install duckdb`, or download from https://duckdb.org). You will use a local DuckDB + DuckLake instance as the ground truth for expected behavior throughout this work.

## Phase 1: Inventory & Gap Analysis (No Code Changes)

Before writing any new code, produce a comprehensive inventory of the extension's current state and a gap analysis against the reference implementation.

### 1a. Current Implementation Inventory

Read the `datafusion-ducklake` codebase thoroughly and document what is already implemented and working. For each capability, note:

- What it does
- Where it lives (file paths, key structs/traits)
- Whether it has test coverage

This inventory is the foundation — gaps are defined relative to it.

### 1b. Gap Analysis

Identify what is missing, incomplete, or incorrect by cross-referencing three sources:

1. **The DuckLake reference implementation** (`ducklake/` source code) — what operations and behaviors does DuckLake define?
2. **DataFusion's catalog/table provider contracts** — what does DataFusion expect from a well-behaved TableProvider, CatalogProvider, and SchemaProvider?
3. **The existing codebase** — are there TODOs, stubs, `unimplemented!()` calls, or partial implementations?

For anything you're unsure about, **do not guess**. Instead:

- Read the `ducklake/` source to find the answer
- Run a local DuckDB instance with the DuckLake extension loaded and test the behavior directly
- If still ambiguous, flag it explicitly as an open question

Use this template for each gap:

```
## [Gap Name]
- **Status**: not started | partial | stubbed | incorrect
- **What exists**: (file paths, current behavior)
- **What's missing**: (specific behavior or capability)
- **Reference**: (where this is defined in ducklake/ or DataFusion)
- **Priority**: required-for-correctness | important | nice-to-have
- **Open questions**: (anything unresolved)
```

Scope: Focus on the catalog and table provider surface area — DDL, DML, reads, schema management, metadata operations. Do not expand into speculative features that aren't represented in either the reference implementation or the existing codebase.

### 1c. Deliverable

Write the inventory and gap analysis to `docs/gap-analysis.md` in the `datafusion-ducklake` repository.

When the analysis is complete, work with an orchestrator or expert agent to review it, resolve open questions, and agree on a prioritized execution order before proceeding to implementation. Do not begin coding until the analysis is reviewed and the priority order is confirmed.

---

## Phase 2: Testing Strategy

Testing is the primary quality gate for this work. The goal is near-100% compliance with DuckDB's DuckLake sqllogic tests that do not test DuckDB-specific behavior.

### Test Tiers

**Tier 1 — DuckLake sqllogic compatibility tests**
- Port the sqllogic tests from the DuckLake/DuckDB test suite
- Exclude tests that exercise DuckDB-specific syntax, functions, or behavior not relevant to DataFusion
- Document every excluded test with a reason (e.g., "uses DuckDB-specific `PRAGMA`", "tests DuckDB's internal optimizer behavior")
- This is the primary acceptance criterion: if the sqllogic tests pass, the feature works

**Tier 2 — DataFusion contract tests**
- Verify that the extension correctly implements DataFusion's TableProvider, CatalogProvider, and SchemaProvider traits
- Test catalog listing, schema resolution, table creation/deletion, column type mapping
- Test that the extension integrates cleanly with DataFusion's SessionContext (e.g., `SELECT` via SQL, DataFrame API)

**Tier 3 — Behavioral verification against live DuckDB**
- For complex or ambiguous behaviors, write tests that:
  1. Execute an operation against DuckDB + DuckLake
  2. Execute the same operation against DataFusion + this extension
  3. Assert equivalent results
- These are particularly valuable for edge cases in type mapping, NULL handling, transaction semantics, etc.

**Tier 4 — Unit tests**
- For internal logic that benefits from isolated testing (type conversions, SQL generation, metadata parsing)
- Not a substitute for integration tests — use sparingly and only where they add real value

### Testing Principles

- Tests come first. Write the test, watch it fail, then implement.
- Every identified gap must have at least one test before implementation begins.
- A feature is not complete until its tests pass and the rationale is documented.
- No partial implementations presented as complete. If something isn't done, leave a `TODO` and a failing `#[ignore]` test.

Write the testing strategy to `docs/testing-strategy.md`.

---

## Phase 3: Implementation

### Change Management Strategy

All work happens locally on feature branches in the `datafusion-ducklake` repository. The workflow:

1. Create a long-lived local branch: `ducklake-features` (branched from `main`)
2. For each feature, create a sub-branch: `ducklake-features/feature-name`
3. Implement with clean, atomic commits — each commit should be a coherent unit of work with a clear message
4. Merge sub-branches into `ducklake-features` with `--no-ff` to preserve feature boundaries
5. Write commit messages that explain **what** changed and **why** — these will be used when replaying changes into upstream PRs later

The goal is that each feature branch can later be cleanly cherry-picked or replayed as an independent PR against the upstream repository. Structure your commits with this in mind:

- One logical change per commit
- No unrelated changes mixed in
- Tests and implementation in the same commit (or test commit immediately preceding implementation commit)
- No "fix lint" or "oops" commits — amend or squash as you go

### Implementation Principles

**Code Quality**
- Match existing code style and patterns unless there is a strong reason to diverge (document the reason)
- Prefer small, composable changes over large rewrites
- Avoid speculative abstractions — earn abstractions through real duplication
- Favor clarity over cleverness

**DataFusion Alignment**
- Follow established TableProvider / Catalog / Execution patterns
- Do not fight DataFusion's APIs — if something feels awkward, document why before working around it
- Use DataFusion's error types and propagation patterns

**Safety**
- No silent fallbacks or swallowed errors
- No partial implementations presented as complete
- Prefer explicit `TODO` + `#[ignore]` test over incomplete behavior that could be mistaken for correct
- `unimplemented!()` and `todo!()` are acceptable placeholders only when accompanied by a tracking test

**Performance**
- Do not introduce obvious performance regressions
- If a performance tradeoff is unavoidable, document it in the commit message and code comments

### What Not to Touch

Unless a change is required for correctness of a new feature:

- Do not refactor existing working code for style or taste
- Do not reorganize module structure
- Do not update dependencies unless required by a feature
- Do not change public APIs that are already working and tested

If you believe a refactor is genuinely necessary, document the case in the gap analysis and treat it as its own work item — not something done silently alongside a feature.

### Incremental Delivery

Work one feature at a time, in priority order from the approved gap analysis. For each feature:

1. Write tests (Tier 1-3 as applicable)
2. Implement
3. Verify all tests pass
4. Write a brief summary: what capability this unlocks, what changed, and any tradeoffs

---

## Behavioral Guidelines

- Always cite specific file paths and line numbers when referencing existing code
- When stating what DuckLake does, back it up with a reference to `ducklake/` source or a DuckDB test result
- Call out uncertainty early — an explicit "I don't know" is better than a plausible-sounding guess
- Be precise about tradeoffs: what you gain, what you lose, what the alternatives were
- If a decision has meaningful architectural implications, explain the options before committing to one
