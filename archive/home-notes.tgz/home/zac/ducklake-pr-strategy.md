# PR Strategy for Security Review Issues

## Executive Summary

13 issues were identified under "security-review". Work was done on the `ducklake-features/integration` branch, which is a massive feature branch (32k+ lines, 78 files changed) that includes write support, ALTER TABLE, virtual columns, and many other features beyond the security fixes.

**Critical finding: Cherry-picking commits from `ducklake-features/integration` onto `origin/main` will NOT work cleanly.** The security fix commits were authored on top of ~40 prior feature commits that significantly changed file layouts (e.g., `src/table.rs` went from 639 lines on main to 900+ lines; `src/path_resolver.rs` from 778 to 1050 lines). All 4 tested cherry-picks produced merge conflicts.

**Recommended approach: Re-implement each fix fresh against `origin/main`.** The actual logic changes are small and well-understood. Re-implementing avoids conflicts and produces clean, reviewable PRs. The existing commits serve as reference implementations.

---

## Current State of Work

### Committed on `ducklake-features/integration` (4 security commits)

| Commit | Issue | Description | Files |
|--------|-------|-------------|-------|
| `3633fe4` | #52 | Error on missing delete files | `src/table.rs`, `tests/delete_filter_tests.rs` |
| `6d21593` | #54 | Reject `../` path traversal | `src/path_resolver.rs` + 14 other files (signature change) |
| `9c9aaf6` | #54 | Reject `%2e%2e` URL-encoded traversal | `src/path_resolver.rs`, `tests/adversarial_catalog_tests.rs` |
| `90d3b6b` | #55 | Null byte rejection tests | `src/path_resolver.rs` |

### Committed on `ducklake-features/integration` (1 additional commit)

| Commit | Issue | Description | Files |
|--------|-------|-------------|-------|
| `e18832f` | #63 | Reject column_id > i32::MAX | `src/types.rs` |

### Committed on `fixup/review-52` branch (1 commit)

| Commit | Issue | Description | Files |
|--------|-------|-------------|-------|
| `8c3b38b` | #52 | Improve error: distinguish NotFound vs other errors | `src/table.rs` |

### Uncommitted in working tree (2 fixes)

| File | Issues | Description |
|------|--------|-------------|
| `src/table.rs` (modified) | #58, #59 | `validated_file_size()` function + skip negative footer_size |
| `tests/negative_footer_size_test.rs` (new) | #59 | Test for negative footer_size |

### Not yet implemented (6 issues)

| Issue | Description | Target File(s) on main |
|-------|-------------|----------------------|
| #53 | Invalid decimal precision (e.g., precision=0 or >76) | `src/types.rs` `parse_decimal()` |
| #56 | ColumnDef accepts invalid type strings silently | `src/types.rs` `ducklake_to_arrow_type()` |
| #62 | Type roundtrip loses precision (e.g., Decimal128 -> "decimal") | `src/types.rs` `arrow_to_ducklake_type()` |
| #64 | Leading whitespace in data_path not trimmed | `src/path_resolver.rs` or `src/catalog.rs` |
| #61 | Case-sensitive scheme check (`S3://` vs `s3://`) | `src/path_resolver.rs` `parse_object_store_url()` |
| #60 | Non-ASCII paths broken by URL encoding | `src/path_resolver.rs` |
| #57 | Empty catalog with no `.files/` directory | `src/table.rs` or `src/catalog.rs` |

---

## Interdependency Analysis

### Strong Dependencies (MUST be in same PR)

1. **#54 + #55**: The null byte validation (`validate_no_null_bytes()`) is part of the `validate_path()` function introduced by #54. The #55 commit only adds tests for it. These are inseparable — the null byte check was implemented as part of #54's `validate_path()`.

2. **#54's three commits**: `6d21593` (core fix), `9c9aaf6` (%2e%2e follow-up), and `90d3b6b` (null byte tests) form one logical unit.

### Weak Dependencies

3. **#58 + #59**: Both touch `src/table.rs` in the same areas (PartitionedFile creation). The `validated_file_size()` helper and the `footer_size > 0` guard are adjacent code. Combining avoids review confusion from overlapping hunks.

4. **#52 + fixup `8c3b38b`**: The fixup improves #52's error handling. Must be combined.

### Independent Fixes

The following can each be a standalone PR with no dependencies on other fixes:
- #52 (table.rs only, delete file handling)
- #54+#55 (path_resolver.rs + call sites)
- #58+#59 (table.rs only, numeric casts)
- #63 (types.rs only, column_id cast)
- #53 (types.rs only, decimal validation)
- #56 (types.rs only, type string validation)
- #62 (types.rs only, type roundtrip)
- #64 (path_resolver.rs or catalog.rs, whitespace trim)
- #61 (path_resolver.rs, scheme case)
- #60 (path_resolver.rs, non-ASCII)
- #57 (table.rs or catalog.rs, empty catalog)

---

## PR Grouping Strategy

### PR 1: Path traversal and null byte validation (#54, #55) — SECURITY

**Priority**: HIGH (security vulnerability)
**Scope**: `src/path_resolver.rs`, `src/catalog.rs`, `src/schema.rs`, `src/table.rs`

**What to do**:
Re-implement against `origin/main`. The core changes are:
1. Add `validate_no_null_bytes()`, `validate_no_path_traversal()`, and `validate_path()` functions to `path_resolver.rs`
2. Change `join_paths()` signature from `-> String` to `-> Result<String>`
3. Change `resolve_path()` signature from `-> String` to `-> Result<String>`
4. Change `PathResolver::resolve()` from `-> String` to `-> Result<String>`
5. Change `PathResolver::child_resolver()` from `-> Self` to `-> Result<Self>`
6. Update all call sites in `catalog.rs` (1 call), `schema.rs` (3 calls), `table.rs` (5 calls)
7. Add comprehensive tests

**Call sites to update on main**:
- `src/catalog.rs:182` — `resolve_path(...)` → add `?`
- `src/schema.rs:136` — `resolve_path(...)` → add `?` (in async fn returning Result)
- `src/schema.rs:208` — `resolve_path(...)` → add `?`
- `src/table.rs:134` — `resolve_path(...)` → needs `map_err` since it's in a closure
- `src/table.rs:144` — `resolve_path(...)` → same
- `src/table.rs:177` — `resolve_file_path()` return type changes to `Result<String>`
- All callers of `resolve_file_path()` in `table.rs` (lines 202, 280, 336, 413)

**Reference commits**: `6d21593`, `9c9aaf6`, `90d3b6b`

**PR title**: `fix: reject path traversal and null bytes in path resolver`
**PR body**:
```
## Summary
- Add path validation that rejects `../` traversal, URL-encoded `%2e%2e` variants, and null bytes
- Prevents catalog metadata injection where attacker-controlled paths could escape the data directory
- Changes `resolve_path()`, `join_paths()`, and `PathResolver` methods to return `Result` to propagate validation errors
- Closes #54, closes #55

## Test plan
- [ ] Unit tests for `validate_no_null_bytes()` with null at start/middle/end/multiple
- [ ] Unit tests for `validate_no_path_traversal()` with `../`, `..\\`, leading/trailing `..`
- [ ] Unit tests for `%2e%2e`, `%2E%2E`, mixed-case URL-encoded traversal
- [ ] Verify dots in filenames (`schema.v2`, `file..name`) still allowed
- [ ] Verify single dot (`.`) still allowed
- [ ] `cargo test` passes
```

**Git instructions**:
```bash
git checkout -b fix/path-traversal-null-bytes origin/main
# Re-implement the changes manually against main
# Reference: git show 6d21593 9c9aaf6 90d3b6b on ducklake-features/integration
git push -u origin fix/path-traversal-null-bytes
gh pr create --title "fix: reject path traversal and null bytes in path resolver" --body "..."
```

---

### PR 2: Error on missing delete files (#52) — DATA INTEGRITY

**Priority**: HIGH (silent data corruption)
**Scope**: `src/table.rs`, `tests/delete_filter_tests.rs`

**What to do**:
Re-implement against `origin/main`. The changes are:
1. In `read_delete_file_positions()` (line ~274 on main), add a `head()` check before reading
2. Distinguish `object_store::Error::NotFound` from other errors
3. On NotFound: return clear error about missing delete file and data corruption risk
4. On other errors: propagate the original error
5. Add integration tests

**Key code location on main**: `src/table.rs:274-310` (`read_delete_file_positions` function)

**Reference commits**: `3633fe4`, `8c3b38b`

**PR title**: `fix: error on missing delete files instead of silent corruption`
**PR body**:
```
## Summary
- Add explicit existence check for delete files before reading
- Previously, a missing delete file caused the query to silently return all rows (including deleted ones)
- Now fails with a clear error message distinguishing NotFound from permissions/network errors
- Closes #52

## Test plan
- [ ] Test that missing delete file produces clear error message
- [ ] Test that permission/network errors are propagated separately
- [ ] Test normal delete file path still works
- [ ] `cargo test` passes
```

**Git instructions**:
```bash
git checkout -b fix/missing-delete-file-error origin/main
# Re-implement against main's src/table.rs
# Reference: git show 3633fe4 8c3b38b
git push -u origin fix/missing-delete-file-error
gh pr create --title "fix: error on missing delete files instead of silent corruption" --body "..."
```

---

### PR 3: Validate numeric metadata fields (#58, #59) — ROBUSTNESS

**Priority**: MEDIUM (corrupt metadata causes confusing errors)
**Scope**: `src/table.rs`

**What to do**:
Re-implement against `origin/main`. The changes are:
1. Add `validated_file_size(file_size_bytes: i64, file_path: &str) -> DataFusionResult<u64>` helper
2. Replace all 3 occurrences of `file_size_bytes as u64` with `validated_file_size(...)?`
   - Line 284: in `read_delete_file_positions()`
   - Line 338: in `build_exec_for_files_without_deletes()`
   - Line 416: in `build_exec_for_file_with_deletes()`
3. Add `footer_size > 0` guard before all 3 `with_metadata_size_hint()` calls
   - Line 286, 343, 418
4. Add tests for negative values

**Reference**: uncommitted changes in working tree of `ducklake-features/integration`

**PR title**: `fix: validate file_size_bytes and footer_size from metadata`
**PR body**:
```
## Summary
- Replace unsafe `as u64` cast for `file_size_bytes` with `u64::try_from()` + clear error
- Skip negative `footer_size` values instead of wrapping to huge usize
- Negative values in catalog metadata indicate corruption; now caught early with clear errors
- Closes #58, closes #59

## Test plan
- [ ] Test negative file_size_bytes produces clear error
- [ ] Test negative footer_size is silently skipped (not wrapped)
- [ ] Test zero file_size_bytes works
- [ ] Test normal positive values still work
- [ ] `cargo test` passes
```

**Git instructions**:
```bash
git checkout -b fix/validate-numeric-metadata origin/main
# Re-implement against main's src/table.rs
# Reference: git diff HEAD -- src/table.rs in ducklake-features/integration working tree
git push -u origin fix/validate-numeric-metadata
gh pr create --title "fix: validate file_size_bytes and footer_size from metadata" --body "..."
```

---

### PR 4: Reject column_id overflow in Parquet field mapping (#63) — ROBUSTNESS

**Priority**: MEDIUM (silent data mapping corruption)
**Scope**: `src/types.rs`

**What to do**:
Re-implement against `origin/main`. The change is minimal:
1. In `build_read_schema_with_field_id_mapping()` at line 248, replace:
   ```rust
   let field_id = col.column_id as i32;
   ```
   with:
   ```rust
   let field_id = i32::try_from(col.column_id).map_err(|_| {
       DuckLakeError::Internal(format!(
           "column_id {} for column '{}' exceeds i32 range for Parquet field_id",
           col.column_id, col.column_name
       ))
   })?;
   ```
2. Add tests for i32::MAX boundary, i32::MAX+1, and negative values

**Reference commit**: `e18832f`

**PR title**: `fix: reject column_id values exceeding i32 range`
**PR body**:
```
## Summary
- Replace unsafe `as i32` cast with `i32::try_from()` in Parquet field_id mapping
- column_id > 2147483647 would silently wrap to negative, breaking column mapping
- Now returns a clear error instead
- Closes #63

## Test plan
- [ ] Test column_id = i32::MAX succeeds
- [ ] Test column_id = i32::MAX + 1 returns error with value and column name
- [ ] Test negative column_id within i32 range succeeds
- [ ] `cargo test` passes
```

**Git instructions**:
```bash
git checkout -b fix/column-id-overflow origin/main
# Single line change + tests in src/types.rs
# Reference: git show e18832f
git push -u origin fix/column-id-overflow
gh pr create --title "fix: reject column_id values exceeding i32 range" --body "..."
```

---

### PR 5: Validate decimal precision and scale (#53) — ROBUSTNESS

**Priority**: LOW
**Scope**: `src/types.rs`

**What to do**:
Implement fresh against `origin/main`:
1. In `parse_decimal()` (line 168 on main), add validation:
   - Precision must be 1..=76 (Arrow Decimal256 max)
   - Precision must be 1..=38 for Decimal128
   - Scale must be <= precision
   - Return `Err` instead of `None` for invalid values
2. Change return type from `Option<DataType>` to `Option<Result<DataType>>` or validate in caller

**Key code on main**: `src/types.rs:168-200`

**PR title**: `fix: validate decimal precision and scale bounds`
**PR body**:
```
## Summary
- Reject decimal precision=0 or precision>76 with clear error
- Reject scale > precision
- Previously, invalid values were silently accepted or caused Arrow panics
- Closes #53

## Test plan
- [ ] Test decimal(0,0) returns error
- [ ] Test decimal(77,0) returns error
- [ ] Test decimal(10,11) returns error (scale > precision)
- [ ] Test decimal(38,0) and decimal(76,0) succeed
- [ ] `cargo test` passes
```

**Git instructions**:
```bash
git checkout -b fix/decimal-precision-validation origin/main
git push -u origin fix/decimal-precision-validation
gh pr create --title "fix: validate decimal precision and scale bounds" --body "..."
```

---

### PR 6: Reject invalid type strings (#56) — ROBUSTNESS

**Priority**: LOW
**Scope**: `src/types.rs`

**What to do**:
Implement fresh against `origin/main`:
1. The current `UnsupportedType` error for unknown types is the right behavior
2. Add specific validation for strings that look like parameterized types but have invalid params
3. Ensure empty strings, whitespace-only strings, and strings with special chars return errors

**PR title**: `fix: improve validation of DuckLake type strings`

**Git instructions**:
```bash
git checkout -b fix/validate-type-strings origin/main
git push -u origin fix/validate-type-strings
```

---

### PR 7: Type roundtrip precision loss (#62) — ROBUSTNESS

**Priority**: LOW (read-only on main, affects write path on integration)
**Scope**: `src/types.rs`

**Note**: On `origin/main`, `arrow_to_ducklake_type()` already preserves Decimal precision/scale. This issue may only apply to the integration branch's extended type support. **Verify before creating PR** — may be a no-op on main.

**PR title**: `fix: preserve type precision in Arrow-to-DuckLake roundtrip`

---

### PR 8: Path resolver hardening (#61, #64, #60) — ROBUSTNESS

**Priority**: LOW
**Scope**: `src/path_resolver.rs`

**What to do** (can be combined since they're all small path_resolver changes):
1. **#61 (case-sensitive scheme)**: Change `starts_with("s3://")` to case-insensitive check
2. **#64 (leading whitespace)**: Trim `data_path` in `parse_object_store_url()` before processing
3. **#60 (non-ASCII paths)**: Ensure non-ASCII path components pass through without URL-encoding corruption

**Depends on**: PR 1 (path traversal) should merge first since both touch `parse_object_store_url()`

**PR title**: `fix: harden path resolver for edge cases`
**PR body**:
```
## Summary
- Handle case-insensitive URL schemes (S3://, FILE://)
- Trim leading/trailing whitespace from data_path
- Preserve non-ASCII characters in paths
- Closes #61, closes #64, closes #60

## Test plan
- [ ] Test S3://, s3://, S3:// all work
- [ ] Test "  /data/path  " trims to "/data/path"
- [ ] Test paths with Unicode characters (日本語, émojis)
- [ ] `cargo test` passes
```

**Git instructions**:
```bash
git checkout -b fix/path-resolver-hardening origin/main
# Should be based on PR 1 if merged, or origin/main if PR 1 hasn't landed
git push -u origin fix/path-resolver-hardening
```

---

### PR 9: Handle empty catalog gracefully (#57) — ROBUSTNESS

**Priority**: LOW
**Scope**: `src/table.rs` or `src/catalog.rs`

**What to do**:
Verify behavior on main — a catalog with no tables/schemas should already work since `DuckLakeTable` handles empty file lists. The issue may be about the `.files/` directory not existing on the filesystem. Test and fix if needed.

**PR title**: `fix: handle empty catalog with no data directory`

---

## Recommended Merge Order

```
PR 1 (path traversal #54/#55) ←── SECURITY, merge first
  ↓
PR 2 (delete files #52) ←── DATA INTEGRITY, independent
  ↓
PR 3 (numeric metadata #58/#59) ←── independent
PR 4 (column_id #63) ←── independent
  ↓
PR 5 (decimal #53) ←── independent
PR 6 (type strings #56) ←── independent
  ↓
PR 8 (path hardening #61/#64/#60) ←── depends on PR 1
PR 7 (type roundtrip #62) ←── verify if needed on main
PR 9 (empty catalog #57) ←── verify if needed on main
```

PRs 1-4 can all be created simultaneously and merged independently (except PR 8 depends on PR 1).

## Key Decisions for the Team

1. **Re-implement vs cherry-pick**: Cherry-picks will fail. Must re-implement each fix against `origin/main`. The logic is well-understood from the reference commits.

2. **PR 1 scope**: The path traversal fix (#54) changes public API signatures (`resolve_path`, `join_paths` now return `Result`). This is the largest PR — touches 4 source files. Consider whether to keep null byte validation (#55) combined or separate (recommendation: combined, since they share `validate_path()`).

3. **PR 7 and #62**: Verify whether type roundtrip is actually an issue on main's codebase (main only has basic type support, not complex types). May be a no-op.

4. **PR 9 and #57**: Verify whether empty catalog handling is already correct on main. May be a no-op.

5. **#58/#59 overlap with #52**: All three touch `src/table.rs` in the delete/file handling area. PRs 2 and 3 could potentially conflict on merge if done in parallel. Recommend merging PR 2 first, then rebasing PR 3.
