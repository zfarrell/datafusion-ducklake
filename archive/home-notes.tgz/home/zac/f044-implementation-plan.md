# F-044 Implementation Plan: Provider/Writer Code Deduplication

## Overview

The three metadata backends (SQLite, PostgreSQL, MySQL) contain ~15,200 lines of near-identical code across 6 implementation files. This plan eliminates ~6,800 lines of duplication (~50% reduction) using the **macro + dialect trait** approach recommended by the architect review, with 4 grouped macros instead of a single monolith.

**Approach adopted**: Simplicity design (macro + dialect trait) with modifications:
- 4 smaller grouped macros instead of one 2,500-line monolith
- Expanded per-backend override list for structurally different methods
- Provider-first migration (lower risk, validates approach)
- One backend at a time (SQLite → PG → MySQL)
- Phase 0 validation gate before committing to full migration

**Key documents** (for context only — this plan is self-contained):
- `/home/zac/f044-design-simplicity.md` — Original simplicity design
- `/home/zac/f044-architect-review.md` — Architect evaluation

---

## Architecture

### New File Structure

```
src/
  dialect.rs                      NEW    ~250 lines   SqlDialect trait + Sqlite/Postgres/MySql impls
  metadata_provider_impl.rs       NEW    ~800 lines   impl_metadata_provider! macro
  metadata_writer_impl.rs         NEW   ~1500 lines   4 grouped writer macros
  metadata_provider.rs            UNCHANGED            Trait definition + SQL constants + types
  metadata_provider_sqlite.rs     SHRUNK ~200 lines    Struct + macro call + 3 overrides
  metadata_provider_postgres.rs   SHRUNK ~200 lines    Struct + macro call + 3 overrides
  metadata_provider_mysql.rs      SHRUNK ~200 lines    Struct + macro call + 3 overrides
  metadata_writer.rs              UNCHANGED            Trait definition + types
  metadata_writer_sqlite.rs       SHRUNK ~600 lines    Struct + macro calls + overrides + inlined data + tests
  metadata_writer_postgres.rs     SHRUNK ~400 lines    Struct + macro calls + overrides
  metadata_writer_mysql.rs        SHRUNK ~450 lines    Struct + macro calls + overrides + sequence helpers
  metadata_writer_validation.rs   UNCHANGED            Shared validation logic
  lib.rs                          MODIFIED             Add `mod dialect;` + `mod metadata_provider_impl;` + `mod metadata_writer_impl;`
```

### The `SqlDialect` Trait

```rust
// src/dialect.rs

/// SQL dialect differences between SQLite, PostgreSQL, and MySQL.
/// Each method returns a SQL fragment or performs a dialect-specific operation.
pub(crate) trait SqlDialect: Send + Sync + 'static {
    /// Parameter placeholder. SQLite/MySQL: "?", Postgres: "$1", "$2", etc.
    fn ph(&self, n: usize) -> String;

    /// Quote an identifier. SQLite/Postgres: "col", MySQL: `col`.
    fn quote_id(&self, name: &str) -> String;

    /// Quote a column name only if it's a reserved word in this dialect.
    /// MySQL must quote `key`, `sql`, `type`. Others return as-is.
    fn col(&self, name: &str) -> String;

    /// SQL expression for current timestamp.
    /// SQLite: "strftime('%Y-%m-%d %H:%M:%f+00:00','now')"
    /// Postgres: "CURRENT_TIMESTAMP"
    /// MySQL: "NOW(6)"
    fn now(&self) -> &'static str;

    /// Generate a UUID. Returns (sql_expr_or_placeholder, Option<bind_value>).
    /// SQLite/MySQL: ("?", Some(uuid_string))
    /// Postgres: ("gen_random_uuid()", None)
    fn uuid_value(&self) -> (String, Option<String>);

    /// Boolean literal in SQL text. SQLite: "1"/"0", PG/MySQL: "TRUE"/"FALSE".
    fn bool_lit(&self, val: bool) -> &'static str;

    /// CAST to text type. SQLite: TEXT, Postgres: VARCHAR, MySQL: CHAR.
    fn cast_text(&self, expr: &str) -> String;

    /// CAST to integer type. SQLite: no-op, Postgres: BIGINT, MySQL: SIGNED.
    fn cast_int(&self, expr: &str) -> String;

    /// Clamp-to-zero expression. SQLite: MAX(0, expr), PG/MySQL: GREATEST(0, expr).
    fn clamp_zero(&self, expr: &str) -> String;

    /// Upsert clause. Returns the full ON CONFLICT / ON DUPLICATE KEY clause.
    fn upsert(&self, conflict_col: &str, set_cols: &[&str]) -> String;

    /// Whether this dialect supports RETURNING on INSERT. SQLite/PG: true, MySQL: false.
    fn supports_returning(&self) -> bool;

    /// FOR UPDATE clause. SQLite: "" (empty), PG/MySQL: " FOR UPDATE".
    fn for_update(&self) -> &'static str;

    /// INSERT-or-ignore syntax prefix or suffix.
    /// SQLite: wraps as "INSERT OR IGNORE INTO ..."
    /// PG: appends "ON CONFLICT DO NOTHING"
    /// MySQL: wraps as "INSERT IGNORE INTO ..."
    fn insert_or_ignore(&self, table: &str, columns: &str, values: &str) -> String;

    /// Existence check SQL pattern.
    /// PG: SELECT EXISTS(SELECT 1 FROM ... WHERE ...)
    /// SQLite/MySQL: SELECT COUNT(*) FROM ... WHERE ...
    /// Returns (sql_template, uses_exists: bool). When uses_exists=true, result is bool;
    /// when false, result is i64 > 0.
    fn existence_check_is_count(&self) -> bool;
}
```

**Implementations** (3 structs, ~200 lines total):

```rust
pub(crate) struct SqliteDialect;
pub(crate) struct PostgresDialect;
pub(crate) struct MySqlDialect;
```

Each implements all trait methods. See design doc for full implementations. Key differences:

| Method | SQLite | PostgreSQL | MySQL |
|--------|--------|------------|-------|
| `ph(n)` | `"?"` | `format!("${n}")` | `"?"` |
| `quote_id(name)` | `"\"name\""` | `"\"name\""` | `` `name` `` |
| `col(name)` | `name` as-is | `name` as-is | backtick-quote `key`, `sql`, `type` |
| `now()` | `strftime(...)` | `CURRENT_TIMESTAMP` | `NOW(6)` |
| `uuid_value()` | `("?", Some(uuid))` | `("gen_random_uuid()", None)` | `("?", Some(uuid))` |
| `bool_lit(true)` | `"1"` | `"TRUE"` | `"TRUE"` |
| `cast_text(x)` | `CAST(x AS TEXT)` | `CAST(x AS VARCHAR)` | `CAST(x AS CHAR)` |
| `cast_int(x)` | `x` (no-op) | `CAST(x AS BIGINT)` | `CAST(x AS SIGNED)` |
| `clamp_zero(x)` | `MAX(0, x)` | `GREATEST(0, x)` | `GREATEST(0, x)` |
| `upsert(col, sets)` | `ON CONFLICT(col) DO UPDATE SET x = excluded.x` | `ON CONFLICT(col) DO UPDATE SET x = EXCLUDED.x` | `ON DUPLICATE KEY UPDATE x = VALUES(x)` |
| `supports_returning()` | `true` | `true` | `false` |
| `for_update()` | `""` | `" FOR UPDATE"` | `" FOR UPDATE"` |
| `existence_check_is_count()` | `true` | `false` | `true` |

### Macro Groupings

The writer implementation uses 4 grouped macros in `metadata_writer_impl.rs`:

```rust
// Macro 1: Query & metadata ops (~300 lines)
macro_rules! impl_writer_query_ops {
    ($struct_name:ty, pool_type=$pool:ty, dialect=$dialect:expr, block_on=$block_on:path) => { ... }
}

// Macro 2: File operations (~500 lines)
macro_rules! impl_writer_file_ops {
    ($struct_name:ty, pool_type=$pool:ty, dialect=$dialect:expr,
     block_on=$block_on:path, last_insert_id=$last_id:expr) => { ... }
}

// Macro 3: DDL operations (~500 lines)
macro_rules! impl_writer_ddl_ops {
    ($struct_name:ty, pool_type=$pool:ty, dialect=$dialect:expr,
     block_on=$block_on:path, next_id=$next_id:expr, last_insert_id=$last_id:expr) => { ... }
}

// Macro 4: Drop operations (~200 lines)
macro_rules! impl_writer_drop_ops {
    ($struct_name:ty, pool_type=$pool:ty, dialect=$dialect:expr,
     block_on=$block_on:path, last_insert_id=$last_id:expr) => { ... }
}
```

The provider uses 1 macro in `metadata_provider_impl.rs`:

```rust
macro_rules! impl_metadata_provider {
    ($struct_name:ty, pool_type=$pool:ty, dialect=$dialect:expr) => { ... }
}
```

---

## Method Classification

### Provider Methods (MetadataProvider trait)

| # | Method | Classification | Rationale |
|---|--------|---------------|-----------|
| 1 | `get_current_snapshot` | **MACRO** | Identical SQL across all backends, no placeholders |
| 2 | `get_data_path` | **MACRO** | Only diff: `key = ?` vs `key = $1` vs `` `key` = ? `` |
| 3 | `list_snapshots` | **MACRO** | Only diff: `CAST(... AS VARCHAR/TEXT/CHAR)` via `cast_text()` |
| 4 | `list_schemas` | **MACRO** | Only diff: `?` vs `$1` placeholders |
| 5 | `list_tables` | **MACRO** | Only diff: placeholders |
| 6 | `get_table_structure` | **MACRO** | Only diff: placeholders |
| 7 | `get_table_files_for_select` | **MACRO** | Only diff: placeholders |
| 8 | `get_schema_by_name` | **MACRO** | Only diff: placeholders |
| 9 | `get_table_by_name` | **MACRO** | Only diff: placeholders |
| 10 | `table_exists` | **MACRO** | PG uses `SELECT EXISTS(...)`, SQLite/MySQL use `COUNT(*)`. Handle via `existence_check_is_count()` dialect method |
| 11 | `list_all_tables` | **MACRO** | Only diff: `CAST(... AS VARCHAR/TEXT/CHAR)` + placeholders |
| 12 | `list_all_columns` | **MACRO** | Only diff: placeholders |
| 13 | `list_all_files` | **MACRO** | Only diff: placeholders |
| 14 | `get_data_files_added_between_snapshots` | **MACRO** | Only diff: placeholders |
| 15 | `get_delete_files_added_between_snapshots` | **OVERRIDE** | SQLite uses correlated subqueries (no LATERAL), PG/MySQL use LATERAL JOIN. Completely different SQL. |
| 16 | `get_file_column_stats` | **MACRO** | SQLite/MySQL use shared SQL constant; PG inlines with `$N`. Easily unified via placeholders |
| 17 | `get_table_row_count` | **MACRO** | Diff: `CAST(... AS BIGINT/SIGNED)` via `cast_int()` + placeholders. All call `count_inlined_rows` helper |
| 18 | `get_partition_columns` | **MACRO** | PG needs `CAST(... AS INT)` for partition_key_index; SQLite/MySQL use shared constant. Minor diff |
| 19 | `get_file_partition_values` | **MACRO** | PG needs `CAST(... AS INT)`; others use shared constant |
| 20 | `list_views` | **MACRO** | MySQL needs `` `sql` `` backtick quoting via `col()` |
| 21 | `get_view_by_name` | **MACRO** | Same as list_views |
| 22 | `view_exists` | **MACRO** | PG uses `SELECT EXISTS(...)`, others use `COUNT(*)` |
| 23 | `get_inlined_data` | **OVERRIDE** | Different table existence checks: `sqlite_master` vs `information_schema.tables` vs `INFORMATION_SCHEMA.TABLES`. Different column discovery: `PRAGMA table_info` vs `information_schema.columns`. Different quoting: `quote_identifier` vs `quote_mysql_identifier` |
| 24 | `count_inlined_rows` (helper) | **OVERRIDE** | Same reason as `get_inlined_data` — different table existence checks |

**Summary**: 20 MACRO, 3 OVERRIDE (+ 1 helper override)

### Writer Methods (MetadataWriter trait)

| # | Method | Classification | Macro Group | Rationale |
|---|--------|---------------|-------------|-----------|
| 1 | `create_snapshot` | **OVERRIDE** | — | SQLite: nested subqueries for `next_catalog_id`/`next_file_id`, RETURNING. PG: `GREATEST()`, RETURNING. MySQL: `LAST_INSERT_ID()`, no RETURNING. Three structurally different INSERT patterns. |
| 2 | `get_or_create_schema` | **OVERRIDE** | — | SQLite: relies on single-writer + retry. PG: `ON CONFLICT (schema_name) WHERE end_snapshot IS NULL DO NOTHING` (partial index). MySQL: `FOR UPDATE` gap locking. Three different concurrency strategies. |
| 3 | `get_or_create_table` | **OVERRIDE** | — | Same as get_or_create_schema — different concurrency/ID allocation strategies. SQLite: `MAX(table_id)+1`. PG: `nextval()`. MySQL: `next_sequence_id()`. |
| 4 | `set_columns` | **OVERRIDE** | — | Column ID allocation differs: SQLite: `MAX(column_id)+1 WHERE table_id=?` (per-table). PG: `nextval('ducklake_column_id_seq')` (global). MySQL: `next_sequence_ids()` (batch). |
| 5 | `register_column_stats` | **MACRO** | file_ops | Pure placeholder + `bool_lit()` differences. All call `recompute_table_column_stats` helper. |
| 6 | `register_data_file` | **MACRO** | file_ops | Logic identical: lock table_stats, compute row_id_start, INSERT file, update stats. Diffs: `FOR UPDATE` (PG/MySQL), RETURNING vs LAST_INSERT_ID, placeholders. Handled via `supports_returning()`, `for_update()`, `last_insert_id` callback. |
| 7 | `end_table_files` | **MACRO** | file_ops | Pure placeholder differences. Three UPDATE statements. |
| 8 | `replace_table_files` | **MACRO** | file_ops | Complex but structurally identical across backends. Diffs: RETURNING vs LAST_INSERT_ID, FOR UPDATE, placeholders. |
| 9 | `register_dml_files` | **MACRO** | file_ops | Structurally identical. Diffs: RETURNING vs LAST_INSERT_ID, FOR UPDATE, `clamp_zero()`, placeholders. |
| 10 | `get_data_path` (writer) | **MACRO** | query_ops | Identical to provider version. `col("key")` for MySQL quoting. |
| 11 | `set_data_path` | **MACRO** | query_ops | DELETE + INSERT in transaction. Placeholder + `col()` diffs. |
| 12 | `initialize_schema` | **OVERRIDE** | — | Completely different DDL per backend. SQLite: single multi-statement string. PG: individual CREATE TABLE + CREATE SEQUENCE + partial unique indexes. MySQL: backtick quoting + `_df_sequences` table + AUTO_INCREMENT. |
| 13 | `record_snapshot_changes` | **MACRO** | query_ops | Only diff: `upsert()` clause. |
| 14 | `register_delete_file` | **MACRO** | file_ops | End old + INSERT new. Diffs: RETURNING vs LAST_INSERT_ID, placeholders. |
| 15 | `drop_table` | **MACRO** | drop_ops | Thin wrapper calling `drop_table_inner`. |
| 16 | `drop_schema` | **MACRO** | drop_ops | Thin wrapper calling `drop_schema_inner`. |
| 17 | `list_active_table_ids` | **MACRO** | query_ops | Pure placeholder diffs. |
| 18 | `begin_checked_write_transaction` | **OVERRIDE** | — | Different conflict detection: SQLite checks `_df_change_tracking` + catalog tables with `block_on_with_retry`. PG uses `FOR UPDATE` row locks. MySQL uses `FOR UPDATE` gap locks. The `write_transaction_inner` call at the end differs per backend. |
| 19 | `drop_table_checked` | **MACRO** | drop_ops | Conflict check logic is identical across backends (query `_df_change_tracking` + check `end_snapshot`). Diffs: `FOR UPDATE` (PG/MySQL), placeholders. |
| 20 | `drop_schema_checked` | **MACRO** | drop_ops | Same pattern as `drop_table_checked`. |
| 21 | `begin_write_transaction` | **OVERRIDE** | — | Thin wrapper calling `write_transaction_inner` which is per-backend. |
| 22 | `write_transaction_inner` (helper) | **OVERRIDE** | — | 4+ structural differences: schema_version allocation (MAX+1 vs nextval vs next_sequence_value), UUID generation (bind vs SQL fn), column ID allocation, SQLite-only next_catalog_id/next_file_id UPDATE, snapshot creation (RETURNING vs LAST_INSERT_ID), upsert syntax. |
| 23 | `create_view` | **MACRO** | ddl_ops | Structurally identical. Diffs: ID allocation via `$next_id` callback, UUID via `uuid_value()`, timestamp via `now()`, upsert, placeholders, RETURNING vs LAST_INSERT_ID. |
| 24 | `drop_view` | **MACRO** | ddl_ops | Structurally identical. Diffs: `$next_id` for schema_version, `now()`, placeholders. |
| 25 | `rename_view` | **MACRO** | ddl_ops | Structurally identical. Diffs: UUID, `$next_id`, `cast_text()` for UUID cast, `now()`, placeholders, upsert. |
| 26 | `alter_table` | **MACRO** | ddl_ops | Structurally identical — uses `validate_alter_table()` from validation module. Diffs: `$next_id` for column_id/schema_version, `now()`, `bool_lit()`, placeholders. Complex (~200 lines) but the action dispatch logic is identical. |
| 27 | `get_active_columns` | **MACRO** | query_ops | Pure placeholder diffs. |
| 28 | `find_table_id` | **MACRO** | query_ops | Pure placeholder diffs. |
| 29 | `rename_table` | **MACRO** | ddl_ops | Same pattern as rename_view. |
| 30 | `set_table_comment` | **MACRO** | ddl_ops | Structurally identical. Diffs: `$next_id`, `now()`, placeholders, upsert. |
| 31 | `set_column_comment` | **MACRO** | ddl_ops | Same pattern as set_table_comment. |
| 32 | `register_file_partition_value` | **MACRO** | query_ops | Pure placeholder diffs. |
| 33 | `get_active_partition_columns` | **MACRO** | query_ops | Pure placeholder diffs. |
| 34 | `get_data_inlining_row_limit` | **OVERRIDE** | — | SQLite-only (others return `Ok(None)` default). |
| 35 | `get_inlined_row_count` | **OVERRIDE** | — | SQLite-only. |
| 36 | `store_inlined_data` | **OVERRIDE** | — | SQLite-only (~150 lines). |
| 37 | `read_inlined_data` | **OVERRIDE** | — | SQLite-only (~80 lines). |
| 38 | `clear_inlined_data` | **OVERRIDE** | — | SQLite-only (~30 lines). |
| 39 | `recompute_table_column_stats` (helper) | **SHARED FUNCTION** | — | Extracted as a standalone async function parameterized by dialect. ~80 lines identical across all 3 backends except placeholder syntax and boolean binding. |
| 40 | `drop_table_inner` (helper) | **MACRO** | drop_ops | Structurally identical. Diffs: `$next_id` for schema_version, `now()`, `last_insert_id`, placeholders, upsert. |
| 41 | `drop_schema_inner` (helper) | **MACRO** | drop_ops | Calls `drop_table_inner` in a loop, then drops schema. Same diffs. |

**Summary**:
- **MACRO**: 23 methods + 2 inner helpers = 25
- **OVERRIDE**: 12 methods (create_snapshot, get_or_create_schema, get_or_create_table, set_columns, initialize_schema, begin_checked_write_transaction, begin_write_transaction, write_transaction_inner, + 5 inlined data methods)
- **SHARED FUNCTION**: 1 (recompute_table_column_stats)

### Methods per Macro Group

**`impl_writer_query_ops!`** (~300 lines):
- `get_data_path` (writer version)
- `set_data_path`
- `record_snapshot_changes`
- `list_active_table_ids`
- `get_active_columns`
- `find_table_id`
- `register_file_partition_value`
- `get_active_partition_columns`

**`impl_writer_file_ops!`** (~500 lines):
- `register_column_stats`
- `register_data_file`
- `end_table_files`
- `replace_table_files`
- `register_dml_files`
- `register_delete_file`

**`impl_writer_ddl_ops!`** (~500 lines):
- `alter_table`
- `rename_table`
- `rename_view`
- `create_view`
- `drop_view`
- `set_table_comment`
- `set_column_comment`

**`impl_writer_drop_ops!`** (~200 lines):
- `drop_table` (wrapper)
- `drop_schema` (wrapper)
- `drop_table_checked`
- `drop_schema_checked`
- `drop_table_inner` (async helper)
- `drop_schema_inner` (async helper)

---

## Phase 0: Validation Gate

**Goal**: Create `dialect.rs` and extract one shared helper to validate the macro approach works with sqlx's type system.

### Step 0.1: Create `src/dialect.rs`

Create the file with the `SqlDialect` trait and 3 implementations as specified in the Architecture section above. All methods are pure functions returning SQL fragments — no sqlx dependency.

### Step 0.2: Extract `recompute_table_column_stats`

This ~80-line function is copy-pasted identically across all 3 writers (SQLite: line 915, PG: line 755, MySQL: line 877). The only differences are:
- Placeholder syntax (`?` vs `$N`)
- Boolean binding: SQLite uses `.bind(if agg.contains_null { 1 } else { 0 })` vs PG/MySQL use `.bind(agg.contains_null)`

**Changes**:
1. In `metadata_writer_validation.rs`, add a new public async function:
```rust
pub(crate) async fn recompute_table_column_stats<'e, E>(
    executor: E,
    d: &dyn SqlDialect,
    table_id: i64,
) -> Result<()>
where
    E: sqlx::Executor<'e>,
```

**IMPORTANT**: This function cannot be truly generic over sqlx executor types due to the concrete type issue. Instead, create it as a **macro** in `metadata_writer_impl.rs`:

```rust
macro_rules! impl_recompute_table_column_stats {
    ($tx_type:ty, $dialect:expr) => {
        pub(crate) async fn recompute_table_column_stats(
            tx: &mut $tx_type,
            table_id: i64,
        ) -> crate::Result<()> {
            let d = $dialect;
            // ... shared logic using d.ph(), d.bool_lit(), etc.
        }
    };
}
```

2. In each writer file, invoke the macro to generate the function
3. Update each writer's `register_column_stats` and `replace_table_files` to call the generated function
4. Delete the old copy-pasted implementations from each writer

### Step 0.3: Fix boolean binding inconsistency

In SQLite's `recompute_table_column_stats` (line ~970), change:
```rust
.bind(if agg.contains_null { 1 } else { 0 })
```
to:
```rust
.bind(agg.contains_null)
```
SQLite's sqlx driver handles `bool` natively.

### Step 0.4: Update `lib.rs`

Add:
```rust
pub(crate) mod dialect;
```

### Step 0.5: Validate

```bash
cargo build --all-features
cargo test --features write-sqlite
```

**Gate**: If this compiles and tests pass, proceed to Phase 1. If sqlx types fight the macro, investigate before proceeding.

---

## Phase 1: Provider Macro Migration

**Goal**: Create `metadata_provider_impl.rs` and migrate all 3 provider backends.

### Step 1.1: Create `src/metadata_provider_impl.rs`

The macro covers 20 of 24 provider methods. Structure:

```rust
/// Shared implementation of MetadataProvider for sqlx-based backends.
macro_rules! impl_metadata_provider {
    (
        $struct_name:ty,
        pool_type = $pool_type:ty,
        dialect = $dialect:expr
    ) => {
        impl MetadataProvider for $struct_name {
            fn get_current_snapshot(&self) -> Result<i64> { ... }
            fn get_data_path(&self) -> Result<String> { ... }
            fn list_snapshots(&self) -> Result<Vec<SnapshotMetadata>> { ... }
            fn list_schemas(&self, snapshot_id: i64) -> Result<Vec<SchemaMetadata>> { ... }
            fn list_tables(&self, schema_id: i64, snapshot_id: i64) -> Result<Vec<TableMetadata>> { ... }
            fn get_table_structure(&self, table_id: i64, snapshot_id: i64) -> Result<Vec<DuckLakeTableColumn>> { ... }
            fn get_table_files_for_select(&self, table_id: i64, snapshot_id: i64) -> Result<Vec<DuckLakeTableFile>> { ... }
            fn get_schema_by_name(&self, name: &str, snapshot_id: i64) -> Result<Option<SchemaMetadata>> { ... }
            fn get_table_by_name(&self, schema_id: i64, name: &str, snapshot_id: i64) -> Result<Option<TableMetadata>> { ... }
            fn table_exists(&self, schema_id: i64, name: &str, snapshot_id: i64) -> Result<bool> { ... }
            fn list_all_tables(&self, snapshot_id: i64) -> Result<Vec<TableWithSchema>> { ... }
            fn list_all_columns(&self, snapshot_id: i64) -> Result<Vec<ColumnWithTable>> { ... }
            fn list_all_files(&self, snapshot_id: i64) -> Result<Vec<FileWithTable>> { ... }
            fn get_data_files_added_between_snapshots(&self, table_id: i64, start_snapshot: i64, end_snapshot: i64) -> Result<Vec<DataFileChange>> { ... }
            fn get_file_column_stats(&self, table_id: i64, snapshot_id: i64) -> Result<Vec<FileColumnStats>> { ... }
            fn get_table_row_count(&self, table_id: i64, snapshot_id: i64) -> Result<Option<i64>> { ... }
            fn get_partition_columns(&self, table_id: i64, snapshot_id: i64) -> Result<Vec<PartitionColumn>> { ... }
            fn get_file_partition_values(&self, table_id: i64, snapshot_id: i64) -> Result<Vec<FilePartitionValue>> { ... }
            fn list_views(&self, schema_id: i64, snapshot_id: i64) -> Result<Vec<ViewMetadata>> { ... }
            fn get_view_by_name(&self, schema_id: i64, name: &str, snapshot_id: i64) -> Result<Option<ViewMetadata>> { ... }
            fn view_exists(&self, schema_id: i64, name: &str, snapshot_id: i64) -> Result<bool> { ... }
        }
    };
}
pub(crate) use impl_metadata_provider;
```

**Key patterns inside the macro**:

For placeholder-only diffs (e.g., `list_schemas`):
```rust
fn list_schemas(&self, snapshot_id: i64) -> Result<Vec<SchemaMetadata>> {
    let d = $dialect;
    let sql = format!(
        "SELECT schema_id, schema_name, path, path_is_relative FROM ducklake_schema
         WHERE {} >= begin_snapshot AND ({} < end_snapshot OR end_snapshot IS NULL)",
        d.ph(1), d.ph(2)
    );
    block_on(async {
        let rows = sqlx::query(&sql)
            .bind(snapshot_id)
            .bind(snapshot_id)
            .fetch_all(&self.pool)
            .await?;
        rows.into_iter().map(|row| {
            Ok(SchemaMetadata {
                schema_id: row.try_get(0)?,
                schema_name: row.try_get(1)?,
                path: row.try_get(2)?,
                path_is_relative: row.try_get(3)?,
            })
        }).collect()
    })
}
```

For `table_exists` (PG uses EXISTS, others use COUNT):
```rust
fn table_exists(&self, schema_id: i64, name: &str, snapshot_id: i64) -> Result<bool> {
    let d = $dialect;
    block_on(async {
        if d.existence_check_is_count() {
            let sql = format!(
                "SELECT COUNT(*) FROM ducklake_table WHERE schema_id = {} AND table_name = {} AND {} >= begin_snapshot AND ({} < end_snapshot OR end_snapshot IS NULL)",
                d.ph(1), d.ph(2), d.ph(3), d.ph(4)
            );
            let row = sqlx::query(&sql).bind(schema_id).bind(name).bind(snapshot_id).bind(snapshot_id)
                .fetch_one(&self.pool).await?;
            let count: i64 = row.try_get(0)?;
            Ok(count > 0)
        } else {
            let sql = format!(
                "SELECT EXISTS(SELECT 1 FROM ducklake_table WHERE schema_id = {} AND table_name = {} AND {} >= begin_snapshot AND ({} < end_snapshot OR end_snapshot IS NULL))",
                d.ph(1), d.ph(2), d.ph(3), d.ph(4)
            );
            let row = sqlx::query(&sql).bind(schema_id).bind(name).bind(snapshot_id).bind(snapshot_id)
                .fetch_one(&self.pool).await?;
            Ok(row.try_get::<bool, _>(0)?)
        }
    })
}
```

For `get_table_row_count` (needs `cast_int` + calls per-backend `count_inlined_rows`):
The macro generates the data-file portion. The `count_inlined_rows` call is handled by having each backend define the method, then the macro calls `self.count_inlined_rows_impl(table_id, snapshot_id).await?`. Each backend provides a `count_inlined_rows_impl` method.

### Step 1.2: Migrate SQLite Provider

Replace the `impl MetadataProvider for SqliteMetadataProvider` block in `metadata_provider_sqlite.rs` with:

```rust
use crate::metadata_provider_impl::impl_metadata_provider;
use crate::dialect::SqliteDialect;

impl_metadata_provider!(
    SqliteMetadataProvider,
    pool_type = SqlitePool,
    dialect = SqliteDialect
);

// Override methods not in macro:
impl SqliteMetadataProvider {
    // get_delete_files_added_between_snapshots — correlated subquery version
    // get_inlined_data — sqlite_master + PRAGMA table_info
    // count_inlined_rows — sqlite_master existence check
}
```

The 3 override methods stay in the per-backend file.

**Note on overrides**: Since `impl_metadata_provider!` generates an `impl MetadataProvider` block, override methods must be in a SEPARATE trait impl or the macro must exclude them. The cleanest approach: the macro generates ALL methods but for override methods, it calls a `self.method_name_impl(...)` helper that each backend provides. This avoids partial trait impl issues.

**Alternative (simpler)**: The macro does NOT implement the 3 override methods. Instead, each backend file has a second `impl MetadataProvider for XxxProvider` block that only contains the overrides. **This won't compile** — Rust doesn't allow multiple `impl Trait for Type` blocks.

**Correct approach**: The macro generates ALL trait methods. For the 3 that differ, the macro body calls `self.override_get_delete_files(...)`, `self.override_get_inlined_data(...)`, `self.override_count_inlined_rows(...)` — methods defined on the struct (not the trait). Each backend implements these helper methods. The DuckDB provider (read-only, no overrides needed) gets default implementations via a separate trait or default methods.

```rust
// In the macro:
fn get_delete_files_added_between_snapshots(
    &self, table_id: i64, start: i64, end: i64,
) -> Result<Vec<DeleteFileChange>> {
    self.get_delete_files_impl(table_id, start, end)
}
```

Each backend defines `get_delete_files_impl` on its struct.

### Step 1.3: Test SQLite Provider

```bash
cargo test --features write-sqlite
```

### Step 1.4: Migrate PostgreSQL Provider

Same pattern. Override methods:
- `get_delete_files_impl` — LATERAL JOIN version
- `get_inlined_data_impl` — `information_schema.tables` + `information_schema.columns`
- `count_inlined_rows_impl` — `information_schema.tables`

```bash
cargo test --all-features --features skip-tests-with-docker  # or with Docker if available
```

### Step 1.5: Migrate MySQL Provider

Same pattern. Override methods:
- `get_delete_files_impl` — LATERAL JOIN version (MySQL 8.0.14+)
- `get_inlined_data_impl` — `INFORMATION_SCHEMA.TABLES` + `INFORMATION_SCHEMA.COLUMNS`
- `count_inlined_rows_impl` — `INFORMATION_SCHEMA.TABLES`

```bash
cargo test --all-features
```

### Step 1.6: Clean up shared SQL constants

After all 3 providers are migrated, review `metadata_provider.rs` for SQL constants that are no longer used (since the macro generates SQL dynamically). Remove unused constants. Keep constants that are still referenced (e.g., by the DuckDB provider which is NOT being migrated).

---

## Phase 2: Writer Macro — Query & File Ops

**Goal**: Create `metadata_writer_impl.rs` with the first two macro groups and migrate the simplest writer methods.

### Step 2.1: Create `src/metadata_writer_impl.rs` with `impl_writer_query_ops!`

Methods in this macro (8 methods, ~300 lines):
- `get_data_path` — `col("key")` for MySQL, `ph(1)` for placeholder
- `set_data_path` — DELETE + INSERT in transaction
- `record_snapshot_changes` — `upsert("snapshot_id", &["changes_made"])`
- `list_active_table_ids` — Simple SELECT with placeholder
- `get_active_columns` — Simple SELECT with placeholder
- `find_table_id` — JOIN query with placeholders
- `register_file_partition_value` — Simple INSERT with placeholders
- `get_active_partition_columns` — JOIN query with placeholders

Macro signature:
```rust
macro_rules! impl_writer_query_ops {
    ($struct_name:ty, pool_type=$pool:ty, dialect=$dialect:expr, block_on=$block_on:path) => { ... }
}
```

The `block_on` parameter is:
- SQLite: `block_on_with_retry` (the retry wrapper)
- PG/MySQL: `block_on` (from `metadata_provider.rs`)

### Step 2.2: Migrate SQLite writer query ops

In `metadata_writer_sqlite.rs`, replace the 8 method implementations with:
```rust
impl_writer_query_ops!(
    SqliteMetadataWriter,
    pool_type = SqlitePool,
    dialect = SqliteDialect,
    block_on = block_on_with_retry
);
```

Test: `cargo test --features write-sqlite`

### Step 2.3: Migrate PG and MySQL writer query ops

Same pattern, test after each.

### Step 2.4: Add `impl_writer_file_ops!`

Methods (6 methods, ~500 lines):
- `register_column_stats`
- `register_data_file`
- `end_table_files`
- `replace_table_files`
- `register_dml_files`
- `register_delete_file`

Macro signature:
```rust
macro_rules! impl_writer_file_ops {
    ($struct_name:ty, pool_type=$pool:ty, dialect=$dialect:expr,
     block_on=$block_on:path, last_insert_id=$last_id:expr) => { ... }
}
```

The `last_insert_id` parameter:
- SQLite: `|_tx| { unreachable!("SQLite uses RETURNING") }` (never called since `supports_returning() == true`)
- PG: Same as SQLite
- MySQL: `last_insert_id` function (line 374 of MySQL writer)

**Pattern for RETURNING vs LAST_INSERT_ID**:
```rust
let file_id: i64 = if d.supports_returning() {
    let sql = format!("INSERT INTO ducklake_data_file (...) VALUES (...) RETURNING data_file_id");
    let row = sqlx::query(&sql).bind(...).fetch_one(&mut *tx).await?;
    row.try_get(0)?
} else {
    let sql = format!("INSERT INTO ducklake_data_file (...) VALUES (...)");
    sqlx::query(&sql).bind(...).execute(&mut *tx).await?;
    ($last_id)(&mut tx).await?
};
```

### Step 2.5: Migrate file ops per backend

SQLite first, then PG, then MySQL. Test after each.

---

## Phase 3: Writer Macro — DDL & Drop Ops

### Step 3.1: Add `impl_writer_ddl_ops!`

Methods (7 methods, ~500 lines):
- `alter_table`
- `rename_table`
- `rename_view`
- `create_view`
- `drop_view`
- `set_table_comment`
- `set_column_comment`

Macro signature:
```rust
macro_rules! impl_writer_ddl_ops {
    ($struct_name:ty, pool_type=$pool:ty, dialect=$dialect:expr,
     block_on=$block_on:path, next_id=$next_id:expr, last_insert_id=$last_id:expr) => { ... }
}
```

The `next_id` callback:
- SQLite: `|tx: &mut sqlx::Transaction<'_, sqlx::Sqlite>, table: &str, col: &str| async { SELECT COALESCE(MAX(col), 0) + 1 FROM table }`
- PG: `|tx, _table, seq_name| async { SELECT nextval(seq_name) }`
- MySQL: `|tx, _table, seq_name| async { next_sequence_id(tx, seq_name) }`

This callback is used in `create_view` (for view_id + schema_version), `alter_table` (for column_id + schema_version), `rename_table/rename_view` (for schema_version), `set_table_comment/set_column_comment` (for schema_version).

**Key complexity**: `alter_table` (~200 lines per backend). The dispatch logic using `AlterTableAction` from `metadata_writer_validation.rs` is identical across all backends. The only diffs are placeholder syntax, ID allocation, timestamp, and boolean literals — all handled by the dialect trait and callbacks.

### Step 3.2: Add `impl_writer_drop_ops!`

Methods (6 items, ~200 lines):
- `drop_table` — thin wrapper calling `drop_table_inner`
- `drop_schema` — thin wrapper calling `drop_schema_inner`
- `drop_table_checked` — conflict detection + call `drop_table_inner`
- `drop_schema_checked` — conflict detection + call `drop_schema_inner`
- `drop_table_inner` — async helper
- `drop_schema_inner` — async helper

Macro signature:
```rust
macro_rules! impl_writer_drop_ops {
    ($struct_name:ty, pool_type=$pool:ty, db_type=$db:ty, dialect=$dialect:expr,
     block_on=$block_on:path, next_id=$next_id:expr, last_insert_id=$last_id:expr) => { ... }
}
```

Note: `drop_table_inner` and `drop_schema_inner` are generated as inherent `async fn` methods on the struct, not as trait methods. The `drop_table`/`drop_schema` trait methods call them via the `block_on` wrapper.

### Step 3.3: Migrate DDL + drop ops per backend

SQLite first, then PG, then MySQL. Test after each migration.

---

## Phase 4: Cleanup

### Step 4.1: Remove dead code

- Delete empty method implementations from per-backend writer files
- Remove unused imports
- Remove any SQL constants from `metadata_provider.rs` that are no longer referenced

### Step 4.2: Clean up feature gates

Ensure `dialect.rs` has correct feature gates:
```rust
#[cfg(any(feature = "metadata-sqlite", feature = "metadata-postgres", feature = "metadata-mysql"))]
```
Or no gate at all if it's only used by gated modules (Rust dead-code elimination handles this).

### Step 4.3: Final validation

```bash
cargo build --all-features
cargo test --features write-sqlite
cargo test --all-features  # if Docker available
cargo test --all-features --features skip-tests-with-docker  # without Docker
```

### Step 4.4: Verify no regressions

Run cross-engine tests specifically:
```bash
cargo test cross_engine --features write-sqlite
```

---

## Per-Backend Override Details

### Methods that stay per-backend in `metadata_writer_sqlite.rs`

| Method | Why | Lines |
|--------|-----|-------|
| `create_snapshot` | SQLite: single INSERT with `COALESCE(MAX(v)+1 FROM (UNION ALL ...))` for `next_catalog_id`/`next_file_id`. No other backend has these fields. Uses `RETURNING`. | ~30 |
| `get_or_create_schema` | SQLite: relies on single-writer serialization + `block_on_with_retry`. No `FOR UPDATE`, no `ON CONFLICT DO NOTHING` with partial index. Uses `RETURNING schema_id`. | ~60 |
| `get_or_create_table` | Same pattern: `MAX(table_id)+1`, no row locking, `RETURNING`. | ~60 |
| `set_columns` | Column IDs allocated per-table: `MAX(column_id)+1 WHERE table_id=?`. Other backends use global sequences. | ~60 |
| `initialize_schema` | ~280 lines of SQLite-specific DDL (single multi-statement string). | ~280 |
| `begin_checked_write_transaction` | Conflict detection queries differ; calls `write_transaction_inner` with retry. | ~100 |
| `begin_write_transaction` | Wrapper calling `write_transaction_inner` with retry. | ~20 |
| `write_transaction_inner` | 4 structural differences (see method classification table). Includes `next_catalog_id`/`next_file_id` UPDATE. | ~270 |
| Inlined data (5 methods) | SQLite-only: `get_data_inlining_row_limit`, `get_inlined_row_count`, `store_inlined_data`, `read_inlined_data`, `clear_inlined_data`. | ~300 |
| `block_on_with_retry` + `is_sqlite_busy` | SQLite-only retry logic. | ~50 |
| **Tests** | ~1,137 lines of tests stay in this file. | ~1,137 |

### Methods that stay per-backend in `metadata_writer_postgres.rs`

| Method | Why | Lines |
|--------|-----|-------|
| `create_snapshot` | PG: uses `GREATEST()` for `next_file_id`, `RETURNING snapshot_id`. No `next_catalog_id`. | ~20 |
| `get_or_create_schema` | PG: `ON CONFLICT (schema_name) WHERE end_snapshot IS NULL DO NOTHING` + re-SELECT. Uses `gen_random_uuid()` in SQL. | ~65 |
| `get_or_create_table` | PG: `nextval('ducklake_table_id_seq')`, `ON CONFLICT ... DO NOTHING`. | ~75 |
| `set_columns` | PG: `nextval('ducklake_column_id_seq')` per column. | ~55 |
| `initialize_schema` | ~125 lines of PG-specific DDL: `CREATE TABLE`, `CREATE SEQUENCE`, partial unique indexes, `setval()`. | ~125 |
| `begin_checked_write_transaction` | PG: `FOR UPDATE` row locks for conflict detection. | ~90 |
| `begin_write_transaction` | Wrapper. | ~15 |
| `write_transaction_inner` | Uses `nextval()` for schema_version, `gen_random_uuid()`, `nextval('ducklake_column_id_seq')`. No `next_catalog_id` UPDATE. | ~230 |

### Methods that stay per-backend in `metadata_writer_mysql.rs`

| Method | Why | Lines |
|--------|-----|-------|
| `create_snapshot` | MySQL: INSERT without RETURNING + `LAST_INSERT_ID()`. No `next_catalog_id`. | ~25 |
| `get_or_create_schema` | MySQL: `FOR UPDATE` gap lock, `LAST_INSERT_ID()` for schema_id. | ~55 |
| `get_or_create_table` | MySQL: `next_sequence_id()` for table_id, `FOR UPDATE`. | ~60 |
| `set_columns` | MySQL: `next_sequence_ids()` for batch column ID allocation. | ~55 |
| `initialize_schema` | ~130 lines of MySQL-specific DDL: backtick quoting, AUTO_INCREMENT, `_df_sequences` table. | ~130 |
| `begin_checked_write_transaction` | MySQL: `FOR UPDATE` gap locks. | ~90 |
| `begin_write_transaction` | Wrapper. | ~15 |
| `write_transaction_inner` | Uses `next_sequence_value()` for schema_version, `LAST_INSERT_ID()`, `next_sequence_ids()`. | ~230 |
| Module-level helpers | `next_sequence_id()`, `next_sequence_ids()`, `last_insert_id()`, `last_insert_id_conn()` | ~50 |

---

## Testing Strategy

### Per-Phase Testing

| Phase | Test Command | What It Validates |
|-------|-------------|-------------------|
| Phase 0 | `cargo test --features write-sqlite` | Dialect trait compiles; `recompute_table_column_stats` shared function works |
| Phase 1 (each backend) | `cargo test --features write-sqlite` then `--all-features` | Provider methods return identical results |
| Phase 2 (each group) | `cargo test --features write-sqlite` | Query ops and file ops work for writes |
| Phase 3 (each group) | `cargo test --features write-sqlite` | DDL and drop ops work |
| Phase 4 | `cargo test --all-features` | Full regression check |

### Critical Tests to Watch

- `cross_engine` tests — Verify DataFusion<->DuckDB interop still works
- `concurrent` tests — SQLite busy-retry logic still functions
- `alter_table` tests — Complex DDL dispatch logic
- `merge` tests — Uses `register_dml_files` which is being macro-ized
- `delete_filter` tests — Delete file registration
- Inlined data tests — SQLite-only, should be unaffected by macro migration

### Smoke Test After Each Backend Migration

After migrating each backend within a phase:
1. Build: `cargo build --features write-sqlite` (or appropriate feature)
2. Test: `cargo test --features write-sqlite` (or appropriate feature)
3. Cross-engine: `cargo test cross_engine --features write-sqlite`

---

## Risk Mitigations

### Risk 1: Cryptic Macro Error Messages
**Symptom**: Errors like "expected `i64`, found `{integer}`" pointing at macro invocation site.
**Mitigation**:
- Add explicit type annotations in macro body: `row.try_get::<i64, _>(0)?`
- Keep macros small (4 groups, not 1 monolith)
- Use `cargo expand` to inspect generated code when debugging

### Risk 2: Lifetime Issues with `&mut *tx` in Macros
**Symptom**: Borrow checker rejects `tx` usage across await points inside macro.
**Mitigation**: Use temporary variables to shorten borrows:
```rust
let result = sqlx::query(&sql).fetch_one(&mut *tx).await?;
let id: i64 = result.try_get(0)?;
// Now `result` is dropped, freeing the borrow on tx
```

### Risk 3: Feature Gate Interactions
**Symptom**: `dialect.rs` pulls in unwanted dependencies.
**Mitigation**:
- `dialect.rs` has zero external dependencies (pure SQL string generation)
- Each dialect struct is feature-gated: `#[cfg(feature = "metadata-sqlite")]` on `SqliteDialect`
- The `uuid` crate dependency for `uuid_value()` is already in the workspace

### Risk 4: Subtle SQL Differences Missed
**Symptom**: Query returns wrong results or fails on one backend after macro migration.
**Mitigation**:
- Migrate one backend at a time
- Run full test suite after each backend
- Cross-engine tests catch parity issues between DataFusion and DuckDB

### Risk 5: `block_on_with_retry` Incompatibility with Macro
**Symptom**: SQLite retry logic doesn't work inside macro-generated methods.
**Mitigation**: The macro takes `block_on` as a parameter. SQLite passes `block_on_with_retry` which has the signature `fn(F) -> Result<T> where F: FnMut() -> Fut`. The macro wraps async blocks in this closure.

### Risk 6: MySQL `LAST_INSERT_ID` Across Multiple Inserts
**Symptom**: `LAST_INSERT_ID()` returns wrong value when multiple INSERTs happen in the same transaction.
**Mitigation**: This is already handled in the current code — `LAST_INSERT_ID()` is called immediately after each INSERT. The macro preserves this ordering.

---

## Agent Assignment

### Agent 1: Foundation (Phase 0 + Phase 1)
**Scope**: `dialect.rs`, `metadata_provider_impl.rs`, provider backend migration
**Files modified**:
- NEW: `src/dialect.rs`, `src/metadata_provider_impl.rs`
- MODIFIED: `src/lib.rs`, `src/metadata_provider_sqlite.rs`, `src/metadata_provider_postgres.rs`, `src/metadata_provider_mysql.rs`, `src/metadata_writer_validation.rs` (recompute_table_column_stats)
- MODIFIED: `src/metadata_writer_sqlite.rs`, `src/metadata_writer_postgres.rs`, `src/metadata_writer_mysql.rs` (update recompute_table_column_stats calls)
**Estimated effort**: Medium. Low risk but touches many files.

### Agent 2: Writer Query + File Ops (Phase 2)
**Scope**: `impl_writer_query_ops!` + `impl_writer_file_ops!` macros and migration
**Files modified**:
- NEW: `src/metadata_writer_impl.rs`
- MODIFIED: `src/metadata_writer_sqlite.rs`, `src/metadata_writer_postgres.rs`, `src/metadata_writer_mysql.rs`
**Estimated effort**: Medium-High. File ops are the most complex macro group due to RETURNING/LAST_INSERT_ID split.
**Depends on**: Agent 1 (needs `dialect.rs`)

### Agent 3: Writer DDL + Drop Ops (Phase 3)
**Scope**: `impl_writer_ddl_ops!` + `impl_writer_drop_ops!` macros and migration
**Files modified**:
- MODIFIED: `src/metadata_writer_impl.rs` (add 2 more macros)
- MODIFIED: `src/metadata_writer_sqlite.rs`, `src/metadata_writer_postgres.rs`, `src/metadata_writer_mysql.rs`
**Estimated effort**: Medium. `alter_table` is complex but the dispatch logic is well-tested.
**Depends on**: Agent 1 (needs `dialect.rs`), Agent 2 (needs `metadata_writer_impl.rs` file to exist)

### Agent 4: Cleanup (Phase 4)
**Scope**: Dead code removal, unused constant cleanup, final validation
**Files modified**: Various
**Estimated effort**: Low
**Depends on**: Agents 1-3 complete

### Parallelization Notes
- Agents 2 and 3 can start in parallel once Agent 1 completes Phase 0
- Agent 2 creates `metadata_writer_impl.rs`; Agent 3 adds to it — coordinate to avoid merge conflicts
- Alternative: Agent 2 does all of Phase 2 + Phase 3 sequentially, Agent 3 does Phase 4
- Agent 4 should be the same person who reviews the final state

---

## Expected LOC Impact

| Component | Before | After | Reduction |
|-----------|--------|-------|-----------|
| Provider implementations (3 files) | 3,199 | ~600 (overrides only) | ~2,600 (81%) |
| Provider macro (new) | 0 | ~800 | +800 |
| Writer implementations (3 files) | 10,400 | ~3,450 (overrides + inlined data + tests) | ~6,950 (67%) |
| Writer macros (new) | 0 | ~1,500 | +1,500 |
| Dialect trait (new) | 0 | ~250 | +250 |
| Trait definitions (unchanged) | 1,634 | 1,634 | 0 |
| Validation (unchanged) | ~1,200 | ~1,200 | 0 |
| **Total** | **~16,433** | **~9,434** | **~7,000 (43%)** |

Net new code: ~2,550 lines (dialect + macros)
Net deleted code: ~9,550 lines
**Net reduction: ~7,000 lines (43%)**

The remaining per-backend code is genuinely different logic that **should** be separate.
