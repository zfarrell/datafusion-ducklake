# DuckLake Implementation — Supplement Prompt

This document supplements `ducklake-impl-prompt.md` with context from the first implementation session. Use both together when restarting.

## What's Been Done

### Phase 1: Inventory & Gap Analysis (COMPLETE)

Three agents worked in parallel to produce four documents, all committed on branch `ducklake-features/phase1-docs`:

1. **`docs/gap-analysis.md`** — 20 gaps identified between datafusion-ducklake and the DuckLake C++ reference. Each gap has: status, what exists, what's missing, reference implementation files, priority, and open questions. Organized into 5 priority tiers (P0-P4) with a phased implementation order.

2. **`docs/duckdb-behavior-reference.md`** — Behavioral reference from live DuckDB + DuckLake v0.3 testing. Exact SQL, outputs, and edge cases for DDL, DML, time travel, metadata functions, types, transactions, and schema evolution.

3. **`docs/test-portability-survey.md`** — All 342 DuckLake sqllogic tests categorized: ~20 directly portable (Category A), ~165 need adaptation (Category B), ~157 not portable (Category C). Includes common adaptation patterns and recommended porting order.

4. **`docs/testing-strategy.md`** — 4-tier testing strategy: Tier 1 (sqllogic compat), Tier 2 (DataFusion contract tests), Tier 3 (behavioral verification against live DuckDB), Tier 4 (unit tests). Includes test infrastructure setup, naming conventions, and the tests-first principle.

5. **`docs/EXCLUDED_TESTS.md`** — Documents tests excluded from porting with reasons.

### Phase 2: Testing Strategy (COMPLETE)

Covered by `docs/testing-strategy.md` above.

### Phase 3: Implementation (PARTIALLY STARTED)

**Committed on branch `ducklake-features/drop-and-constraints`** (260 LOC, apply via patch):
- `MetadataWriter` trait: added `drop_table()`, `drop_schema()`, `list_active_table_ids()`
- `SqliteMetadataWriter`: full transactional implementations of all three
- `DuckLakeSchema::deregister_table()`: DROP TABLE support
- `DuckLakeCatalog::deregister_schema()`: DROP SCHEMA with CASCADE support
- `DuckLakeInsertExec`: NOT NULL constraint enforcement before writing batches
- All feature-gated under `write`
- **No tests written yet** — this is the first priority before continuing

**NOT started (lost in crash, needs to be redone):**
- Virtual Columns (Gap 17) — exposing `filename`, `file_row_number` on scans
- DELETE support (Gap 1) — writing delete files
- UPDATE support (Gap 2) — delete + insert pattern
- Transaction conflict detection (Gap 14)
- Sqllogic test porting for existing features

## Agreed Priority Order

From the gap analysis, confirmed implementation order:

```
Phase 3a: Write Foundation
  1. Virtual Columns (Gap 17) — prerequisite for DELETE/UPDATE
  2. DELETE support (Gap 1) — write delete files
  3. UPDATE support (Gap 2) — delete + insert pattern
  4. DROP TABLE/SCHEMA (Gap 3) — DONE, needs tests
  5. NOT NULL constraints (Gap 18) — DONE, needs tests
  6. Transaction conflict detection (Gap 14) — write safety

Phase 3b: Read Quality
  7. Column Statistics write (Gap 15)
  8. Column Statistics read (Gap 6)
  9. File Pruning (Gap 7)
  10. Complex Types (Gap 12) — LIST, STRUCT, MAP

Phase 3c: SQL Completeness
  11. Views (Gap 4)
  12. ALTER TABLE (Gap 5)
  13. Additional MetadataWriter backends (Gap 20)

Phase 3d: Advanced (defer)
  14. Compaction (Gap 11)
  15. Time Travel (Gap 8)
  16. MERGE INTO (Gap 9)
  17. Data Inlining (Gap 10)
  18. Encrypted Writes (Gap 19)
  19. Macros (Gap 16)
```

**Key finding from behavioral testing:** Partitioning (Gap 13) is NOT implemented in DuckLake v0.3, so it was dropped to P4.

## Team Structure

We used a 5-agent team managed by an orchestrator (you). Here are the roles:

### Orchestrator (team-lead)
- Manages task list, assigns work, reviews output, makes priority decisions
- Does NOT write code directly — delegates to agents
- Synthesizes findings across agents, resolves conflicts

### Phase 1 Agents (completed, shut down)
- **gap-analyst** — Wrote `docs/gap-analysis.md` by cross-referencing both repos
- **duckdb-tester** — Installed DuckDB + DuckLake, tested behaviors, wrote `docs/duckdb-behavior-reference.md`
- **test-surveyor** — Surveyed 342 sqllogic tests, wrote `docs/test-portability-survey.md` and `docs/testing-strategy.md`

### Phase 3 Agents (need to be respawned)
- **impl-delete** — Virtual Columns + DELETE support. Works on isolated worktree, feature branch `ducklake-features/virtual-columns-and-delete`. Was lost in crash, needs full redo.
- **impl-drop** — DROP TABLE/SCHEMA + NOT NULL. Code is done (on `ducklake-features/drop-and-constraints`), but **tests are missing**. Next step: write tests for the existing implementation.
- **test-porter** — Ports sqllogic tests from ducklake reference to datafusion-ducklake. Works on worktree, branch `ducklake-features/sqllogic-test-porting`. Was lost in crash, needs full redo.

## Where to Pick Up

### Immediate next steps (spawn 3 agents in parallel):

1. **impl-delete agent** (worktree, new branch from main):
   - Implement Virtual Columns (Gap 17): expose `filename`, `file_row_number` on DuckLakeTable scans
   - Implement DELETE support (Gap 1): write delete files, extend MetadataWriter with `register_delete_file()`
   - Write tests first, then implement
   - Reference: `docs/gap-analysis.md` Gaps 1 and 17, `/home/zac/ducklake/src/storage/ducklake_delete.cpp`

2. **impl-drop agent** (worktree, branch from `ducklake-features/drop-and-constraints`):
   - Write tests for the existing DROP TABLE, DROP SCHEMA, and NOT NULL implementations
   - Follow test patterns from `tests/` directory and `docs/testing-strategy.md`
   - Bug fix if tests reveal issues in the existing code

3. **test-porter agent** (worktree, new branch from main):
   - Port sqllogic tests for existing features (reads, INSERT, types)
   - Apply adaptation patterns from `docs/testing-strategy.md`
   - Focus on `insert/`, `general/`, `types/` directories
   - Document excluded tests in `docs/EXCLUDED_TESTS.md`

### After impl-delete completes:

4. **impl-update agent** (worktree, new branch):
   - UPDATE support (Gap 2) — depends on DELETE being done
   - Transaction conflict detection (Gap 14)

## Key Technical Notes

- Git identity: `Zac Farrell <zac@hotdata.dev>`
- Do not attribute claude in commit messages, issues, or PR bodies
- All write code feature-gated under `write` / `write-sqlite`
- All tests must pass — do not assume failures are unrelated to changes
- When fixing bugs, reproduce with a test first, then fix
- DataFusion version: 51.0, Arrow/Parquet: 57
- DuckLake reference is C++ at `/home/zac/ducklake/`
- Agents on worktrees should use `isolation: "worktree"` in Task tool config
